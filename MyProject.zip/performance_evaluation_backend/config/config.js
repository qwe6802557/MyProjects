module.exports = {
    mongodb: {
        host: 'localhost',
        port: '27017',
        database: 'graduation_system'
    },
    redis: {
        host: '127.0.0.1',
        port: '6379'
    }
}