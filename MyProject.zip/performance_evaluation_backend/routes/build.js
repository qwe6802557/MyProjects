/**
 * 学科建设
 * @type {createApplication}
 */
const express = require('express');
const router = express.Router();

module.exports = router;