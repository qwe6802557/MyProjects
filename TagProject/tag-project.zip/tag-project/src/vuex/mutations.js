/**
 * 同步vuex数据操作管理 --- mutations
 */
export default {
    changeUserInfo (state, userInfo) {
        state.userInfo = userInfo;
    },
    changeToken (state, token) {
        state.token = token;
    },
    changeTableData (state, data){
        state.tableData = data;
    },
    changeTableId (state, tableId){
        state.tableId = tableId;
    },
    changeTableTagsId (state, tagIds){
        state.tagIds = tagIds;
    }
}