/**
 * vuex数据管理
 */
import storeUntil from "@/untils/storeUntil";
export default {
    userInfo: {},
    token: storeUntil.getToken(),
    tableData: [],
    tableId: '',
    tagIds: ''
}