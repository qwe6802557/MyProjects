export default function createSql(columnName, mark, value) {
	let sql = " `" + columnName + "` ";
	switch (mark) {
		case 1:// 等于
			sql = sql + " = " + " '" + value + "' ";
			break;
		case 2:// 不等于
			sql = sql + " != " + " '" + value + "' ";
			break;
		case 3:// 大于
			sql = sql + " &gt; " + " '" + value + "' ";
			break;
		case 4:// 小于
			sql = sql + " &lt; " + " '" + value + "' ";
			break;
		case 5:// 大于等于
			sql = sql + " &gt;= " + " '" + value + "' ";
			break;
		case 6:// 小于等于
			sql = sql + " &lt;= " + " '" + value + "' ";
			break;
		case 7:// 包含
			sql = sql + " like " + " '%" + value + "%' ";
			break;
		case 8:// 不包含
			sql = sql + " not like " + " '%" + value + "%' ";
			break;
		default:
			return '';
	}
	return sql;
}
