import Vue from 'vue'
import { Button, RadioGroup, RadioButton,
    Menu, MenuItem, MenuItemGroup, Upload, Input, Pagination, Table, TableColumn, Select, Option } from 'element-ui'


Vue.use(Button).use(RadioGroup).use(RadioButton).use(Menu).use(MenuItem).
use(MenuItemGroup).use(Upload).use(Input).use(Pagination).use(Table).use(TableColumn).use(Select).use(Option);
