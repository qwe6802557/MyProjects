<template>
    <div id="phone">
        <Title :title="'号码管理'"/>
        <div class="button-area">
            <a-button type="primary" icon="search">筛选</a-button>
            <a-button type="danger" icon="delete">批量删除</a-button>
        </div>
        <a-table class="tag-table"
                 :columns="columns"
                 :dataSource="dataSource"
                 :pagination="pagination"
                 :rowKey="rowKey">
            <template slot="operation">
                <a href="javascript:;">删除</a>
            </template>
        </a-table>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    export default {
        name: "Phone",
        data () {
            return {
                columns: [],
                dataSource: [{
                    phone: '123',
                }],
                pagination: {},
                rowKey: 'phone'
            }
        },
        components:{
            Title
        },
        methods: {
            tableInit () {
                this.columns = [
                    {
                        title: '手机号码',
                        dataIndex: 'phone',
                    },
                    {
                        title: '名字',
                        dataIndex: 'age',
                    },
                    {
                        title: '运营商',
                        dataIndex: 'owner',
                    },
                    {
                        title: '省份',
                        dataIndex: 'province',
                    },
                    {
                        title: '城市',
                        dataIndex: 'city',
                    },
                    {
                        title: '操作',
                        dataIndex: 'operation',
                        scopedSlots: { customRender: 'operation' }
                    },
                ];
            }
        },
        mounted() {
            this.tableInit();
        }
    }
</script>

<style scoped lang="less">
    #phone{
        .button-area{
            text-align: left;
        }
        .ant-btn{
            margin-right: 10px;
        }
    }
</style>