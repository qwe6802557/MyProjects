<template>
    <div id="interface">
        <Title :title="title"/>
        <div class="button-area">
            <span style="margin-right: 5px;">表名称:</span>
            <a-select :value="tableValue" style="width: 170px;margin-right: 10px;" @change="changeValue" :loading="tableLoading">
                <a-select-option  :value="''">请选择</a-select-option>
                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">{{item.tableChineseName}}</a-select-option>
            </a-select>
            <span style="margin-right: 5px;">接口类型:</span>
            <a-select :value="interfaceValue" style="width: 170px;margin-right: 10px;" @change="changeInterface" :loading="tableLoading">
                <a-select-option  :value="''">请选择</a-select-option>
                <a-select-option  v-for="item in interfaceData" :value="item.interfaceId" :key="item.interfaceId">{{item.interfaceName}}</a-select-option>
            </a-select>
            <a-button type="primary" icon="search" @click="showTable">查看</a-button>
            <a-button icon="plus" @click="addTagGroup" v-if="userInfo.admin">新建模板</a-button>
            <a-button type="primary" icon="pushpin" @click="changeHeader">筛选显示</a-button>
        </div>
        <a-spin :spinning="initLoading" tip="获取模板数据中...">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="pagination"
                     :rowSelection="rowSelection"
                     :rowKey="'id'"
                     @change="handleTableChange">
                <span slot="tableId" slot-scope="tableId">
                    {{!!selectValue.filter( item => item.id === tableId )[0] && selectValue.filter( item => item.id === tableId )[0].tableChineseName || '-'}}
                </span>
                <span slot="interfaceId" slot-scope="interfaceId">
                    {{!!interfaceData.filter( item => item.interfaceId === interfaceId )[0] && interfaceData.filter( item => item.interfaceId === interfaceId )[0].interfaceName || '-'}}
                </span>
                <span slot="templateData" slot-scope="templateData">
                    <a href="javascript:;" @click="editOperation(templateData)">点击查看</a>
                </span>
                <template slot="operation" slot-scope="text">
                    <a href="javascript:;" @click="deleteOperation(text)" v-if="userInfo.admin">删除</a>
                </template>
            </a-table>
        </a-spin>
        <a-modal :title="modalTitle"
                 v-model="visible"
                 @ok="handleOk"
                 @cancel="handleCancel"
                 :class="showHeader || showDetail? ['common-modal', 'personal-modal'] : ['common-modal', 'tagGroup-modal']"
                 :destroyOnClose="true"
                 :keyboard="true"
                 :maskClosable="false"
                 :okText="'确认'"
                 :cancelText="'取消'"
                 :confirmLoading="confirmLoading">
            <div class="check-box-area" v-if="showHeader && !showDetail">
                <a-checkbox-group name="checkboxgroup"
                                  v-model="checkedHeader"
                                  :options="options">
                </a-checkbox-group>
            </div>
            <div class="template-tag-group" v-if="!showHeader && !showDetail">
                <a-form :form="form">
                <a-col :span="24">
                    <a-form-item label="表名称"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-select
                                v-decorator="[
                                                              'tableId',
                                                              {    initialValue: modalTableValue || undefined,
                                                                   rules: [
                                                                             {   required: true, message: '请选择表名称!' }]
                                                              }
                                                            ]"
                                placeholder="请选择表名称"
                                @change="tableChange"
                        >
                            <a-select-option  v-for="item in modalTableData" :value="item.id" :key="item.id">
                                {{item.tableChineseName}}
                            </a-select-option>
                        </a-select>
                    </a-form-item>
                </a-col>
                <a-col :span="24">
                    <a-form-item label="接口类型"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-select
                                v-decorator="[
                                                              'interfaceId',
                                                              {
                                                                   rules: [
                                                                             {   required: true, message: '请选择接口类型!' }]
                                                              }
                                                            ]"
                                placeholder="请选择接口类型"
                                @change="interfaceChange"
                        >
                            <a-select-option  v-for="item in modalInterfaceData" :value="item.interfaceId" :key="item.interfaceId" :checked="modalInterfaceValue">
                                {{item.interfaceName}}
                            </a-select-option>
                        </a-select>
                    </a-form-item>
                </a-col>
                <a-col :span="24">
                    <a-form-item label="模板名称"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-input v-decorator="[
                                             'templateName',
                                             {
                                                 rules: [
                                                 {   required: true, message: '请输入模板名称!' }] }
                                                ]"
                                 placeholder="请输入模板名称">
                        </a-input>
                    </a-form-item>
                </a-col>
                <a-col :span="24" v-for="(item, index) in modalForm" :key="index">
                    <a-form-item :label="item.name"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-select
                                v-decorator="[
                                                              item.value,
                                                              {
                                                                   rules: [
                                                                             {   required: true, message: '请选择' + item }]
                                                              }
                                                            ]"
                                :placeholder="'请选择' + item.name"
                        >
                            <a-select-option  v-for="cItem in extraColumnData" :value="cItem.tableColumnEnglishName" :key="cItem.id">
                                {{cItem.tableColumnChineseName}}
                            </a-select-option>
                        </a-select>
                    </a-form-item>
                </a-col>
            </a-form>
            </div>
            <div v-if="showDetail">
                <a-list bordered :dataSource="detailDataSource">
                    <a-list-item slot="renderItem" slot-scope="item">
                        <h3>{{item.name}}:</h3>
                        <span style="font-size: 15px;line-height: 28px;margin-left: 30px;">{{item.value}}</span>
                    </a-list-item>
                </a-list>
            </div>
        </a-modal>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import {reqAddTemplate, reqAllTemplate, reqDeleteKey, reqDeleteTemplate} from "../../api/interface";
    import { Modal } from 'ant-design-vue';
    import {reqFindAllColumn, reqFindAllTable} from "../../api/schema";
    import {mapState} from "vuex";
    export default {
        name: "InterfaceData",
        data () {
            return {
                columns: [],
                showHeader: false,
                showDetail: false,
                tagGroupName: '',
                editInfo: {},
                id: 0,
                modalTableData: [],
                modalTableValue: '',
                modalInterfaceData: [],
                modalInterfaceValue: '',
                modalColumnValue: '',
                modalColumnData: [],
                extraColumnData: [],
                formItemLayoutWithOutLabel:{
                    wrapperCol: {
                        sm: { span: 15, offset: 6 }
                    }
                },
                interfaceValue: '',
                interfaceData: [{
                    interfaceId: 0,
                    interfaceName: '手机号码归属地',
                    interfaceArr: [
                        {name: '手机号', value: 'mobile'},
                        {name: '省份', value: 'prov'},
                        {name: '运营商', value: 'name'},
                        {name: '城市', value: 'city'}]
                }, {
                    interfaceId: 1,
                    interfaceName: '手机号码在网时长',
                    interfaceArr: [{name: '在网时长', value: 'time'}, {name: '手机号', value: 'mobile'}]
                }, {
                    interfaceId: 2,
                    interfaceName: '手机号码空号检测服务',
                    interfaceArr: [{name: '手机号', value: 'mobile'}, {name: '手机号状态', value: 'status'}]
                }, {
                    interfaceId: 3,
                    interfaceName: '身份证号码查询',
                    interfaceArr: [{name: '身份证号', value: 'idcard'},
                        {name: '发证地区', value: 'area'},
                        {name: '出生日期', value: 'birth'},
                        {name: '性别', value: 'sex'}]
                }, {
                    interfaceId: 4,
                    interfaceName: '手机实名认证',
                    interfaceArr: [{name: '身份证号', value: 'idcard'},
                        {name: '手机号', value: 'mobile'},
                        {name: '姓名', value: 'name'},
                        {name: '验证结果', value: 'description'}]
                }, {
                    interfaceId: 5,
                    interfaceName: '手机号码标记查询',
                    interfaceArr: [{name: '手机号', value: 'mobile'}, {name: '标记名称', value: 'blackMsg'}]
                }],
                modalForm:[],
                selectFormValue: [],
                detailDataSource: [],
                defaultColumns: [{
                    name: 'id',
                    title: '主键ID'
                }, {
                    name: 'tableId',
                    title: '表名称',
                    scopedSlots: true
                }, {
                    name: 'interfaceId',
                    title: '接口名称',
                    scopedSlots: true
                }, {
                    name: 'templateName',
                    title: '模板名称'
                }, {
                    name: 'templateData',
                    title: '模板数据',
                    scopedSlots: true
                }],
                options: [{
                    value: 'id',
                    label: '主键ID'
                }, {
                    value: 'tableId',
                    label: '表名称'
                }, {
                    value: 'interfaceId',
                    label: '接口名称'
                }, {
                    value: 'templateName',
                    label: '模板名称'
                }, {
                    value: 'templateData',
                    label: '模板数据'
                }],
                showColumns: [],
                dataSource: [],
                initLoading: false,
                tableValue: '',
                selectValue: [],
                tableHeader: [],
                title: '数据模板管理',
                tableId: '',
                visible: false,
                confirmLoading: false,
                tableLoading: false,
                modalTitle: '新增数据模板',
                rowSelection: {},
                checkedHeader: [],
                form: this.$form.createForm(this, { name: 'dynamic_form_item' }),
                formItemLayout: {
                    labelCol: { span: 6 },
                    wrapperCol: { span: 15 }
                },
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize) {
                        this.pagination.pageSize = pageSize;
                    },
                    showQuickJumper: true,
                    showSizeChanger: false,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                selectedId: '',
                wordName: '',
                wordLoading: false
            }
        },
        methods: {
            getTableData () {
                this.tableLoading = true;
                reqFindAllTable({
                    hasCreate: true,
                    pageNumber: 1,
                    pageSize: 1000
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.selectValue = result;

                        this.getAllTemplate();
                    } else {
                        this.$message.error(message);
                    }
                    this.tableLoading = false;
                });
            },
            async getAllColumn () {
                const result_column = await reqFindAllColumn({
                    tableId: this.modalTableValue,
                    showColumn: true
                });
                const { code, result, message } = result_column.data;
                if (code === 20000){
                    this.modalColumnData = result;
                    this.extraColumnData = this.modalColumnData;
                    result.length > 0 ? this.modalColumnValue = result[0].id : this.modalColumnValue = undefined
                } else {
                    this.$message.error(message);
                }
            },
            changeValue (value) {
                this.tableValue = value;
            },
            changeInterface (value) {
                this.interfaceValue = value;
            },
            tableInit () {
                this.showColumns = this.defaultColumns;
                this.showColumns.map(( item ) => {
                    if (item.scopedSlots){
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name,
                            scopedSlots: { customRender: item.name }
                        });
                    } else {
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name
                        });
                    }
                    return item;
                });
                this.columns.push({
                    title: '操作',
                    scopedSlots: { customRender: 'operation' }
                });

                this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }
            },
            changeHeader () {
                this.modalTitle = '筛选表头';
                this.showHeader = true;
                this.visible = true;
            },
            editOperation (tagGroup) {
                this.modalTitle = '查看模板数据';
                this.detailDataSource = [];
                for(const item in JSON.parse(tagGroup)){
                    this.detailDataSource.push({
                        name: item,
                        value: JSON.parse(tagGroup)[item]
                    });
                }
                this.visible = true;
                this.showDetail = true;
            },
            deleteOperation (tagGroup) {
                Modal.confirm({
                    title: '删除模板',
                    content: '确定要删除 ' + tagGroup.templateName + ' 吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteTemplate({
                            id: tagGroup.id
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getTableData();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除模板',
                    content: '确定要批量删除这些模板吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteKey({
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getTableData();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            addTagGroup () {
                this.modalTitle = '新增模板';
                this.modalTableData = this.selectValue;
                this.modalTableValue = this.tableValue;
                this.modalInterfaceData = this.interfaceData;
                this.modalInterfaceValue = this.interfaceValue;
                this.getAllColumn();
                this.showHeader = false;
                this.visible = true;
            },
            showTable () {
                this.getAllTemplate();
            },
            showSearchForm () {

            },
            handleOk () {
                if (this.showHeader){
                    const okColumns = [];
                    this.showColumns.map( item => {
                        this.checkedHeader.map( cItem => {
                            if (cItem === item.name){
                                if (item.scopedSlots){
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name,
                                        scopedSlots: { customRender: item.name }
                                    });
                                } else {
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name
                                    });
                                }
                            }
                        });
                    });
                    okColumns.push({
                        title: '操作',
                        scopedSlots: { customRender: 'operation' }
                    });
                    this.columns = okColumns;
                    this.visible = false;
                } else if (this.showDetail){
                    this.visible = false;
                    const timer = setTimeout( () => {
                        this.showDetail = false;
                        clearTimeout(timer);
                    }, 300);
                }else {
                    this.form.validateFields(this.modalForm.map( item => item.value),(err, values) => {
                        if (err){
                            return false;
                        }
                        const validateArr = [];
                        let repeatFlag = false;
                        for(const item in values){
                            validateArr.push(values[item]);
                        }
                        validateArr.forEach( (item, index) => {
                            if (item === validateArr[index - 1]){
                                repeatFlag = true;
                                return false;
                            }
                        });
                        if (repeatFlag){
                            return this.$message.warning(this.modalForm.map( item => item.name).join(',') + '的值不能相同!');
                        }
                        this.form.validateFields((err, values) => {
                            if (err){
                                return false;
                            }
                            this.confirmLoading = true;
                            const templateData = {};
                            this.modalForm.map( item => {
                                for (const cItem in values){
                                    if (cItem === item.value){
                                        templateData[cItem] = values[cItem];
                                        delete values[cItem];
                                    }
                                }
                                return item;
                            });
                            values.templateData = JSON.stringify(templateData);
                            reqAddTemplate(values).then( res => {
                                const { code, message } =  res.data;
                                code === 20000 && this.$message.success('新增模板成功!') && this.getAllTemplate();
                                code !== 20000 && this.$message.error(message);
                                this.confirmLoading = false;
                                this.visible = false;
                            })
                        });
                    })
                }
            },
            handleCancel () {
                  this.visible = false;
                  this.showDetail = false;
                  const timer = setTimeout(() => {
                      this.modalForm = [];
                      clearTimeout(timer);
                  }, 300);
            },
           async getAllTemplate () {
                this.initLoading = true;
               const template = await reqAllTemplate({
                   interfaceId: this.interfaceValue,
                   tableId: this.tableValue
               });
               const { code, result, message } = template.data;
               if (code === 20000){
                   this.dataSource = result.data;
                   this.pagination.total = result.total;
               } else {
                   this.$message.error(message);
               }
               this.initLoading = false;
            },
            async tableChange (value) {
                this.modalTableValue = value;
                this.getAllColumn();
            },
            interfaceChange (value) {
                this.modalInterfaceValue = value;
                this.modalForm = this.interfaceData.filter( item => item.interfaceId === value)[0].interfaceArr;
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.showTable();
            },
        },
        computed: {
            ...mapState(['userInfo'])
        },
        components:{
            Title
        },
        mounted() {
            this.getTableData();
            this.tableInit();
            this.checkedHeader = this.options.map( item => item.value);
        }
    }
</script>

<style lang="less">
    #interface{
        .ant-checkbox-wrapper{
            margin-bottom: 0;
        }
    }
    .template-tag-group{
        .ant-input{
            background: #F7F9FA !important;
        }
        .ant-input:focus{
            background: #ffffff !important;
        }
        .ant-select-selection--single{
            background: #F7F9FA !important;
        }
        .ant-btn-dashed{
            margin: 0 117px !important;
            width: 295px;
        }
    }
    .ant-checkbox-group-item{
        width: 117px;
    }
    .ant-checkbox-wrapper{
        margin-bottom: 10px;
    }
    .tagGroup-modal{
        .ant-btn{
            margin-top: 20px;
        }
    }
    .personal-modal{
        .ant-modal-content{
            button:nth-child(1){
                display: none;
            }
            button:nth-child(2){
                margin-left: 0;
            }
            .ant-modal-body{
                padding-bottom: 10px;
            }
        }
    }
    .dynamic-delete-button {
        cursor: pointer;
        position: relative;
        top: 4px;
        font-size: 24px;
        color: #999;
        transition: all 0.3s;
    }
    .dynamic-delete-button:hover {
        color: #777;
    }
    .dynamic-delete-button[disabled] {
        cursor: not-allowed;
        opacity: 0.5;
    }
</style>