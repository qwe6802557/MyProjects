<template>
    <div id="interface">
        <div class="title-area">
            <Title :title="title"/>
            <a-button type="link" icon="arrow-left" @click="$router.go(-1)">返回数据表管理</a-button>
        </div>
        <div class="interface-content">
            <a-card title="接口分类">
                <a-card-grid v-for="item in interfaceData" :key="item.interfaceId" style="cursor: pointer;" @click="showModal(item.interfaceId)">
                    <a-row>
                        <a-col :span="12">
                            <img :src="item.interfaceImg" alt="接口图片" style="width: 100px; height: 100px;">
                        </a-col>
                        <a-col :span="8">
                            <h3 style="line-height: 100px">{{item.interfaceName}}</h3>
                        </a-col>
                    </a-row>
                </a-card-grid>
            </a-card>
        </div>
        <div class="interface-modal">
            <a-modal class="common-modal template-modal"
                    :visible="visible"
                    :title="'接口对接'"
                    :okText="'确定'"
                    :cancelText="'取消'"
                    :destroyOnClose="true"
                    :keyboard="true"
                    :maskClosable="false"
                     :confirmLoading="confirmLoading"
                    @ok="handleOk"
                    @cancel="handleCancel">
                <a-form :form="form">
                    <a-col :span="24">
                        <a-form-item label="表名称"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'tableId',
                                                              {
                                                                   rules: [
                                                                             {   required: true, message: '请选择表名称!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择表名称"
                                    @change="tableChange"
                                    :loading="tableLoading"
                            >
                                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">
                                    {{item.tableChineseName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="模板名称"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'templateId',
                                                              {
                                                                   rules: [
                                                                             {   required: true, message: '请选择模板名称!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择模板名称"
                                    :loading="tableLoading"
                            >
                                <a-select-option  v-for="item in templateData" :value="item.id" :key="item.id">
                                    {{item.templateName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="密钥名称"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'aliyunKeyId',
                                                              {
                                                                   rules: [
                                                                             {   required: true, message: '请选择密钥名称!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择密钥名称"
                            >
                                <a-select-option  v-for="item in keyData" :value="item.id" :key="item.id">
                                    {{item.keyName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                </a-form>
            </a-modal>
        </div>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import { reqFindAllTable} from "../../api/schema";
    import {reqAllKey, reqAllTemplate, reqInterfaceData} from "../../api/interface";
    import { mapState } from 'vuex';
    export default {
        name: "Interface",
        data () {
            return {
                title: '接口对接',
                interfaceId: '',
                interfaceData: [{
                    interfaceId: 0,
                    interfaceName: '手机号码归属地',
                    interfaceImg: require('@/public/images/phone-home.png'),
                    interfaceArr: [
                        {name: '手机号', value: 'mobile'},
                        {name: '省份', value: 'prov'},
                        {name: '运营商', value: 'name'},
                        {name: '城市', value: 'city'}]
                }, {
                    interfaceId: 1,
                    interfaceName: '手机号码在网时长',
                    interfaceImg: require('@/public/images/internet-time.png'),
                    interfaceArr: [{name: '在网时长', value: 'time'}, {name: '手机号', value: 'mobile'}]
                }, {
                    interfaceId: 2,
                    interfaceName: '手机号码空号检测服务',
                    interfaceImg: require('@/public/images/empty.png'),
                    interfaceArr: [{name: '手机号', value: 'mobile'}, {name: '手机号状态', value: 'mobile'}]
                }, {
                    interfaceId: 3,
                    interfaceName: '身份证号码查询',
                    interfaceImg: require('@/public/images/idCard.png'),
                    interfaceArr: [{name: '身份证号', value: 'idcard'},
                        {name: '发证地区', value: 'area'},
                        {name: '出生日期', value: 'birth'},
                        {name: '性别', value: 'sex'}]
                }, {
                    interfaceId: 4,
                    interfaceName: '手机实名认证',
                    interfaceImg: require('@/public/images/validate.png'),
                    interfaceArr: [{name: '身份证号', value: 'idcard'},
                        {name: '手机号', value: 'mobile'},
                        {name: '姓名', value: 'name'},
                        {name: '验证结果', value: 'description'}]
                }, {
                    interfaceId: 5,
                    interfaceName: '手机号码标记查询',
                    interfaceImg: require('@/public/images/target.png'),
                    interfaceArr: [{name: '手机号', value: 'mobile'}, {name: '标记名称', value: 'blackMsg'}]
                }],
                visible: false,
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 14 }
                },
                selectValue: [],
                tableValue: '',
                templateData: [],
                keyData: [],
                templateValue: '',
                tableLoading: false,
                confirmLoading: false
            }
        },
        methods: {
            tableChange (value) {
                this.tableValue = value;
                this.getAllTemplate();
            },
            getTableData () {
                this.tableLoading = true;
                reqFindAllTable({
                    hasCreate: true,
                    pageNumber: 1,
                    pageSize: 1000
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.selectValue = result;
                        this.tableValue = result[0].id;
                    } else {
                        this.$message.error(message);
                    }
                });
                this.tableLoading = false;
            },
            async getAllTemplate () {
                const template = await reqAllTemplate({
                    interfaceId: this.interfaceId,
                    tableId: this.tableValue
                });
                const { code, result, message } = template.data;
                if (code === 20000){
                    this.templateData = result.data;
                } else {
                    this.$message.error(message);
                }
                this.tableLoading = false;
            },
            getAllKey () {
                reqAllKey({
                    pageNumber: 1,
                    pageSize: 100000
                }).then( res => {
                        const { code, result, message } = res.data;
                        if (code === 20000){
                            this.keyData = result.data;
                        } else {
                            this.$message.error(message);
                        }
            })},
            showModal (id) {
                this.interfaceId = id;
                this.getTableData();
                this.visible = true;
            },
            handleOk () {
                this.form.validateFields((err, values) => {
                    if(err){
                        return false;
                    }
                    this.confirmLoading = true;
                    values.dataIds = this.$route.query.dataIds;
                    values.interfaceId = this.interfaceId;
                    reqInterfaceData(values).then( res => {
                        const { code, message } = res.data;
                        code === 20000 && this.$message.success('接口调用成功!');
                        code !== 20000 && this.$message.error(message);
                        this.confirmLoading = false;
                        this.visible = false;
                    });
                });
            },
            handleCancel () {
                this.visible = false;
            }
        },
        computed: {
          ...mapState(['userInfo'])
        },
        components:{
            Title
        },
        mounted() {
            this.getAllKey();
        }
    }
</script>

<style lang="less">
    .title-area{
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }
    .template-modal{
        .ant-input{
            background: #F7F9FA !important;
        }
        .ant-input:focus{
            background: #ffffff !important;
        }
        .ant-select-selection--single{
            background: #F7F9FA !important;
        }
        .ant-btn{
            margin-top: 20px;
        }
    }
</style>