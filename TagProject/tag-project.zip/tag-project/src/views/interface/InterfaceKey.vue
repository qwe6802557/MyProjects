<template>
    <div id="tag">
        <Title :title="title"/>
        <div class="button-area">
            <!--<a-button type="danger" icon="delete" @click="deleteMany">批量删除</a-button>-->
            <a-button icon="plus" @click="addTagGroup">新建密钥</a-button>
            <a-button type="primary" icon="pushpin" @click="changeHeader">筛选显示</a-button>
        </div>
        <a-spin :spinning="initLoading" tip="获取标签数据中...">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="pagination"
                     :rowSelection="rowSelection"
                     :rowKey="'id'"
                     @change="handleTableChange">
                <span slot="addTime" slot-scope="addTime">
                    {{$moment(addTime).format('YYYY-MM-DD hh:mm:ss')}}
                </span>
                <template slot="operation" slot-scope="text">
                    <a href="javascript:;" @click="editOperation(text)">编辑</a>
                    <a href="javascript:;" @click="deleteOperation(text)">删除</a>
                </template>
            </a-table>
        </a-spin>
        <a-modal :title="modalTitle"
                 v-model="visible"
                 @ok="handleOk"
                 :class="showHeader? ['common-modal', 'personal-modal'] : ['common-modal', 'tagGroup-modal']"
                 :destroyOnClose="true"
                 :keyboard="true"
                 :maskClosable="false"
                 :okText="'确认'"
                 :cancelText="'取消'"
                 :confirmLoading="confirmLoading">
            <div class="check-box-area" v-if="showHeader">
                <a-checkbox-group name="checkboxgroup"
                                  v-model="checkedHeader"
                                  :options="options">
                </a-checkbox-group>
            </div>
            <div class="add-tag-group" v-if="!showHeader">
                <a-form :form="form">
                    <a-col :span="24">
                        <a-form-item label="AppCode"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                             'appCode',
                                             {   initialValue: !!editInfo.appCode && editInfo.appCode || undefined,
                                                 rules: [
                                                 {   required: true, message: '请输入AppCode!' }] }
                                                ]"
                                     placeholder="请输入AppCode">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="AppKey"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                             'appKey',
                                             {   initialValue: !!editInfo.appKey && editInfo.appKey || undefined,
                                                 rules: [
                                                 {   required: true, message: '请输入AppKey!' }] }
                                                ]"
                                     placeholder="请输入AppKey">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="密匙名称"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                             'keyName',
                                             {   initialValue: !!editInfo.keyName && editInfo.keyName || undefined,
                                                 rules: [
                                                 {   required: true, message: '请输入密匙名称!' }] }
                                                ]"
                                     placeholder="请输入密匙名称">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="AppSecret"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                             'appSecret',
                                             {   initialValue: !!editInfo.appSecret && editInfo.appSecret || undefined,
                                                 rules: [
                                                 {   required: true, message: '请输入AppSecret!' }] }
                                                ]"
                                     placeholder="请输入AppSecret">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="备注"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                             'notes',
                                             {   initialValue: !!editInfo.notes && editInfo.notes || undefined }
                                                ]"
                                     placeholder="请输入备注">
                            </a-input>
                        </a-form-item>
                    </a-col>
                </a-form>
            </div>
        </a-modal>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import { reqAddKey, reqAllKey, reqUpdateKey, reqDeleteKey } from "../../api/interface";
    import { Modal } from 'ant-design-vue';
    export default {
        name: "InterfaceKey",
        data () {
            return {
                columns: [],
                showHeader: false,
                tagGroupName: '',
                editInfo: {},
                defaultColumns: [{
                    id: 1,
                    name: 'id',
                    title: '主键ID'
                }, {
                    id: 2,
                    name: 'appCode',
                    title: 'AppCode',
                }, {
                    id: 3,
                    name: 'appKey',
                    title: 'AppKey',
                }, {
                    id: 4,
                    name: 'appSecret',
                    title: 'AppSecret'
                },{
                    id: 4,
                    name: 'keyName',
                    title: '密钥名称'
                }, {
                    id: 5,
                    name: 'addTime',
                    title: '创建时间',
                    scopedSlots: true
                }, {
                    id: 6,
                    name: 'notes',
                    title: '备注'
                }],
                options: [  { label: '主键ID', value: 'id' },
                    { label: 'AppCode', value: 'appCode' },
                    { label: 'AppKey', value: 'appKey' },
                    { label: 'AppSecret', value: 'appSecret'},
                    { label: '密钥名称', value: 'keyName'},
                    { label: '创建时间', value: 'addTime' },
                    { label: '备注', value: 'notes' }],
                showColumns: [],
                dataSource: [],
                initLoading: false,
                tableValue: '',
                selectValue: [],
                tableHeader: [],
                title: '接口密钥管理',
                tableId: '',
                visible: false,
                confirmLoading: false,
                tableLoading: false,
                modalTitle: '新增密钥',
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize) {
                        this.pagination.pageSize = pageSize;
                    },
                    showQuickJumper: true,
                    showSizeChanger: false,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                rowSelection: {},
                checkedHeader: [],
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 6 },
                    wrapperCol: { span: 15 }
                },
                selectedId: '',
                wordName: '',
                wordLoading: false
            }
        },
        methods: {
            getTableData () {
                this.initLoading = true;
                reqAllKey({
                    pageNumber: this.pagination.current,
                    pageSize: this.pagination.pageSize
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.dataSource = result.data;
                        this.pagination.total = result.total;
                    } else {
                        this.$message.error(message);
                    }
                    this.initLoading = false;
                });
            },
            changeValue (value) {
                this.tableValue = value;
            },
            tableInit () {
                this.showColumns = this.defaultColumns;
                this.showColumns.map(( item ) => {
                    if (item.scopedSlots){
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name,
                            scopedSlots: { customRender: item.name }
                        });
                    } else {
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name
                        });
                    }
                    return item;
                });
                this.columns.push({
                    title: '操作',
                    scopedSlots: { customRender: 'operation' }
                });

                this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }
            },
            changeHeader () {
                this.modalTitle = '筛选表头';
                this.showHeader = true;
                this.visible = true;
            },
            editOperation (tagGroup) {
                this.modalTitle = '编辑密钥';
                this.editInfo = tagGroup;
                this.visible = true;
            },
            deleteOperation (tagGroup) {
                Modal.confirm({
                    title: '删除密钥',
                    content: '确定要删除 ' + tagGroup.keyName + ' 吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteKey({
                            id: tagGroup.id
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getTableData();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除密钥',
                    content: '确定要批量删除这些密钥吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteKey({
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getTableData();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            addTagGroup () {
                this.modalTitle = '新增密钥';
                this.editInfo = {};
                this.showHeader = false;
                this.visible = true;
            },
            showSearchForm () {

            },
            handleOk () {
                if (this.showHeader){
                    const okColumns = [];
                    this.showColumns.map( item => {
                        this.checkedHeader.map( cItem => {
                            if (cItem === item.name){
                                if (item.scopedSlots){
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name,
                                        scopedSlots: { customRender: item.name }
                                    });
                                } else {
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name
                                    });
                                }
                            }
                        });
                    });
                    okColumns.push({
                        title: '操作',
                        scopedSlots: { customRender: 'operation' }
                    });
                    this.columns = okColumns;
                    this.visible = false;
                } else {
                    this.form.validateFields( (err, values) => {
                        if (err){
                            return false;
                        }
                        this.confirmLoading = true;
                        if (this.editInfo.id){
                            values.id = this.editInfo.id;
                            reqUpdateKey(values).then( res => {
                                const { code } = res.data;
                                code === 20000 && this.$message.success('修改密钥成功!') && this.getTableData();
                                code !== 20000 && this.$message.error(res.data.message);
                                this.confirmLoading = false;
                                this.visible = false;
                                this.form.resetFields();
                            });
                        } else {
                            reqAddKey(values).then( res => {
                                const { code } = res.data;
                                code === 20000 && this.$message.success('新增密钥成功!') && this.getTableData();
                                code !== 20000 && this.$message.error(res.data.message);
                                this.confirmLoading = false;
                                this.visible = false;
                                this.form.resetFields();
                            });
                        }
                    })
                }
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.getTableData();
            },
        },
        components:{
            Title
        },
        mounted() {
            this.getTableData();
            this.tableInit();
            this.checkedHeader = this.options.map( item => item.value);
        }
    }
</script>

<style lang="less">
    .add-tag-group{
        .ant-input{
            background: #F7F9FA !important;
        }
        .ant-input:focus{
            background: #ffffff !important;
        }
        .ant-select-selection--single{
            background: #F7F9FA !important;
        }
    }
    .ant-checkbox-group-item{
        width: 117px;
    }
    .ant-checkbox-wrapper{
        margin-bottom: 10px;
    }
    .tagGroup-modal{
        .ant-btn{
            margin-top: 20px;
        }
    }
    .personal-modal{
        .ant-modal-content{
            button:nth-child(1){
                display: none;
            }
            button:nth-child(2){
                margin-left: 0;
            }
            .ant-modal-body{
                padding-bottom: 10px;
            }
        }
    }
</style>