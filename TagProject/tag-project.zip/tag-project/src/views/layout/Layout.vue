<template>
    <div class="admin">
        <Header/>
        <a-locale-provider :locale="locale">
            <div class="locale-components" :key="(!!locale).toString()">
                <div class="admin-side">
                    <div class="admin-left">
                        <LeftBar/>
                    </div>
                    <div class="admin-content">
                        <transition name="el-fade-in" mode="out-in">
                            <router-view/>
                        </transition>
                    </div>
                </div>
             </div>
        </a-locale-provider>
    </div>
</template>

<script>
    import Header from '@/components/header';
    import LeftBar from '@/components/leftBar';
    import { mapState, mapMutations } from 'vuex';
    import storeUntil from "@/untils/storeUntil";
    import { reqIsLogin } from "@/api/login";
    import zhCN from 'ant-design-vue/es/locale-provider/zh_CN';
    import moment from 'moment';
    import 'moment/locale/zh-cn';
    moment.locale('zh');

    export default {
        name: "Layout",
        data(){
            return {
                userMes:{},
                value:'',
                locale: null,
                zhCN,
            }
        },
        methods:{
            moment,
            isLogin (token) {
                reqIsLogin({
                    token,
                }).then( res => {
                    const { result } = res.data;
                    if (!result){
                        this.$message.destroy();
                        this.$message.error('登录状态变化,请重新登录!');
                        this.changeToken('');
                        storeUntil.delToken();
                        this.$router.push('/login');
                    } else {
                        this.changeUserInfo(result);
                    }
                })
            },
            changeLocale(e) {
                const localeValue = e.target.value;
                this.locale = localeValue;
                if (!localeValue) {
                    moment.locale('en');
                } else {
                    moment.locale('zh-cn');
                }
            },
            ...mapMutations(['changeToken', 'changeUserInfo'])
        },
        computed: {
            ...mapState(['token'])
        },
        updated() {
            document.querySelector('.admin-content').style.height=document.documentElement.clientHeight - 68 + 'px';
        },
        mounted(){
            document.querySelector('.admin-content').style.height=document.documentElement.clientHeight - 68 + 'px';
            !!this.token && this.isLogin(this.token);
        },
        components:{
            Header,
            LeftBar
        }
    }
</script>

<style scoped>


</style>
<style lang="less">
    .admin{
        min-width: 1600px;
        position: relative;
        .admin-side{
            display: flex;
            flex-direction: row;
        }
        .admin-left{
            text-align: left;
            .left-nav{
                .el-radio-button{
                    left: 194px;
                }
            }
        }
        .admin-content{
            flex: 1;
            background: #F4F6F9;
            padding: 20px;
            overflow-y: scroll;
            overflow-x: hidden;
        }
    }
</style>
