<template>
    <div id="schema">
        <Title :title="'权限管理'"/>
        <div class="button-area">
            <!--<a-button type="primary" icon="search" @click="this.showSearchForm">筛选</a-button>-->
            <!--<a-button type="danger" icon="delete">批量删除</a-button>-->
            <a-button icon="plus" @click="addSchema">新建用户</a-button>
        </div>
        <a-spin :spinning="spinning" :tip="tip">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="pagination"
                     :rowKey="'id'"
                     @change="handleTableChange"
                     >
                <template slot="operation" slot-scope="operation">
                    <a href="javascript:;" @click="editOperation(operation)">编辑</a>
                    <a href="javascript:;" @click="deleteOperation(operation)">删除</a>
                </template>
                <span slot="admin" slot-scope="admin">
                    <span :style="{ color: admin === true? '#10A54A' : 'red'}">{{admin === true && '已拥有' || '未拥有'}}</span>
                </span>
                <span slot="daoru" slot-scope="daoru">
                    <span :style="{ color: daoru === true? '#10A54A' : 'red'}">{{daoru === true && '已拥有' || '未拥有'}}</span>
                </span>
                <span slot="daochu" slot-scope="daochu">
                    <span :style="{ color: daochu === true? '#10A54A' : 'red'}">{{daochu === true && '已拥有' || '未拥有'}}</span>
                </span>
            </a-table>
        </a-spin>
        <!--<div class="form-drawer">
            <a-drawer :title="'筛选表单'"
                      :closable="false"
                      :visible="drawerVisible"
                      @close="this.drawerClose"
                      :drawerStyle="{background:'#F8FAFC'}"
                      :width="drawerWidth">
                <div class="form-content">
                    <SearchForm/>
                </div>
                <a-button type="primary" shape="round" class="confirm-button"  :loading="searchLoading">确定</a-button>
            </a-drawer>
        </div>-->
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import {reqDeleteUser, reqFindAllUsers} from "../../api/user";
    import {Modal} from "ant-design-vue";
/*    import SearchForm from "@/views/origin/schema/SearchForm";*/
    export default {
        name: "Authority",
        data () {
            return {
                columns: [],
                dataSource: [],
                selectValue: [],
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize) {
                        this.pagination.pageSize = pageSize;
                    },
                    showQuickJumper: true,
                    showSizeChanger: false,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                rowSelection: {},
                drawerWidth: '300',
                searchLoading: false,
                drawerVisible: false,
                spinning: false,
                tableValue: '',
                tip: '获取数据中...',
                tableLoading: false,
                addDisabled: false,
                selectedId: [],
            }
        },
        methods: {
            tableInit () {
                this.columns = [
                    {
                        title: '用户账号',
                        key: 'username',
                        dataIndex: 'username',
                    },
                    {
                        title: '管理权限',
                        key: 'admin',
                        dataIndex: 'admin',
                        scopedSlots: { customRender: 'admin' }
                    },
                    {
                        title: '导入权限',
                        key: 'daoru',
                        dataIndex: 'daoru',
                        scopedSlots: { customRender: 'daoru' }
                    },
                    {
                        title: '导出权限',
                        key: 'daochu',
                        dataIndex: 'daochu',
                        scopedSlots: { customRender: 'daochu' }
                    },
                    {
                        title: '操作',
                        scopedSlots: { customRender: 'operation' }
                    },
                ];
                /*this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }*/
            },
            addSchema () {
                this.$router.push({ path: '/auth/addOrEditUser'});
            },
            drawerClose () {
                this.drawerVisible = false;
            },
            getAllUsers () {
                this.spinning = true;
                reqFindAllUsers({
                    pageNumber: this.pagination.current,
                    pageSize: this.pagination.pageSize
                }).then( res => {
                    const { code, message, result } = res.data;
                    if (code === 20000){
                        this.dataSource = result.data;
                        this.pagination.total = result.total;
                    } else {
                        this.$message.error(message);
                    }
                    this.spinning = false;
                });
            },
            deleteOperation (row) {
                Modal.confirm({
                    title: '删除用户',
                    content: '确定要删除该用户吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteUser({
                            userId: row.id
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllUsers();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            /*deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除字段',
                    content: '确定要批量删除这些字段吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteColumn({
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllTable();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },*/
            /*changeValue (value) {
                this.tableValue = value;
            },*/
            editOperation (row) {
                this.$router.push({ path: '/auth/addOrEditUser', query: row })
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.getAllUsers();
            },
        },
        components: {
            Title,
            /* SearchForm*/
        },
        mounted() {
            this.tableInit();
            this.getAllUsers();
        }
    }
</script>

<style lang="less">
    #schema{
        .button-area{
            text-align: left;
            padding-bottom: 3px;
        }
        .ant-btn{
            margin-right: 10px;
        }
    }
</style>