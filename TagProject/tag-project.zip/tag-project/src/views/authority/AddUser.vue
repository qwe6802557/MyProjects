<template>
    <div id="add-form">
        <Title :title="'新增字段'"/>
        <div class="container">
            <div class="add-title">
                <i class="title-icon"/>
                基本信息
            </div>
            <a-form :form="form" style="width: 60%; overflow: hidden;">
                <a-col :span="12">
                    <a-form-item label="用户名"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-input v-decorator="[
                                         'username',
                                         {
                                             initialValue: $route.query && $route.query.username || undefined,
                                             rules: [{ required: true, message: '请输入用户名!' }]
                                         }
                                            ]"
                                 placeholder="请输入用户名">
                        </a-input>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item label="密码"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-input v-decorator="[
                                         'password',
                                         {
                                             initialValue: $route.query.username && defaultValue || undefined,
                                             rules: [{ required: true, message: '请输入密码!' }]
                                         }
                                            ]"
                                 placeholder="请输入密码" :disabled="disabled" type="password">
                        </a-input>
                        <a-button type="link" icon="redo" @click="reset" v-if="$route.query.username" style="position:absolute;top: -8px;">重置密码</a-button>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item label="确认密码"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-input v-decorator="[
                                         'confirmPassword',
                                         {
                                             initialValue: $route.query.username && defaultValue || undefined,
                                             rules: [{ required: true, message: '请输入确认密码!' }, {
                                                 validator: checkPass
                                             }]
                                         }
                                            ]"
                                 type="password"
                                 placeholder="请输入确认密码" :disabled="disabled">
                        </a-input>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item label="是否拥有管理权限"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-select v-decorator="[
                                             'admin',
                                             {   initialValue: $route.query.admin && String(Number($route.query.admin)) || '0',
                                                 rules: [{ required: true, message: '请选择是否拥有管理权限!' }] }
                                                ]"
                                  placeholder="请选择是否拥有管理权限">
                            <a-select-option value="1">
                                是
                            </a-select-option>
                            <a-select-option value="0">
                                否
                            </a-select-option>
                        </a-select>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item label="是否拥有导入权限"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-select v-decorator="[
                                             'daoru',
                                             {   initialValue: $route.query.daoru && String(Number($route.query.daoru)) || '0',
                                                 rules: [{ required: true, message: '请选择是否拥有导入权限!' }] }
                                                ]"
                                  placeholder="请选择是否拥有导入权限">
                            <a-select-option value="1">
                                是
                            </a-select-option>
                            <a-select-option value="0">
                                否
                            </a-select-option>
                        </a-select>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item label="是否拥有导出权限"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-select v-decorator="[
                                             'daochu',
                                             {   initialValue: $route.query.daochu && String(Number($route.query.daochu)) || '0',
                                                 rules: [{ required: true, message: '请选择是否拥有导出权限!' }] }
                                                ]"
                                  placeholder="请选择是否拥有导出权限">
                            <a-select-option value="1">
                                是
                            </a-select-option>
                            <a-select-option value="0">
                                否
                            </a-select-option>
                        </a-select>
                    </a-form-item>
                </a-col>
            </a-form>
        </div>
        <div class="modal-button">
            <a-button shape="round" type="primary" id="cancelButton" @click="cancel">取消</a-button>
            <a-button shape="round" type="primary" id="okButton" @click="confirm" :loading="confirmLoading">确定</a-button>
        </div>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import { reqAddUser, reqUpdateUser} from "../../api/user";
    export default {
        name: "AddUser",
        data () {
            return {
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 12 }
                },
                showIndex: false,
                dataType: [],
                dataTypeLoading: false,
                confirmLoading: false,
                disabled: false,
                defaultValue: '密码不可见, 需要修改请点击下方'
            }
        },
        methods: {
            cancel () {
                this.$router.go(-1);
            },
            checkPass(rule, value, callback) {
                const form = this.form;
                if (value && value !== form.getFieldValue('password')) {
                    callback('两次密码输入不一致!');
                } else {
                    callback();
                }
            },
            confirm () {
                this.confirmLoading = true;
                this.form.validateFields( (err , values) => {
                    if (err) {
                        this.confirmLoading = false;
                        return false;
                    }
                    values.admin = !!Number(values.admin);
                    values.daoru = !!Number(values.daoru);
                    values.daochu = !!Number(values.daochu);
                    if (!this.$route.query.username){
                        reqAddUser(values).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.$router.push('/auth/authority');
                            code !== 20000 && this.$message.error(message);
                            this.confirmLoading = false;
                        })
                    } else {
                        values.id = this.$route.query.id;
                        delete values.password;
                        reqUpdateUser(values).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.$router.push('/auth/authority');
                            code !== 20000 && this.$message.error(message);
                            this.confirmLoading = false;
                        })
                    }
                })
            },
            reset () {
                this.defaultValue = '';
                this.disabled = false;
            }
        },
        components: {
            Title
        },
        mounted() {
            if (this.$route.query.username){
                this.disabled = true;
            }
        }
    }
</script>

<style scoped>

</style>