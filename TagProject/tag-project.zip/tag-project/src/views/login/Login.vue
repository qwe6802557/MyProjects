<template>
    <a-spin tip="检测登录状态中..." :spinning="spinning">
    <div id="login">
            <div class="login-center center-width">
                <div class="center-right">
                    <h1>用户登录</h1>
                    <span>USER &nbsp;&nbsp;LOGIN</span>
                    <a-form layout="horizontal" :form="form">
                        <a-form-item>
                            <a-input v-decorator="[
                                              'username',
                                              { rules: [{ required: true, message: '请输入用户名' }] }
                                            ]"
                                     placeholder="请输入用户名">
                                <a-icon
                                        slot="prefix"
                                        type="user"
                                        style="color: rgba(0,0,0,.25)"
                                />
                            </a-input>
                        </a-form-item>
                        <a-form-item>
                            <a-input v-decorator="[
                                              'password',
                                              { rules: [{ required: true, message: '请输入密码!' }] }
                                            ]"
                                     placeholder="请输入密码">
                                <a-icon
                                        slot="prefix"
                                        type="lock"
                                        style="color: rgba(0,0,0,.25)"
                                />
                            </a-input>
                        </a-form-item>
                        <a-form-item>
                            <a-input v-decorator="[
                                              'code',
                                              { rules: [{ required: true, message: '请输入验证码!' }] }
                                            ]"
                                     placeholder="请输入验证码">
                                <a-icon
                                        slot="prefix"
                                        type="safety-certificate"
                                        style="color: rgba(0,0,0,.25)"
                                />
                            </a-input>
                            <div id="validate" @click="getValidateCode">
                                <img :src="validateImg" alt="验证码">
                            </div>
                        </a-form-item>
                        <a-form-item>
                            <a-button type="primary" htmlType="submit" class="login-form-button" :loading="loading" @click="this.login">
                                登录
                            </a-button>
                            <!--<div class="register">
                                还没有账号?<span @click="this.toRegister">立即注册</span>
                            </div>-->
                        </a-form-item>
                    </a-form>
                </div>
            </div>
    </div>
    </a-spin>
</template>

<script>
    import { reqGetValidateId, reqGetValidateImg, reqLogin } from "@/api/login";
    import { message } from 'ant-design-vue';
    import { mapMutations } from 'vuex';
    import storeUntil from "@/untils/storeUntil";
    import {reqIsLogin} from "../../api/login";
    export default {
        name: "Login",
        data () {
            return {
                loading: false,
                form: this.$form.createForm(this),
                validateCode: '',
                validateImg: '',
                codeId: '',
                spinning: false
            }
        },
        methods: {
            getValidateCode () {
                reqGetValidateId().then( res => {
                    const { code, result } = res.data;
                    if (code === 20000){
                        this.codeId = result;
                        reqGetValidateImg(result).then( res => {
                            this.validateImg = 'data:image/png;base64,' + btoa(
                                new Uint8Array(res.data).reduce((data, byte) => data + String.fromCharCode(byte), ''))
                        })
                    }
                    code !== 20000 && message.warning(res.data.message) && this.getValidateCode();
                })
            },
            login () {
                this.loading = true;
                this.form.validateFields( (err, values) => {
                    if (err){
                        this.loading = false;
                        return false;
                    }
                    values.codeId = this.codeId;
                    reqLogin(values).then( res => {
                        const { code, result } = res.data;
                        if (code === 20000) {
                            message.success('登录成功!');
                            storeUntil.setToken(result.password);
                            this.changeUserInfo(result);
                            this.changeToken(result.password);
                            this.$router.push({ path: '/auth'});
                        }
                        code !== 20000 && message.error(res.data.message) && this.getValidateCode();
                        this.loading = false;
                    })
                });
            },
            async validateLogin () {
                this.spinning = true;
                const result = await reqIsLogin({
                    token: storeUntil.getToken()
                });
                const { code } = result.data;
                if (code === 20000){
                    this.$router.push('/auth/home');
                } else {
                    storeUntil.delToken();
                    this.changeToken('');
                }
                this.spinning = false;
            },
            ...mapMutations([
                'changeUserInfo',
                'changeToken'
            ])
        },
        mounted() {
            document.querySelector('#login').style.height = document.documentElement.clientHeight + 'px';
            this.getValidateCode();
            if (this.$store.state.token){
                this.validateLogin();
            }
        }
    }
</script>

<style lang="less" scoped >
    #login{
        background: url("../../public/images/login-bg.png") no-repeat;
        background-size: cover;
        min-width: 1200px;
        /deep/ .ant-btn{
            span{
                font-size: 16px;
            }
        }
    .center-width{
        width: 1400px;
        margin: 0 auto;
        padding-right: 0px;
    }
    .login-center{
        padding-top: 250px;
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
    .center-right{
        width: 400px;
        height: 400px;
        text-align: left;
    h1{
        font-size: 24px;
        color: #4452D5;
        font-weight: normal;
    }
    span{
        font-size: 14px;
        color: #B5B5B5;
    }
    .ant-input{
        width: 300px;
        height: 40px;
    }
    span{
        color:#B5B5B5;
    }
    /deep/ .ant-btn{
        width: 300px;
        height: 40px;
        margin-top: 5px;
    span{
        font-size: 17px;
        color: white;
    }
    }
        /deep/ .ant-form-item{
        margin-top: 25px;
    input{
        padding-left: 40px;
    }
    }
        /deep/ .ant-form-item:first-child{
        margin-top: 25px;
    }
        /deep/ .ant-form-item:nth-child(2){
        margin-bottom: 25px;
    }
        /deep/.ant-form-item:nth-child(3){
        margin-top: 0;
    input{
        width: 170px;
    }
    }
    .register{
        margin-top: 0px;
    span{
        color: #1C93FF;
        cursor: pointer;
        margin-left: 5px;
    &:hover{
         text-decoration: underline;
     }
    }
    }
    .has-success{
        line-height: 0px;
    }
        /deep/ .ant-input-affix-wrapper{
        width: 300px;
        height: 40px;
    }
        /deep/ .ant-form-item{
            &:nth-child(3){
                margin-bottom: 18px;
                .ant-input-affix-wrapper{
                    width: 150px;
                    height: 40px;
                }
            }
            &:nth-child(4){
                margin-top: 0;
            }
        }
    #validate{
        height: 40px;
        width: 113px;
        position: absolute;
        top: -13px;
        left: 122%;
        cursor: pointer;
        img{
            width: 100%;
            height: 100%;
        }
    }
    }
    /deep/ .ant-input-prefix{
        font-size: 16px !important;
        left: 10px;
    }
    }
    }

</style>