<template>
    <div id="tag">
        <Title :title="title"/>
        <div class="button-area">
            <!--<span style="margin-right: 5px;">字段名:</span>
            <a-select :value="tableValue" style="width: 120px;margin-right: 10px;" @change="changeValue" :loading="tableLoading">
                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">{{item.tableColumnChineseName}}</a-select-option>
            </a-select>
            <a-button type="primary" icon="search" @click="showTable">查看</a-button>-->
            <a-button type="danger" icon="delete" @click="deleteMany" v-if="userInfo.admin">批量删除</a-button>
            <a-button icon="plus" @click="addTagGroup">新建标签</a-button>
            <a-button type="primary" icon="pushpin" @click="changeHeader">筛选显示</a-button>
            <a-button type="dashed" icon="left" style="float: right;margin-right: 0;" @click="$router.go(-1)">返回标签组管理</a-button>
        </div>
        <a-spin :spinning="initLoading" tip="获取标签数据中...">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="pagination"
                     :rowSelection="rowSelection"
                     :rowKey="'id'"
                     @change="handleTableChange">
                <span slot="tagGroupId" slot-scope="tagGroupId">
                    {{!!tagGroupValue.filter( item => item.id === tagGroupId )[0] && tagGroupValue.filter( item => item.id === tagGroupId )[0].tagGroupName || '-'}}
                </span>
                <span slot="tableColumnId" slot-scope="tableColumnId">
                    {{!!selectValue.filter( item => item.id === tableColumnId )[0] && selectValue.filter( item => item.id === tableColumnId )[0].tableColumnChineseName || '-'}}
                </span>
                <template slot="operation" slot-scope="text">
                    <a href="javascript:;" @click="editOperation(text)" v-if="userInfo.admin">编辑</a>
                    <a href="javascript:;" @click="deleteOperation(text)" v-if="userInfo.admin">删除</a>
                </template>
            </a-table>
        </a-spin>
        <a-modal :title="modalTitle"
                 v-model="visible"
                 @ok="handleOk"
                 :class="showHeader? ['common-modal', 'personal-modal'] : ['common-modal', 'tagGroup-modal']"
                 :destroyOnClose="true"
                 :keyboard="true"
                 :maskClosable="false"
                 :okText="'确认'"
                 :cancelText="'取消'"
                 :closable="!showHeader"
                 :confirmLoading="confirmLoading">
            <div class="check-box-area" v-if="showHeader">
                <a-checkbox-group name="checkboxgroup"
                                  v-model="checkedHeader"
                                  :options="options">
                </a-checkbox-group>
            </div>
            <div class="add-tag-group" v-if="!showHeader">
                <a-form :form="form">
                    <!--<a-col :span="24">
                        <a-form-item label="所属标签组"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'tagGroupId',
                                                              {    initialValue: Number(tagGroupId) || undefined,
                                                                   rules: [
                                                                             {   required: true, message: '请选择所属标签组!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择所属标签组"
                                    :disabled="true"
                            >
                                <a-select-option  v-for="item in tagGroupValue" :value="item.id" :key="item.id">
                                    {{item.tagGroupName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>-->
                    <!--<a-col :span="24">
                        <a-form-item label="所属字段"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'tableColumnId',
                                                              {    initialValue: editInfo.tableColumnId || undefined,
                                                                   rules: [
                                                                             {   required: true, message: '请选择所属字段!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择所属字段"
                                    @change="this.typeChange"
                                    :loading="typeLoading"
                            >
                                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">
                                    {{item.tableColumnChineseName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                </a-col>-->
                <a-col :span="24">
                    <a-form-item label="标签名称"
                                 :label-col="formItemLayout.labelCol"
                                 :wrapper-col="formItemLayout.wrapperCol">
                        <a-input v-decorator="[
                                         'tagName',
                                         {   initialValue: editInfo.tagName || undefined,
                                             rules: [
                                             {   validator: checkTag }] }
                                            ]"
                                 placeholder="请输入标签名称">
                        </a-input>
                    </a-form-item>
                </a-col>
                </a-form>
            </div>
        </a-modal>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import {
         reqAllTag
        /*reqTagGroupList*/, reqAddTag, reqUpdateTag, reqDeleteTag
    } from "../../api/tag";
    import { Modal } from 'ant-design-vue';
    import {reqFindTableColumn, reqQueryDataType} from "../../api/schema";
    import { mapState } from 'vuex';
   /* import {reqFindAllColumn} from "../../api/schema";*/
    export default {
        name: "Tag",
        data () {
            return {
                columns: [],
                showHeader: false,
                tagGroupName: '',
                tagGroupValue: '',
                editInfo: {
                    tagName: '',
                    tableColumnId: '',
                    id: ''
                },
                defaultColumns: [{
                    id: 1,
                    name: 'id',
                    title: '主键ID'
                },/* {
                    id: 2,
                    name: 'tableColumnId',
                    title: '所属字段',
                    scopedSlots: true
                },*/ /*{
                    id: 2,
                    name: 'tagGroupId',
                    title: '所属标签组',
                    scopedSlots: true
                },*/ {
                    id: 3,
                    name: 'tagName',
                    title: '标签名称'
                }],
                options: [  { label: '主键ID', value: 'id' },
                   /* { label: '所属字段', value: 'tableColumnId' },*/
                   /* { label: '所属标签组', value: 'tagGroupId' },*/
                    { label: '标签名称', value: 'tagName' }],
                showColumns: [],
                dataSource: [],
                initLoading: false,
                tableValue: '',
                selectValue: [],
                tableHeader: [],
                title: '标签管理',
                tableId: '',
                visible: false,
                confirmLoading: false,
                tableLoading: false,
                modalTitle: '新增标签',
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize) {
                        this.pagination.pageSize = pageSize;
                    },
                    showQuickJumper: true,
                    showSizeChanger: false,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                rowSelection: {},
                checkedHeader: [],
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 14 }
                },
                selectedId: '',
                wordName: '',
                wordLoading: false,
                tagGroupId: this.$route.params.tagGroupId,
                typeValue: '',
                columnId: '',
                typeLoading: false
            }
        },
        methods: {
            getTableData () {
                this.initLoading = true;
                reqAllTag({
                    tagGroupId: this.tagGroupId,
                    tableColumnId: this.tableValue,
                    pageNumber: this.pagination.current,
                    pageSize: this.pagination.pageSize,
                    hasPage: true,
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.dataSource = result.data;
                        this.pagination.total = result.total;
                    } else {
                        this.$message.error(message);
                    }
                    this.initLoading = false;
                })
            },
            getAllColumn () {
                this.tableLoading = true;
                reqFindTableColumn({
                    tableId: this.$route.params.tableId
                }).then( res => {
                    const { code, message, result } = res.data;
                    if (code === 20000){
                        this.selectValue = result;
                        if (this.selectValue.length > 0){
                            this.tableValue = this.selectValue[0].id;
                        }
                        this.getTableData();
                    } else {
                        this.$message.error(message);
                    }
                    this.tableLoading = false;
                });
            },
            getAllTagGroup () {
                /*reqTagGroupList().then( res => {
                   const { code, result, message } = res.data;
                   if (code === 20000){
                       this.tagGroupValue = result;
                   } else {
                       this.$message.error(message);
                   }
                });*/
            },
            typeChange (value) {
                this.columnId = value;
                /*this.getDataType();*/
            },
            changeValue (value) {
                this.tableValue = value;
            },
            tableInit () {
                this.showColumns = this.defaultColumns;
                this.showColumns.map(( item ) => {
                    if (item.scopedSlots){
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name,
                            scopedSlots: { customRender: item.name }
                        });
                    } else {
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name
                        });
                    }
                    return item;
                });
                this.columns.push({
                    title: '操作',
                    scopedSlots: { customRender: 'operation' }
                });

                this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }
            },
            changeHeader () {
                this.modalTitle = '筛选表头';
                this.showHeader = true;
                this.visible = true;
            },
            editOperation (tagGroup) {
                this.modalTitle = '编辑标签';
                this.editInfo.tagName = tagGroup.tagName;
                this.editInfo.tableColumnId = tagGroup.tableColumnId;
                this.editInfo.id = tagGroup.id;
                this.columnId = tagGroup.tableColumnId;
                this.visible = true;
                /*this.getDataType();*/
            },
            deleteOperation (tag) {
                Modal.confirm({
                    title: '删除标签',
                    content: '确定要删除 ' + tag.tagName + ' 吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteTag({
                            ids: [tag.id]
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getTableData();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除标签',
                    content: '确定要批量删除这些标签吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteTag({
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getTableData();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            addTagGroup () {
                this.modalTitle = '新增标签';
                this.editInfo.tagName = '';
                this.editInfo.tableColumnId = '';
                this.editInfo.id = '';
                this.typeValue = '';
                this.columnId = '';
                this.showHeader = false;
                this.visible = true;
            },
            showSearchForm () {

            },
            async getDataType () {
                this.typeLoading = true;
                const result_column = await reqQueryDataType({
                    tableColumnId: this.columnId
                });
                const { code, result, message } = result_column.data;
                if (code === 20000){
                    this.typeValue = result.dataType;
                } else {
                    this.$message.error(message);
                }
                this.typeLoading = false;
            },
            checkTag (rule, value, callback) {
                if (!value){
                    return callback('标签名称不能为空!')
                } else {
                    if ((this.typeValue === 2 || this.typeValue === 3) && !Number(value)){
                        callback('该字段只能填写数字类型');
                    } else {
                        callback();
                    }
                }
            },
            showTable () {
                this.getTableData();
            },
            handleOk () {
                if (this.showHeader){
                    const okColumns = [];
                    this.showColumns.map( item => {
                        this.checkedHeader.map( cItem => {
                            if (cItem === item.name){
                                if (item.scopedSlots){
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name,
                                        scopedSlots: { customRender: item.name }
                                    });
                                } else {
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name
                                    });
                                }
                            }
                        });
                    });
                    okColumns.push({
                        title: '操作',
                        scopedSlots: { customRender: 'operation' }
                    });
                    this.columns = okColumns;
                    this.visible = false;
                } else {
                    this.form.validateFields( (err, values) => {
                        if (err){
                            return false;
                        }
                        this.confirmLoading = true;
                        values.tagGroupId = this.$route.params.tagGroupId;
                        if (this.editInfo.id){
                            values.id = this.editInfo.id;
                            reqUpdateTag(values).then( res => {
                                const { code } = res.data;
                                code === 20000 && this.$message.success('修改标签成功!') && this.getTableData();
                                code !== 20000 && this.$message.error(res.data.message);
                                this.confirmLoading = false;
                                this.visible = false;
                                this.form.resetFields();
                            });
                        } else {
                            reqAddTag(values).then( res => {
                                const { code } = res.data;
                                code === 20000 && this.$message.success('新增标签成功!') && this.getTableData();
                                code !== 20000 && this.$message.error(res.data.message);
                                this.confirmLoading = false;
                                this.visible = false;
                                this.form.resetFields();
                            });
                        }
                    })
                }
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.showTable();
            },
        },
        computed: {
            ...mapState(['userInfo'])
        },
        components:{
            Title
        },
        mounted() {
            /*this.getTableData();*/
            this.tableInit();
            this.getAllColumn();
            this.getAllTagGroup();
            this.checkedHeader = this.options.map( item => item.value);
        }
    }
</script>

<style lang="less">
    .add-tag-group{
        .ant-input{
            background: #F7F9FA !important;
        }
        .ant-input:focus{
            background: #ffffff !important;
        }
        .ant-select-selection--single{
            background: #F7F9FA !important;
        }
    }
     .ant-checkbox-group-item{
         white-space: nowrap;
         text-overflow:ellipsis;
         overflow: hidden;
    }
    .ant-checkbox-wrapper{
        margin-bottom: 10px;
    }
    .tagGroup-modal{
        .ant-btn{
            margin-top: 20px;
        }
    }
    .personal-modal{
        .ant-modal-content{
            button:nth-child(1){
                display: none;
            }
            button:nth-child(2){
                margin-left: 0;
            }
            .ant-modal-body{
                padding-bottom: 10px;
            }
        }
    }
</style>