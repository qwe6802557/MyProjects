<template>
    <div id="home">
        <div class="first-part">
            <div id="province">
                <div class="choose-area">
                    <Title :title="'省份分布图'" :hasTriangle="true" />
                        <div class="select-area">
                            <a-select :value="tableValue1" @change="tableChange1" style="margin-right: 15px">
                                <a-select-option v-for="item in selectValue1" :key="item.id" :value="item.id">
                                    {{item.tableChineseName}}
                                </a-select-option>
                            </a-select>
                            <a-select :value="columnValue1" @change="columnChange1" style="margin-right: 15px">
                                <a-select-option v-for="item in columnData1" :key="item.id" :value="item.id">
                                    {{item.tableColumnChineseName}}
                                </a-select-option>
                            </a-select>
                            <a-button icon="search" type="primary" style="margin-right: 15px" @click="countMap1">统计</a-button>
                        </div>
                </div>
                <a-spin tip="获取省份分布图数据中..." :spinning="spinning1">
                    <div id="province-map">

                    </div>
                </a-spin>
            </div>
            <div id="merchant">
                <div class="choose-area">
                    <Title :title="'运营商分布图'" :hasTriangle="true" />
                    <div class="select-area">
                        <a-select :value="tableValue2" @change="tableChange2" style="margin-right: 15px">
                            <a-select-option v-for="item in selectValue2" :key="item.id" :value="item.id">
                                {{item.tableChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-select :value="columnValue2" @change="columnChange2" style="margin-right: 15px">
                            <a-select-option v-for="item in columnData2" :key="item.id" :value="item.id">
                                {{item.tableColumnChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-button icon="search" type="primary" style="margin-right: 15px" @click="countMap2">统计</a-button>
                    </div>
                </div>
                <a-spin tip="获取运营商分布图数据中..." :spinning="spinning2">
                    <div id="merchant-map">
                    </div>
                </a-spin>
            </div>
        </div>
        <div class="second-part">
            <div id="city">
                <div class="choose-area">
                    <Title :title="'城市分布图'" :hasTriangle="true" />
                    <div class="select-area">
                        <a-select :value="tableValue3" @change="tableChange3" style="margin-right: 15px">
                            <a-select-option v-for="item in selectValue3" :key="item.id" :value="item.id">
                                {{item.tableChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-select :value="columnValue3" @change="columnChange3" style="margin-right: 15px">
                            <a-select-option v-for="item in columnData3" :key="item.id" :value="item.id">
                                {{item.tableColumnChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-button icon="search" type="primary" style="margin-right: 15px" @click="countMap3">统计</a-button>
                    </div>
                </div>
                <a-spin tip="获取城市分布图数据中..." :spinning="spinning3">
                    <div id="city-map">
                    </div>
                </a-spin>
            </div>
            <div id="count">
                <div class="choose-area">
                    <Title :title="'出现次数分布图'" :hasTriangle="true" />
                    <div class="select-area">
                        <a-select :value="tableValue4" @change="tableChange4" style="margin-right: 15px">
                            <a-select-option v-for="item in selectValue4" :key="item.id" :value="item.id">
                                {{item.tableChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-select :value="columnValue4" @change="columnChange4" style="margin-right: 15px">
                            <a-select-option v-for="item in columnData4" :key="item.id" :value="item.id">
                                {{item.tableColumnChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-button icon="search" type="primary" style="margin-right: 15px" @click="countMap4">统计</a-button>
                    </div>
                </div>
                <a-spin tip="获取出现次数分布图数据中..." :spinning="spinning4">
                    <div id="count-map">
                    </div>
                </a-spin>
            </div>
        </div>
        <div class="third-part">
            <div id="type">
                <div class="choose-area">
                    <Title :title="'型号分布图'" :hasTriangle="true" />
                    <div class="select-area">
                        <a-select :value="tableValue5" @change="tableChange5" style="margin-right: 15px">
                            <a-select-option v-for="item in selectValue5" :key="item.id" :value="item.id">
                                {{item.tableChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-select :value="columnValue5" @change="columnChange5" style="margin-right: 15px">
                            <a-select-option v-for="item in columnData5" :key="item.id" :value="item.id">
                                {{item.tableColumnChineseName}}
                            </a-select-option>
                        </a-select>
                        <a-button icon="search" type="primary" style="margin-right: 15px" @click="countMap5">统计</a-button>
                    </div>
                </div>
                <a-spin tip="获取型号分布图数据中..." :spinning="spinning5">
                    <div id="type-map">
                    </div>
                </a-spin>
            </div>
        </div>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import '../../../node_modules/echarts/map/js/china.js'
    import { provinceMap, chatPie, longPie } from "../../plugins/echarts";
    import {reqFindAllTable, reqFindTableColumn} from "../../api/schema";
    import {reqCityMap, reqCountMap, reqMerchantMap, reqProvinceMap, reqTypeMap} from "../../api/statistics";

    export default {
        name: "Home",
        data () {
            return {
                spinning1: false,
                spinning2: false,
                spinning3: false,
                spinning4: false,
                spinning5: false,
                selectValue1: [],
                tableValue1: '',
                columnData1: [],
                columnValue1: '',
                columnData2: [],
                columnValue2: '',
                columnData3: [],
                columnValue3: '',
                columnData4: [],
                columnValue4: '',
                columnData5: [],
                columnValue5: '',
                selectValue2: [],
                tableValue2: '',
                selectValue3: [],
                tableValue3: '',
                selectValue4: [],
                tableValue4: '',
                selectValue5: [],
                tableValue5: '',
                mapData1: [],
                mapData2: [],
                mapData3: [],
                mapData4: [],
                mapData5: [],
            }
        },
        methods: {
          provinceInit (data) {
              let chinaMap = this.$echarts.init(document.getElementById('province-map'));
              chinaMap.setOption(provinceMap(data));
        },
        merchantInit (data) {
            let chinaMap = this.$echarts.init(document.getElementById('merchant-map'));
            const newData = data.length > 0 ? data.map( item => item.value).reduce( (total, cItem) =>total + cItem ) : 0;
            chinaMap.setOption(chatPie(chinaMap, '运营商分布图', data, newData));
        },
        cityInit (data) {
            let chinaMap = this.$echarts.init(document.getElementById('city-map'));
            const newData = data.length > 0 ? data.map( item => item.value).reduce( (total, cItem) =>total + cItem ) : 0;
            chinaMap.setOption(chatPie(chinaMap, '城市分布图', data, newData));
        },
        countInit (data) {
            let chinaMap = this.$echarts.init(document.getElementById('count-map'));
            const newData = data.length > 0 ? data.map( item => item.value).reduce( (total, cItem) =>total + cItem ) : 0;
            chinaMap.setOption(chatPie(chinaMap, '出现次数分布图', data, newData));
        },
        typeInit (data) {
            let chinaMap = this.$echarts.init(document.getElementById('type-map'));
            chinaMap.setOption(longPie(data));
        },
        async getAllTable () {
              this.spinning1 = this.spinning2 = this.spinning3 = this.spinning4 = this.spinning5 = true;
              const result = await reqFindAllTable({
                    hasCreate: true
                });
              this.selectValue1 = this.selectValue2 = this.selectValue3 = this.selectValue4 = this.selectValue5 = result.data.result;
              if (result.data.result.length > 0){
                  this.tableValue1 = this.tableValue2 = this.tableValue3 = this.tableValue4 = this.tableValue5 = result.data.result[0].id;
              } else {
                  this.tableValue1 = this.tableValue2 = this.tableValue3 = this.tableValue4 = this.tableValue5 = undefined;
              }
              this.getTableColumn();
        },
        async getTableColumn(type, tableId) {
            const result = await reqFindTableColumn({
                showColumn: true,
                tableId: !type? this.tableValue1 : tableId
            });
            if (!type){
                this.columnData1 = this.columnData2 = this.columnData3 = this.columnData4 = this.columnData5 = result.data.result;
                this.columnValue1 = this.columnData1.filter( item => item.tableColumnChineseName === '省份')[0].id;
                this.columnValue2 = this.columnData2.filter( item => item.tableColumnChineseName === '运营商')[0].id;
                this.columnValue3 = this.columnData3.filter( item => item.tableColumnChineseName === '所在城市')[0].id;
                this.columnValue4 = this.columnData4.filter( item => item.tableColumnChineseName === '在网时长')[0].id;
                this.columnValue5 = this.columnData5.filter( item => item.tableColumnChineseName === '手机型号')[0].id;
                this.countMap1();
                this.countMap2();
                this.countMap3();
                this.countMap4();
                this.countMap5();
            } else {
                return result.data.result;
            }
        },
            async tableChange1(value){
              this.tableValue1 = value;
              this.columnData1 = await this.getTableColumn(1, value);
              this.columnValue1 = this.columnData1[0].id;
            },
            async tableChange2(value){
                this.tableValue2 = value;
                this.columnData2 = await this.getTableColumn(1, value);
                this.columnValue2 = this.columnData2[0].id;
            },
            async tableChange3(value){
                this.tableValue3 = value;
                this.columnData3 = await this.getTableColumn(1, value);
                this.columnValue3 = this.columnData3[0].id;
            },
            async tableChange4(value){
                this.tableValue4 = value;
                this.columnData4 = await this.getTableColumn(1, value);
                this.columnValue4 = this.columnData4[0].id;
            },
            async tableChange5(value){
                this.tableValue5 = value;
                this.columnData5 = await this.getTableColumn(1, value);
                this.columnValue5 = this.columnData5[0].id;
            },
            columnChange1 (value) {
              this.columnValue1 = value;
            },
            columnChange2 (value) {
                this.columnValue2 = value;
            },
            columnChange3 (value) {
                this.columnValue3 = value;
            },
            columnChange4 (value) {
                this.columnValue4 = value;
            },
            columnChange5 (value) {
                this.columnValue5 = value;
            },
            async countMap1 () {
              this.spinning1 = true;
              const result_map  = await reqProvinceMap({
                  tableId: this.tableValue1,
                  tableColumnId: this.columnValue1
              });
                const { code, message, result } = result_map.data;
                if (code === 20000){
                    this.mapData1 = result;
                    this.provinceInit(this.mapData1);
                } else {
                    this.$message.error(message);
                }
                this.spinning1 = false;
            },
           async countMap2 () {
                this.spinning2 = true;
                const result_map  = await reqMerchantMap({
                    tableId: this.tableValue2,
                    tableColumnId: this.columnValue2
                });
                const { code, message, result } = result_map.data;
                if (code === 20000){
                    this.mapData2 = result;
                    this.merchantInit(this.mapData2);
                } else {
                    this.$message.error(message);
                }
                this.spinning2 = false;
            },
            async countMap3 () {
                this.spinning3 = true;
                const result_map  = await reqCityMap({
                    tableId: this.tableValue3,
                    tableColumnId: this.columnValue3
                });
                const { code, message, result } = result_map.data;
                if (code === 20000){
                    this.mapData3 = result;
                    this.cityInit(this.mapData3);
                } else {
                    this.$message.error(message);
                }
                this.spinning3 = false;
            },
            async countMap4 () {
                this.spinning4 = true;
                const result_map  = await reqCountMap({
                    tableId: this.tableValue4,
                    tableColumnId: this.columnValue4
                });
                const { code, message, result } = result_map.data;
                if (code === 20000){
                    this.mapData4 = result;
                    this.countInit(this.mapData4);
                } else {
                    this.$message.error(message);
                }
                this.spinning4 = false;
            },
           async countMap5 () {
                this.spinning5 = true;
                const result_map  = await reqTypeMap({
                    tableId: this.tableValue5,
                    tableColumnId: this.columnValue5
                });
                const { code, message, result } = result_map.data;
                if (code === 20000){
                    this.mapData5 = result;
                    this.typeInit(this.mapData5);
                } else {
                    this.$message.error(message);
                }
                this.spinning5 = false;
            },
        },
        components: {
            Title
        },
        mounted() {
            this.getAllTable();
        }
    }
</script>

<style lang="less">
#home{
    padding: 10px;
    .content-title{
        margin-top: 20px;
    }
    .first-part{
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        #province{
            width: 49%;
            height: 530px;
            background: white;
            border-radius: 8px;
            position: relative;
            #province-map{
                width: 100%;
                height: 400px;
            }
        }
        #merchant{
            width: 49%;
            height: 530px;
            background: white;
            border-radius: 8px;
            #merchant-map{
                width: 100%;
                height: 400px;
            }
        }
    }
    .second-part{
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        margin-top: 30px;
        #city{
            width: 49%;
            height: 530px;
            background: white;
            border-radius: 8px;
            position: relative;
            #city-map{
                width: 100%;
                height: 430px;
            }
        }
        #count{
            width: 49%;
            height: 530px;
            background: white;
            border-radius: 8px;
            #count-map{
                width: 100%;
                height: 430px;
            }
        }
    }
    .third-part{
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        margin-top: 30px;
        background: white;
        #type{
            width: 100%;
            height: 530px;
            border-radius: 8px;
            position: relative;
            #type-map{
                width: 100%;
                height: 430px;
            }
        }
    }
    .choose-area{
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
    }
}
</style>