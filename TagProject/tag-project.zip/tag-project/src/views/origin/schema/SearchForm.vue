<template>
    <div id="searchForm">
        <a-form layout="horizontal" :form="form" >
            <a-form-item label="主键ID"
                         :label-col="formItemLayout.labelCol"
                         :wrapper-col="formItemLayout.wrapperCol">
                <a-input v-decorator="[
                                         'username',
                                            ]"
                         placeholder="请输入主键ID">
                </a-input>
            </a-form-item>
            <a-form-item label="表名"
                         :label-col="formItemLayout.labelCol"
                         :wrapper-col="formItemLayout.wrapperCol">
                <a-input v-decorator="[
                                         'username',
                                            ]"
                         placeholder="请输入表名">
                </a-input>
            </a-form-item>
            <a-form-item label="表序号"
                         :label-col="formItemLayout.labelCol"
                         :wrapper-col="formItemLayout.wrapperCol">
                <a-input v-decorator="[
                                         'username',
                                            ]"
                         placeholder="请输入表序号">
                </a-input>
            </a-form-item>
            <a-form-item label="创建状态"
                         :label-col="formItemLayout.labelCol"
                         :wrapper-col="formItemLayout.wrapperCol">
                <a-select
                        v-decorator="[
                                                      'status',

                                                    ]"
                        placeholder="请选择创建状态"
                >
                    <a-select-option value="0">
                        未创建
                    </a-select-option>
                    <a-select-option value="1">
                        已创建
                    </a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="表备注"
                         :label-col="formItemLayout.labelCol"
                         :wrapper-col="formItemLayout.wrapperCol">
                <a-input v-decorator="[
                                         'username',
                                            ]"
                         placeholder="请输入表备注">
                </a-input>
            </a-form-item>
        </a-form>
    </div>
</template>

<script>
    export default {
        name: "SearchForm",
        data () {
            return {
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 16 }
                }
            }
        }
    }
</script>

<style scoped>

</style>