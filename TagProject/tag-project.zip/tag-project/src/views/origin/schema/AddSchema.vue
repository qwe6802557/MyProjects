<template>
    <div id="add-form">
        <Title :title="$route.query.id? '编辑表': '新增表'"/>
        <div class="container">
            <div class="add-title">
                <i class="title-icon"/>
                基本信息
            </div>
            <a-form :form="form">
                <a-row>
                    <a-col :span="5">
                        <a-form-item label="表序号"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'columnNumber',
                                         {   initialValue: $route.query.columnNumber,
                                             rules: [
                                             {   required: true, message: '请输入表序号!' }] }
                                            ]"
                                     placeholder="请输入表序号">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="7">
                        <a-form-item label="表名称"
                                     :label-col="{ span: 9}"
                                     :wrapper-col="{ span: 12}">
                            <a-input v-decorator="[
                                         'tableChineseName',
                                         {   initialValue: $route.query.tableChineseName,
                                             rules: [{
                                             required: true, message: '请填写表名称!' }] }
                                            ]"
                                     placeholder="请输入表名称">
                            </a-input>
                        </a-form-item>
                    </a-col>
                </a-row>
                <a-row>
                    <!--<a-col :span="5">
                        <a-form-item label="创建状态"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                      'hasCreate',
                                                      { rules: [{ required: true, message: '请选择创建状态!' }] },
                                                    ]"
                                    placeholder="请选择创建状态"
                            >
                                <a-select-option value="0">
                                    未创建
                                </a-select-option>
                                <a-select-option value="1">
                                    已创建
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>-->
                    <a-col :span="5">
                        <a-form-item label="表备注"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'columnNotes',
                                         {
                                             initialValue: $route.query.columnNotes,
                                         }
                                            ]"
                                     placeholder="请输入表备注">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="7">
                        <a-form-item label="表英文名"
                                     :label-col="{ span: 9}"
                                     :wrapper-col="{ span: 12}">
                            <a-input v-decorator="[
                                         'tableEnglishName',
                                         {
                                             initialValue: $route.query.tableEnglishName,
                                         }
                                            ]"
                                     placeholder="请输入表英文名">
                            </a-input>
                        </a-form-item>
                    </a-col>
                </a-row>
            </a-form>
        </div>
        <div class="modal-button">
            <a-button shape="round" type="primary" id="cancelButton" @click="cancel">取消</a-button>
            <a-button shape="round" type="primary" id="okButton" @click="confirm" :loading="confirmLoading">确定</a-button>
        </div>
    </div>
</template>

<script>
    import { reqAddTable, reqUpdateTable } from "../../../api/schema";
    import Title from '@/components/contentTitle';
    export default {
        name: "AddForm",
        data () {
            return {
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 16 }
                },
                confirmLoading: false
            }
        },
        methods: {
          cancel () {
              this.$router.go(-1);
          },
          confirm () {
              this.confirmLoading = true;
              this.form.validateFields( (err , values) => {
                 if (err){
                     this.confirmLoading = true;
                     return false;
                 }
                 values.hasCreate = !!Number(values.hasCreate);
                 if (!this.$route.query.id){
                     reqAddTable(values).then( res => {
                         const { code, message } = res.data;
                         code === 20000 && this.$message.success(message) && this.$router.push('/auth/schema');
                         code !== 20000 && this.$message.error(message);
                         this.confirmLoading  = false;
                     });
                 } else {
                     values.id = this.$route.query.id;
                     reqUpdateTable(values).then( res => {
                         const { code, message } = res.data;
                         code === 20000 && this.$message.success(message) && this.$router.push('/auth/schema');
                         code !== 20000 && this.$message.error(message);
                         this.confirmLoading  = false;
                     });
                 }
              });
          }
        },
        mounted() {
          console.log(this.$route.query);
        },
        components: {
            Title
        }
    }
</script>

<style scoped>

</style>