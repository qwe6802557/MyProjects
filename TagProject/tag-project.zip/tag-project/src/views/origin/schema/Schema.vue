<template>
    <div id="schema">
        <Title :title="'表管理'"/>
        <div class="button-area">
            <!--<a-button type="primary" icon="search" @click="this.showSearchForm">筛选</a-button>-->
            <a-button type="danger" icon="delete" @click="deleteMany" v-if="userInfo.admin">批量删除</a-button>
            <a-button icon="plus" @click="addSchema" v-if="userInfo.admin">新建表</a-button>
        </div>
        <a-spin :spinning="spinning" :tip="tip">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="pagination"
                     :rowKey="rowKey"
                     :rowSelection="rowSelection"
                     @change="handleTableChange">
                <span slot="hasCreate" slot-scope="hasCreate">
                      <a-tag :color="hasCreate === true? 'geekblue' : 'volcano'">
                        {{hasCreate === true? '已创建' : '未创建'}}
                      </a-tag>
                </span>
                <template slot="operation" slot-scope="text">
                    <a href="javascript:;" @click="createOperation(text)" v-if="!text.hasCreate && userInfo.admin">创建</a>
                    <a href="javascript:;" @click="editOperation(text)" v-if="userInfo.admin">编辑</a>
                    <a href="javascript:;" @click="deleteOperation(text.id)" v-if="userInfo.admin">删除</a>
                </template>
            </a-table>
        </a-spin>
        <!--<div class="form-drawer">
            <a-drawer :title="'筛选表单'"
                      :closable="false"
                      :visible="drawerVisible"
                      @close="this.drawerClose"
                      :drawerStyle="{background:'#F8FAFC'}"
                      :width="drawerWidth">
                <div class="form-content">
                    <SearchForm/>
                </div>
                <a-button type="primary" shape="round" class="confirm-button"  :loading="searchLoading">确定</a-button>
            </a-drawer>
        </div>-->
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    /*import SearchForm from "@/views/origin/schema/SearchForm";*/
    import { reqFindAllTable, reqDeleteTable, reqCreateTable } from "../../../api/schema";
    import { Modal } from 'ant-design-vue';
    import { mapState } from 'vuex';
    export default {
        name: "Schema",
        data () {
            return {
                columns: [],
                dataSource: [],
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize) {
                        this.pagination.pageSize = pageSize;
                    },
                    showQuickJumper: true,
                    showSizeChanger: false,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                rowSelection: {},
                rowKey: 'id',
                tip: '获取数据中...',
                drawerWidth: '300',
                searchLoading: false,
                drawerVisible: false,
                spinning: false,
                selectedId: []
            }
        },
        methods: {
            tableInit () {
                this.columns = [
                    {
                        title: '表序号',
                        dataIndex: 'columnNumber',
                    }, {
                        title: '主键ID',
                        dataIndex: 'id',
                    },
                    {
                        title: '表名',
                        dataIndex: 'tableChineseName',
                    }, {
                        title: '创建状态',
                        dataIndex: 'hasCreate',
                        scopedSlots: { customRender: 'hasCreate'}
                    }, {
                        title: '表备注',
                        dataIndex: 'columnNotes',
                    }, {
                        title: '操作',
                        scopedSlots: { customRender: 'operation' }
                    },
                ];
                this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }
            },
            addSchema () {
              this.$router.push('/auth/addOrEditSchema');
            },
            /*drawerClose () {
                this.drawerVisible = false;
            },*/
            showSearchForm () {
                this.drawerVisible = true;
            },
            getAllTable (loadingFlag) {
                if (!loadingFlag){
                    this.spinning = true;
                }
                reqFindAllTable({
                    hasCreate: false,
                    pageNumber: this.pagination.current,
                    pageSize: this.pagination.pageSize
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.pagination.total = result.total;
                        this.dataSource = result.data;
                    } else {
                        this.$message.error(message);
                    }
                    this.spinning = false
                });
            },
            deleteOperation (id) {
                Modal.confirm({
                    title: '删除表',
                    content: '确定要删除该表吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteTable({
                            ids: [id]
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllTable();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除表',
                    content: '确定要批量删除这些表吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteTable({
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllTable();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            editOperation (table) {
                this.$router.push({ path: '/auth/addOrEditSchema', query: table });
            },
            createOperation (text) {
                this.tip = '创建表中...';
                this.spinning = true;
                reqCreateTable({
                    tableId: text.id
                }).then( res => {
                    const { code, message } = res.data;
                    code === 20000 && this.$message.success(message) && this.getAllTable();
                    code !== 20000 && this.$message.error(message);
                    this.spinning = false;
                    this.tip = '获取表数据中...';
                });
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.getAllTable();
            },
        },
        computed: {
          ...mapState(['userInfo'])
        },
        components: {
            Title,
            /*SearchForm*/
        },
        mounted() {
            this.tableInit();
            this.getAllTable();
        }
    }
</script>

<style lang="less">
    #schema{
        .button-area{
            text-align: left;
            padding-bottom: 3px;
        }
        .ant-btn{
            margin-right: 10px;
        }
    }
</style>