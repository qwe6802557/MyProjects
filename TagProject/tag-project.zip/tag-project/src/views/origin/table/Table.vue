<template>
    <div id="tag">
        <div class="title-bar">
            <Title :title="title"/>
            <div class="title-button">
                <a-button type="primary" icon="edit" @click="setManyTags">批量设置标签</a-button>
                <a-button type="danger" icon="delete" @click="deleteMany" v-if="userInfo.admin">批量删除</a-button>
                <a-button icon="plus" @click="addTableData" v-if="userInfo.admin">新增数据</a-button>
                <a-button type="dashed"  icon="upload"  @click="toInterface" v-if="userInfo.admin">接口调用</a-button>
                <a-button type="dashed"  icon="download" @click="download" v-if="userInfo.daochu">导出筛选数据</a-button>
            </div>
        </div>
        <div class="button-area">
            <a-collapse v-model="activeKey">
                <a-collapse-panel  :accordion="true" :key="'1'">
                    <div class="header" slot="header" @click.stop>
                        <span style="margin-right: 5px;">表名称:</span>
                        <a-select :value="tableValue" style="width: 150px;margin-right: 10px;" @change.stop="changeValue" :loading="tableLoading" @click.stop>
                            <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">{{item.tableChineseName}}</a-select-option>
                        </a-select>
                        <a-button type="link" icon="plus" @click="add">筛选条件</a-button>
                    </div>
                    <a-form :form="formDynamic" >
                        <a-form-item
                                v-for="(k /*index*/) in form.getFieldValue('keys')"
                                :key="k"
                                v-bind="{
                                    labelCol: { span: 1 },
                                    wrapperCol: { span: 5 }
                                }"
                                :label="'条件配置'"
                                :required="false"
                        >
                            <a-select
                                    v-decorator="[`names[${k}]`,
                                     {
                                        rules: [{
                                            required: true,
                                            message: '请选择条件配置!'
                                        }]
                                    }]"
                                    placeholder="请选择"
                                    style="width: 220px; margin-right: 8px"
                            >
                                <a-select-option :value="item.tableColumnEnglishName" v-for="item in columnData" :key="item.id">
                                    {{item.tableColumnChineseName}}
                                </a-select-option>
                            </a-select>
                            <a-select
                                    v-decorator="[`names1[${k}]`, {
                                        initialValue: 7,
                                        rules: [{
                                            required: true,
                                            message: '请选择条件!'
                                        }]
                                    } ]"
                                    placeholder="请选择条件"
                                    style="position: absolute;width: 120px;top: -8px;"
                            >
                                <a-select-option :value="item.id" v-for="item in equalList" :key="item.id">
                                    {{item.value}}
                                </a-select-option>
                            </a-select>
                            <a-input
                                    v-decorator="[`names2[${k}]`, {
                                        rules: [{
                                            required: true,
                                            message: '请输入条件值!'
                                        }]
                                    }]"
                                    placeholder="请输入条件值"
                                    style="position: absolute;width: 140px;left: 355px;margin-top: 4px;"
                            >
                            </a-input>
                            <a-icon
                                    v-if="form.getFieldValue('keys')"
                                    class="dynamic-delete-button"
                                    type="minus-circle-o"

                                    @click="() => remove(k)"
                                    style="position: absolute;left: 505px;top: 0px;"
                            />
                        </a-form-item>
                    </a-form>
                </a-collapse-panel>
                <a-collapse-panel  :accordion="true" :key="'2'">
                    <p slot="header" style="height: 100%;margin-bottom: 0;">
                        标签管理
                    </p>
                       <div class="each-tag" style="border-bottom: 2px dotted #eeeeee;padding-bottom: 8px;" v-for="(item, index) in tagsList" :key="index">
                           <a-row>
                               <a-col :span="2">
                                   <span style="color: #959598; font-weight: 500;font-size: 14px;">{{item.tagGroup}}</span>
                               </a-col>
                               <a-col>
                                   <div class="tag-area">
                                       <span @click="tagClick(cItem)" :class="cItem.isChecked? 'tag-active' : ''" v-for="cItem in item.tagList" :key="cItem.id">
                                           {{cItem.tagName}}
                                       </span>
                                   </div>
                               </a-col>
                           </a-row>
                       </div>
                        <a-row>
                            <div class="checked-tag" style="background: #EFEFEF;margin-top: 10px;">
                                <span style="rgba(0,0,0,.8);padding: 5px 10px;display: inline-block;">已选字段</span>
                                <a-tag v-for="item in checkedTags" @close="() => handleClose(item)" :key="item.id" closable>
                                    {{ item.tagName }}
                                </a-tag>
                            </div>
                        </a-row>
                </a-collapse-panel>
            </a-collapse>
            <!--<a-button type="dashed"  icon="upload"  @click="importData" style="float: right;margin-right: 0;">导入数据</a-button>-->
        </div>
        <div class="table-button" style="display: flex;flex-direction: row;justify-content: flex-end;">
            <a-button type="primary" icon="pushpin" @click="changeHeader">筛选显示</a-button>
            <a-button type="link" @click="deleteAllOperation">[清空全部]</a-button>
            <a-button type="primary" icon="search" @click="searchData">搜索</a-button>
        </div>
        <a-spin :spinning="initLoading" tip="获取表格数据中...">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="false"
                     :rowSelection="rowSelection"
                     :rowKey="'id'"
                     :scroll="{ y: 480}"
                     >
                <span slot="tagGroupId" slot-scope="tagGroupId">
                    {{!!tagGroupValue.filter( item => item.id === tagGroupId )[0] && tagGroupValue.filter( item => item.id === tagGroupId )[0].tagGroupName || '-'}}
                </span>
                <span slot="tableColumnId" slot-scope="tableColumnId">
                    {{!!selectValue.filter( item => item.id === tableColumnId )[0] && selectValue.filter( item => item.id === tableColumnId )[0].tableColumnChineseName || '-'}}
                </span>
                <template slot="operation" slot-scope="text">
                    <a href="javascript:;" @click="setOperation(text)" v-if="userInfo.admin">设置标签</a>
                    <a href="javascript:;" @click="editOperation(text)" v-if="userInfo.admin">编辑</a>
                    <a href="javascript:;" @click="deleteOperation(text)" v-if="userInfo.admin">删除</a>
                </template>
            </a-table>
            <div class="pagination" style="display: flex;flex-direction: row;justify-content: flex-end;">
                <el-pagination
                        @size-change="showSizeChange"
                        @current-change="changeCurrent"
                        :current-page="pagination.current"
                        :page-sizes="[10,20,50,100,200,500,1000,2000,5000]"
                        :page-size="10"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="pagination.total"
                        >
                </el-pagination>
            </div>
        </a-spin>
        <div class="form-drawer">
            <a-drawer :title="'设置标签'"
                      :closable="false"
                      :visible="drawerVisible"
                      @close="drawerClose"
                      :destroyOnClose="true"
                      :drawerStyle="{background:'#F8FAFC'}"
                      :width="drawerWidth">
                <div class="form-content" style="max-height: 700px;overflow-y: auto;">
                    <div>
                        <a-form :form="form">
                            <a-col :span="24">
                                <a-form-item label="数据表"
                                             :label-col="{ span: 2 }"
                                             :wrapper-col="{ span: 7 }">
                                    <a-select
                                            v-decorator="['tableId', { rules: [{   required: true, message: '请选择表字段!' }]} ]"
                                            placeholder="请选择数据表"
                                            @change="searchTag"
                                    >
                                        <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">
                                            {{item.tableChineseName}}
                                        </a-select-option>
                                    </a-select>
                                </a-form-item>
                            </a-col>
                            <a-col :span="24" style="overflow-y: auto;max-height: 700px;">
                        <span v-for="(item, index) in tagOptions" :key="index" style="display: flex;flex-direction: row;justify-content: flex-start;">
                             <span style="margin-right: 60px;font-weight: bolder;">{{item.tagGroup}}:</span>
                             <a-checkbox-group name="checkboxgroup"
                                               v-model="checkedTableTags"
                                               :options="item.tagList">
                             </a-checkbox-group>
                        </span>
                                <!--<a-checkbox-group name="checkboxgroup"
                                                  v-model="checkedTableTags"
                                                  :options="tagOptions">
                                </a-checkbox-group>-->
                            </a-col>
                        </a-form>
                    </div>
                </div>
                <a-button type="primary" shape="round" class="confirm-button"  :loading="searchLoading" @click="confirmSetting">确定</a-button>
            </a-drawer>
        </div>
        <a-modal :title="modalTitle"
                 v-model="visible"
                 @ok="handleOk"
                 @cancel="handleCancel"
                 :class="showHeader? ['common-modal', 'personal-modal'] : ['common-modal', 'tagGroup-modal']"
                 :destroyOnClose="true"
                 :keyboard="true"
                 :maskClosable="false"
                 :okText="'确认'"
                 :cancelText="'取消'"
                 :closable="!showHeader"
                 :confirmLoading="confirmLoading"
                 :width="showTag? 800 : 550"
                 :scroll="{ y: 700 }">
            <div class="check-box-area" v-if="showHeader">
                <a-checkbox-group name="checkboxgroup"
                                  v-model="checkedHeader"
                                  :options="options">
                </a-checkbox-group>
            </div>
            <div class="add-tag-group" v-if="!showHeader && !showTag">
                <a-form :form="form">
                    <a-col :span="24">
                        <a-form-item label="所属标签组"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'tagGroupId',
                                                              {    initialValue: Number(tagGroupId) || undefined,
                                                                   rules: [
                                                                             {   required: true, message: '请选择所属标签组!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择所属标签组"
                                    :disabled="true"
                            >
                                <a-select-option  v-for="item in tagGroupValue" :value="item.id" :key="item.id">
                                    {{item.tagGroupName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="所属字段"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'tableColumnId',
                                                              {    initialValue: editInfo.tableColumnId || undefined,
                                                                   rules: [
                                                                             {   required: true, message: '请选择所属字段!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择所属字段"
                            >
                                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">
                                    {{item.tableColumnChineseName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="标签名称"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'tagName',
                                         {   initialValue: editInfo.tagName || undefined,
                                             rules: [
                                             {   required: true, message: '请输入标签名称!' }] }
                                            ]"
                                     placeholder="请输入标签名称">
                            </a-input>
                        </a-form-item>
                    </a-col>
                </a-form>
            </div>
        </a-modal>
    </div>
</template>

<script type="text/jsx">
    import Title from '@/components/contentTitle';
    import {reqAddTag, reqUpdateTag, reqTagGroup, reqTagsByTableId} from "../../../api/tag";
    import { Modal } from 'ant-design-vue';
    import {reqDeleteTableData, reqFindAllColumn, reqFindAllTable, reqSetTags, reqTableData} from "../../../api/schema";
    /*import { exportExcel } from 'xlsx-oc';*/
    import { mapState } from 'vuex';
    import {reqExportFile} from "@/api/file";
    import createSql from "@/untils/createSql";
    export default {
        name: "Table",
        data () {
            return {
                columns: [],
                activeKey: ['1', '2'],
                tagsList: [],
                checkedTags: [],
                sqlStr: [],
                showTag: false,
                drawerVisible: false,
                searchLoading: false,
                drawerWidth: 1300,
                equalList: [{
                   id: 1,
                   value: '等于',
                }, {
                    id: 2,
                    value: '不等于',
                }, {
                    id: 3,
                    value: '大于',
                }, {
                    id: 4,
                    value: '小于',
                }, {
                    id: 5,
                    value: '大于等于',
                }, {
                    id: 6,
                    value: '小于等于',
                }, {
                    id: 7,
                    value: '包含',
                }, {
                    id: 8,
                    value: '不包含',
                }],
                tagVisible: false,
                showHeader: false,
                tagTitle: false,
                nowIndex: '',
                tagGroupLoading: false,
                tableColumnLoading: false,
                formItemLayoutWithOutLabel: {
                    wrapperCol: {
                        xs: { span: 24, offset: 0 },
                        sm: { span: 20, offset: 4 },
                    }},
                formDynamic: this.$form.createForm(this, { name: 'dynamic_form_item' }),
                tagGroupName: '',
                tagGroupValue: '',
                tagGroupSelectValue: '',
                columnData: [],
                header: '',
                editInfo: {
                    tagName: '',
                    tableColumnId: '',
                    id: ''
                },
                checkedTableTags: [],
                tagOptions: [],
                defaultColumns: [],
                options: [],
                showColumns: [],
                dataSource: [],
                initLoading: false,
                tableValue: '',
                selectValue: [],
                tableHeader: [],
                title: '数据分析',
                visible: false,
                confirmLoading: false,
                tableLoading: false,
                modalTitle: '新增数据',
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize, size) {
                        console.log(pageSize, size);
                        this.pagination.pageSize = pageSize;
                        this.getTagGroupTableData();
                    },
                    showTotal(total){
                        return `共${total}条数据`
                    },
                    showQuickJumper: true,
                    showSizeChanger: true,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                tableTagList: [],
                tableTagValue: '',
                rowSelection: {},
                checkedHeader: [],
                tableColumnArr: [],
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 14 }
                },
                selectedId: [],
                wordName: '',
                wordLoading: false,
                tagGroupId: this.$route.params.tagGroupId,
                load: true,
                isSearch: true,
                id: 1,
            }
        },
        methods: {
           async getTableData (func) {
                this.tableLoading = true;
                const result_table = await reqFindAllTable({
                    hasCreate: true
                });
                const { code, result, message } = result_table.data;
                if (code === 20000){
                    this.selectValue = result;
                    if (this.selectValue.length > 0){
                        this.tableValue = this.selectValue[0].id;
                    } else {
                        this.tableValue = undefined;
                    }
                    this.getTagsListByTableId();
                    await this.getTableColumnData();
                    !!func && this.getTagGroupData(func) || this.getTagGroupData();
                } else {
                    this.$message.error(message);
                }
               this.tableLoading = false;
            },
            confirmSetting () {
                this.searchLoading = true;
                reqSetTags({
                    tableId: this.tableTagValue,
                    updateIds: this.selectedId.length > 0 ? this.selectedId : [this.editInfo.id],
                    tagStrs: this.checkedTableTags,
                }).then( res => {
                    const {code} = res.data;
                    code === 20000 && this.$message.success('设置标签成功!') && this.getTagGroupTableData();
                    code !== 20000 && this.$message.error(res.data.message);
                    this.searchLoading = false;
                    this.drawerVisible = false;
                    this.tableTagList = [];
                    this.checkedTableTags = [];
                    this.tagOptions = [];
                    this.checkedTags = [];
                    this.selectedId = [];
                    this.selectionInit();
                });
            },
            drawerClose() {
                this.drawerVisible = false;
                setTimeout(() => {
                    this.tableTagList = [];
                    this.checkedTableTags = [];
                    this.tagOptions = [];
                }, 300);
            },
            handleCancel () {
              this.visible = false;
              setTimeout(() => {
                  this.tableTagList = [];
                  this.checkedTableTags = [];
                  this.tagOptions = [];
              }, 300);
            },
            showSizeChange (pageSize) {
               this.pagination.pageSize = pageSize;
               this.getTagGroupTableData();
            },
            async getTagsListByTableId () {
              const result_tags = await reqTagsByTableId({
                  tableId: this.tableValue,
              });

              const { code, message, result } = result_tags.data;

              if (code === 20000){
                  this.tagsList = result;
              } else {
                  this.$message.error(message);
              }
            },
            handleClose (tag) {
                this.tagsList.map(item => {
                    if (item.tagList.findIndex(value => value.id === tag.id) !== -1){
                        item.tagList[item.tagList.findIndex(value => value.id === tag.id)].isChecked = false;
                    }
                });
                this.checkedTags.map( (item, index) => {
                    if (item.id === tag.id){
                        this.checkedTags.splice(index, 1);
                    }
                })
            },
            tagClick (tag) {
                tag.isChecked = true;
                if (this.checkedTags.filter( item => item.id === tag.id )[0]){
                    return false;
                }
                this.checkedTags.push(tag);
            },
           async getTagGroupData (func) {
               this.tagGroupLoading = true;
               const result_tagGroup = await reqTagGroup({
                   hasPage: false,
                   tableId: this.tableValue
               });
               const { code, result, message } = result_tagGroup.data;
               if (code === 20000){
                   this.tagGroupSelectValue = result;
                   if (this.tagGroupSelectValue.length > 0){
                       this.tagGroupValue = this.tagGroupSelectValue[0].id;
                   } else {
                       this.tagGroupValue = undefined;
                   }
                   !!func && func();
               } else {
                   this.$message.error(message);
               }
               this.tagGroupLoading = false;
            },
            async getTagGroupTableData (type) {
               this.initLoading = true;
               const searchCondition = {
                   tableId: !this.isSearch? this.$route.query.tableId : this.tableValue,
                   tagIds: this.checkedTags.map(item => item.id),
                   pageNumber: this.pagination.current,
                   pageSize: this.pagination.pageSize,
               };

               if (this.sqlStr.length > 0){
                   searchCondition.queryStrs = this.sqlStr;
               }
               const result_table = await reqTableData(searchCondition);
               const { code, message, result } = result_table.data;
               if (type){
                   if (code === 20000){
                       this.dataSource = result.data;
                       this.pagination.total = result.total;
                   }
               }else {
                   code === 20000 && this.headerInit(result);
               }
               this.isDisabled();
               code !== 20000 && this.$message.error(message);
               this.initLoading = false;

               return result || [];
            },
            async getTableColumnData () {
                const result_column = await reqFindAllColumn({
                    tableId: this.tableValue,
                    showColumn: true
                });

                const { code, message, result } = result_column.data;
                if (code === 20000){
                    this.columnData = result;
                } else {
                    this.$message.error(message);
                }
            },
            deleteAllOperation () {
               this.checkedTags = [];
               this.tagsList.map( item => {
                   item.tagList.map(cItem => {
                       cItem.isChecked = false;
                   });
               });
               for (let i = 1; i <= this.id; i++){
                   this.remove(i);
               }
            },
          /*  exportExcelData () {
                const listHeader = [];
                this.defaultColumns.map( item => {
                   listHeader.push({
                       k: item.name,
                       v: item.title
                   })
               });

                const fileName = "筛选数据.xlsx";

                exportExcel(listHeader, this.dataSource, fileName);
            },*/
            changeValue (value) {
                this.tableValue = value;
                this.getTagGroupData();
            },
            changeTagGroup (value) {
                this.tagGroupValue = value;
            },
            importData () {
               this.$router.push({ path: '/auth/addFile', query: { tableId: this.tableValue, tableData: this.selectValue }});
            },
           async download () {
               /* if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择需要导出的数据');
                }
                this.exportExcelData();*/
                   const result =  await reqExportFile({
                       tableId: !this.isSearch? this.$route.query.tableId : this.tableValue,
                       tagIds: this.checkedTags.map(item => item.id),
                   });
                   this.exportFile(result.data);
            },
            tableInit () {
                this.columns = [];
                this.showColumns = this.defaultColumns;
                this.showColumns.map(( item ) => {
                    if (item.scopedSlots){
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name,
                            scopedSlots: { customRender: item.name }
                        });
                    } else {
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name
                        });
                    }
                    return item;
                });
                this.columns.push({
                    title: '操作',
                    width: 200,
                    scopedSlots: { customRender: 'operation' }
                });
                this.selectionInit();
            },
            selectionInit () {
                this.rowSelection = {
                    selectedRowKeys: this.selectedId,
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                        this.rowSelection.selectedRowKeys = this.selectedId;
                    },
                }
            },
            async setManyTags () {
              if (this.selectedId.length === 0){
                  return this.$message.warning('请选择需要设置标签的数据!');
              }
              this.modalTitle = '批量设置标签';
              this.showHeader = false;
              this.showTag = true;
              this.drawerVisible = true;
            },
            changeHeader () {
                this.modalTitle = '筛选表头';
                this.showHeader = true;
                this.visible = true;
                console.log(this.options);
            },
            exportFile (blob) {  //处理返回的excel文件
                const reader = new FileReader();

                reader.readAsDataURL(blob); // 转换为base64，可以直接放入a标签href

                reader.onload = e => {
                    // 转换完成，创建一个a标签用于下载

                    let a = document.createElement("a");
                    a.style.display = "none";
                    a.download = "筛选数据.xls";

                    a.href = e.target.result;
                    const body = document.body;
                    body.appendChild(a); // 修复firefox中无法触发click
                    a.click();
                    body.removeChild(a);
                };
            },
            editOperation (tagGroup) {
                this.editInfo = tagGroup;
                this.$router.push({ path: '/auth/addTable', query: { tableData: this.selectValue, editInfo: this.editInfo, tableId: this.tableValue, columnData: this.columnData}})
            },
            deleteOperation (tag) {
                Modal.confirm({
                    title: '删除数据',
                    content: '确定要删除该数据吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteTableData({
                            tableId: this.tableValue,
                            ids: [tag.id]
                        }).then( res => {
                            const { code, message } = res.data;
                            if (code === 20000){
                                this.defaultColumns = [];
                                this.options = [];
                                this.columns = [];
                                this.$message.success(message);
                                this.getTagGroupTableData();
                            }
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            async searchTag (value) {
                this.tableTagValue = value;
                const result_tag = await reqTagsByTableId({
                    tableId: value
                });

                const { code, message, result } = result_tag.data;

                if (code === 20000){
                    result.map( item => {
                        item.tagList = item.tagList.map( cItem => {
                            cItem = {
                                label: cItem.tagName,
                                value: cItem.tagName
                            };

                            return cItem;
                        });
                    });
                    this.tagOptions = result;
                } else {
                    this.$message.error(message);
                }
            },
            deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除数据',
                    content: '确定要批量删除这些数据吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteTableData({
                            tableId: this.tableValue,
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            if (code === 20000){
                                this.defaultColumns = [];
                                this.options = [];
                                this.columns = [];
                                this.$message.success(message);
                                this.getTagGroupTableData();
                            }
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            addTableData () {
                this.showHeader = false;
               const editInfo = {};
               for (const item in this.dataSource[0]){
                   editInfo[item] = ''
               }
               this.$router.push({ path: '/auth/addTable', query: { tableData: this.selectValue, editInfo, tableId: this.tableValue, columnData: this.columnData}});
            },
            showSearchForm () {

            },
            showTable () {
                this.defaultColumns = [];
                this.options = [];
            },
            headerInit (tableData) {
                this.defaultColumns = [];
                this.options = [];
                for( const item in tableData.data[0]){
                    this.defaultColumns.push({
                        name: item,
                        title: this.columnData.filter( cItem => cItem.tableColumnEnglishName === item)[0] ? this.columnData.filter( cItem => cItem.tableColumnEnglishName === item)[0].tableColumnChineseName : '主键ID'
                    });
                    this.options.push({
                        label: this.columnData.filter( cItem => cItem.tableColumnEnglishName === item)[0] ? this.columnData.filter( cItem => cItem.tableColumnEnglishName === item)[0].tableColumnChineseName : '主键ID',
                        value: item
                    });
                }
                this.checkedHeader = this.options.map( item => item.value);
                this.tableInit();
                this.dataSource = tableData.data;
                this.pagination.total = tableData.total;
            },
            searchData () {
               this.formDynamic.validateFields((err, value) => {
                   if (err){
                       return this.$message.warning('有未填写的数据,请先检查!');
                   }
                   this.sqlStr = [];
                   if (value.names){
                       const { names, names1, names2 } = value;

                       names.map((item, index) => {
                           !!item && this.sqlStr.push(createSql(item, names1[index], names2[index]));
                       });
                   }
                   this.getTagGroupTableData();
                });
            },
            async nextPage () {
                this.pagination.current++;
                this.getTagGroupTableData(1);
            },
            isDisabled () {
                if (this.dataSource.length < (this.pagination.current*this.pagination.pageSize)){
                    this.load = true;
                } else {
                    this.load = false;
                }
            },
            handleOk () {
                if (this.showHeader){
                    const okColumns = [];
                    this.showColumns.map( item => {
                        this.checkedHeader.map( cItem => {
                            if (cItem === item.name){
                                if (item.scopedSlots){
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name,
                                        scopedSlots: { customRender: item.name },
                                    });
                                } else {
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name,
                                });
                                }
                            }
                        });
                    });
                    okColumns.push({
                        title: '操作',
                        width: 200,
                        scopedSlots: { customRender: 'operation' }
                    });
                    this.columns = okColumns;
                    this.visible = false;
                } else {
                    this.form.validateFields( (err, values) => {
                        if (err){
                            return false;
                        }
                        this.confirmLoading = true;
                        if (this.showTag){
                            reqSetTags({
                                tableId: this.tableTagValue,
                                updateIds: this.selectedId.length > 0 ? this.selectedId : [this.editInfo.id],
                                tagStrs: this.checkedTableTags,
                            }).then( res => {
                                const { code } = res.data;
                                code === 20000 && this.$message.success('设置标签成功!') && this.getTagGroupTableData();
                                code !== 20000 && this.$message.error(res.data.message);
                                this.confirmLoading = false;
                                this.visible = false;
                                this.checkedTags = [];
                                this.tagOptions = [];
                                this.selectedId = [];
                                this.selectionInit();
                            });
                        } else {
                            if (this.editInfo.tableColumnId){
                                values.id = this.editInfo.id;
                                reqUpdateTag(values).then( res => {
                                    const { code } = res.data;
                                    code === 20000 && this.$message.success('修改标签成功!') && this.getTagGroupTableData();
                                    code !== 20000 && this.$message.error(res.data.message);
                                    this.confirmLoading = false;
                                    this.visible = false;
                                    this.form.resetFields();
                                });
                            } else {
                                reqAddTag(values).then( res => {
                                    const { code } = res.data;
                                    code === 20000 && this.$message.success('新增标签成功!') && this.getTagGroupTableData();
                                    code !== 20000 && this.$message.error(res.data.message);
                                    this.confirmLoading = false;
                                    this.visible = false;
                                    this.form.resetFields();
                                });
                            }
                        }
                    })
                }
            },
            toInterface () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择需要调用接口的数据');
                }
                this.$router.push({ path: '/auth/interface', query: { dataIds: this.selectedId }});
            },
            remove(k) {
                const { form } = this;
                // can use data-binding to get
                const keys = form.getFieldValue('keys');

                // can use data-binding to set
                form.setFieldsValue({
                    keys: keys.filter(key => key !== k),
                });
            },

            add() {
                const { form } = this;
                // can use data-binding to get
                const keys = form.getFieldValue('keys');
                const nextKeys = keys.concat(this.id++);
                // can use data-binding to set
                // important! notify form to detect changes
                form.setFieldsValue({
                    keys: nextKeys,
                });
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.getTagGroupTableData();
            },
            changeCurrent (current) {
               this.pagination.current = current;
               this.getTagGroupTableData();
            },
            setOperation (tag) {
                this.selectedId = [];
                this.modalTitle = '设置标签';
                this.editInfo = tag;
                this.showHeader = false;
                this.showTag = true;
                this.drawerVisible = true;
            },
        },
        computed: {
            ...mapState(['userInfo', 'tableId', 'tagIds'])
        },
        components:{
            Title
        },
        mounted() {
            const { tableData } = this.$route.query;
            if (this.$route.query.tagsId){
                this.isSearch = false;
            } else {
                this.isSearch = true;
            }
            if (Array.isArray(tableData)){
                this.initLoading = true;
                this.getTableData().then( () => {
                    if (tableData.length > 0){
                        this.headerInit(tableData);
                    } else {
                        this.defaultColumns = [];
                        this.options = [];
                        this.tableInit();
                    }
                    this.initLoading = false;
                });
            } else {
                this.getTableData(this.getTagGroupTableData);
            }
            this.form.getFieldDecorator('keys', { initialValue: [], preserve: true });
        }
    }
</script>

<style lang="less">
    #tag{
        .ant-table-header{
            overflow-y: hidden;
        }
        .tag-area{
            span{
                margin: 0 10px;
                transition: .5s all;
                &:hover{
                    color: #87BBF4;
                    cursor: pointer;
                }
            }
            .tag-active{
                color: #87BBF4;
            }
        }
        .title-bar{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
        }
        .header{
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            height: 100%;
            background: #FAFAFA;
        }
        .ant-btn{
            margin: 0 5px;
        }
    }
    .add-tag-group{
        .ant-input{
            background: #F7F9FA !important;
        }
        .ant-input:focus{
            background: #ffffff !important;
        }
        .ant-select-selection--single{
            background: #F7F9FA !important;
        }
    }
    .ant-checkbox-group-item{
        white-space: nowrap;
        text-overflow:ellipsis;
        overflow: hidden;
    }
    .ant-checkbox-wrapper{
        margin-bottom: 10px;
    }
    .tagGroup-modal{
        .ant-btn{
            margin-top: 20px;
        }
    }
    .personal-modal{
        .ant-modal-content{
            button:nth-child(1){
                display: none;
            }
            button:nth-child(2){
                margin-left: 0;
            }
            .ant-modal-body{
                padding-bottom: 10px;
            }
        }
    }
</style>