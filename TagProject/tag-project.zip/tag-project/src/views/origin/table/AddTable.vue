<template>
    <div id="search-form">
        <Title :title="this.id? '修改数据' : '添加数据'"/>
        <div class="container">
            <div class="add-title">
                <i class="title-icon"/>
                筛选信息
            </div>
                <a-form :form="form" style="width: 80%; overflow: hidden;">
                        <a-col :span="8">
                            <a-form-item :label="'表名称'"
                                         :label-col="formItemLayout.labelCol"
                                         :wrapper-col="formItemLayout.wrapperCol">
                                <a-select v-decorator="[
                                         'tableId',
                                         {   initialValue: $route.query.tableId || undefined,
                                             rules: [{
                                                 required: true, message: '请选择表名称!' }]
                                             }
                                            ]"
                                          placeholder="请选择表名称">
                                    <a-select-option v-for="item in $route.query.tableData" :value="item.id" :key="item.id">
                                        {{item.tableChineseName}}
                                    </a-select-option>
                                </a-select>
                            </a-form-item>
                        </a-col>
                    <a-col :span="8" v-for="(value, key, index) in formData" :key="index">
                        <a-form-item :label="$route.query.columnData.filter( item => item.tableColumnEnglishName === key)[0].tableColumnChineseName"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         key,
                                         {   initialValue: value || undefined,
                                             rules: [{
                                             validator: checkValues
                                             }]
                                             }
                                            ]"
                                      :placeholder="'请输入' + $route.query.columnData.filter( item => item.tableColumnEnglishName === key)[0].tableColumnChineseName ">
                            </a-input>
                        </a-form-item>
                    </a-col>
                </a-form>
        </div>
        <div class="modal-button">
            <a-button shape="round" type="primary" id="cancelButton" @click="cancel">取消</a-button>
            <a-button shape="round" type="primary" id="okButton" @click="confirm" :loading="confirmLoading">确定</a-button>
        </div>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import {reqAddTableData, reqFindAllColumn, reqUpdateTableData} from "../../../api/schema";

    export default {
        name: "AddTable",
        data () {
            return {
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 6 },
                    wrapperCol: { span: 14 }
                },
                dataTypeLoading: false,
                confirmLoading: false,
                spinning: false,
                columns: [],
                formData: {},
                id: '',
                tableColumns: []
            }
        },
        methods: {
            cancel () {
                this.$router.go(-1);
            },
            async confirm () {
                this.confirmLoading = true;
                this.form.validateFields( async (err , values) => {
                    if (err) {
                        this.confirmLoading = false;
                        return false;
                    }
                    if (this.id){
                        const result_update = await reqUpdateTableData({
                            id: this.id,
                            ...values
                        });
                        const { code, message } = result_update.data;
                        code === 20000 && this.$message.success('修改数据成功!') && this.$router.go(-1);
                        code !== 20000 && this.$message.error(message);
                    } else {
                        const result_add = await reqAddTableData(values);
                        const { code, message } = result_add.data;
                        code === 20000 && this.$message.success('新增数据成功!') && this.$router.go(-1);
                        code !== 20000 && this.$message.error(message);
                    }
                    this.confirmLoading = false;
                })
            },
            async getAllColumn () {
                const result_column = await reqFindAllColumn({
                    showColumn: true,
                    tableId: this.$route.query.tableId
                });
                const { code, result, message } = result_column.data;
                if (code === 20000){
                    this.tableColumns = result;
                    console.log(result);
                } else {
                    this.$message.error(message);
                }
            },
            checkValues (rule, value, callBack) {
                const formId = rule.field;
                const dataType = this.tableColumns.filter( item => item.tableColumnEnglishName === formId)[0].dataType;
                if ((dataType === 2 || dataType === 3) && !Number(value)){
                    callBack('该字段只能填写数字类型');
                } else {
                    callBack();
                }
            }
        },
        components: {
            Title
        },
        mounted() {
            this.id = this.$route.query.editInfo.id;
            delete this.$route.query.editInfo.id;
            this.formData = this.$route.query.editInfo;
            this.getAllColumn();
        }
    }
</script>

<style lang="less">
    #search-form{
        .ant-form-item-label{
            white-space: nowrap;
            text-overflow:ellipsis;
            overflow: hidden;
        }
    }
</style>