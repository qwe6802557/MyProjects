<template>
    <div id="search-form">
        <Title :title="'筛选数据'"/>
        <div class="container">
            <div class="add-title">
                <i class="title-icon"/>
                筛选信息
            </div>
            <a-spin :spinning="spinning" tip="获取筛选信息中...">
                <a-form :form="form" style="width: 60%; overflow: hidden;">
                    <a-col :span="8" v-for="item in columns" :key="item.id">
                        <a-form-item :label="item.tableColumnChineseName"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select v-decorator="[
                                         item.tableColumnEnglishName,
                                         {   initialValue: '',
                                             }
                                            ]"
                                      placeholder="请选择标签" :loadng="dataTypeLoading">
                                <a-select-option value="">
                                    {{'全部'}}
                                </a-select-option>
                                <a-select-option v-for="cItem in item.tags" :value="cItem.tagId" :key="cItem.tagId">
                                    {{cItem.tagName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                </a-form>
            </a-spin>
        </div>
        <div class="modal-button">
            <a-button shape="round" type="primary" id="cancelButton" @click="cancel">取消</a-button>
            <a-button shape="round" type="primary" id="okButton" @click="confirm" :loading="confirmLoading">确定</a-button>
        </div>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import {reqGroupColumn} from "../../../api/tag";
    import {reqTableData} from "../../../api/schema";
    import { mapMutations} from 'vuex';
    export default {
        name: "SearchTable",
        data () {
            return {
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 17 }
                },
                dataTypeLoading: false,
                confirmLoading: false,
                spinning: false,
                columns: []
            }
        },
        methods: {
            cancel () {
                this.$router.go(-1);
            },
           async confirm () {
                this.confirmLoading = true;
                this.form.validateFields( async (err , values) => {
                    if (err) {
                        this.confirmLoading = false;
                        return false;
                    }
                    const tagIds = [];
                    for(const item in values){
                        tagIds.push(values[item]);
                    }
                    const search_condition = {
                        tableId: this.$route.query.tableId,
                        tagIds,
                        pageNumber: 1,
                        pageSize: 10
                    };
                    const result_table = await reqTableData(search_condition);
                    const { code, result, message } = result_table.data;
                    if (code === 20000){
                        this.$message.success('筛选成功!');
                        this.changeTableData(result);
                        this.changeTableId(this.$route.query.tableId);
                        this.changeTableTagsId(tagIds);
                        await this.$router.push({path: '/auth/tableData', query: { tableData: result, tagIds, tableId: this.$route.query.tableId }});
                    } else {
                        this.$message.error(message);
                    }
                    this.confirmLoading = false;
                })
            },
            async getColumnsAndData () {
                this.spinning = true;
                const result_columns = await reqGroupColumn({
                    tagGroupId: this.$route.query.tagGroupId
                });
                const { code, result, message } = result_columns.data;
                if (code === 20000){
                    this.columns = result;
                } else {
                    this.$message.error(message);
                }
                this.spinning = false;
            },
            ...mapMutations(['changeTableData', 'changeTableId', 'changeTableTagsId'])
        },
        components: {
            Title
        },
        mounted() {
            this.getColumnsAndData();
        }
    }
</script>

<style lang="less">
    #search-form{
        .ant-form-item-label{
            white-space: nowrap;
            text-overflow:ellipsis;
            overflow: hidden;
        }
    }
</style>