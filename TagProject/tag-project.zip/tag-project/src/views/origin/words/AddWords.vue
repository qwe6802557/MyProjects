<template>
    <div id="add-form">
        <Title :title="'新增字段'"/>
        <div class="container">
            <div class="add-title">
                <i class="title-icon"/>
                基本信息
            </div>
            <a-form :form="form" style="width: 60%; overflow: hidden;">
                    <a-col :span="12">
                        <a-form-item label="列序号"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'columnNumber',
                                         { initialValue: $route.query.words && $route.query.words.columnNumber || undefined }
                                            ]"
                                     placeholder="请输入列序号">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="12">
                        <a-form-item label="字段名"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'tableColumnChineseName',
                                         {   initialValue: $route.query.words && $route.query.words.tableColumnChineseName || undefined,
                                             rules: [{ required: true, message: '请输入字段名!' }] }
                                            ]"
                                     placeholder="请输入字段名">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="12" v-if="!$route.query.words">
                        <a-form-item label="字段英文名"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'tableColumnEnglishName',
                                         {
                                             initialValue: $route.query.words && $route.query.words.tableColumnEnglishName || undefined
                                         }
                                            ]"
                                     placeholder="请输入字段英文名">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="12" v-if="!$route.query.words">
                        <a-form-item label="数据类型"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select v-decorator="[
                                         'dataType',
                                         {   initialValue: $route.query.words && $route.query.words.dataType + 1,
                                             rules: [{ required: true, message: '请选择数据类型!' }] }
                                            ]"
                                     placeholder="请选择数据类型" :loaidng="dataTypeLoading">
                                <a-select-option v-for="item in dataType" :value="item.id" :key="item.id">
                                    {{item.name}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="12" v-if="!$route.query.words">
                        <a-form-item label="是否需要索引"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select v-decorator="[
                                             'hasIndex',
                                             {   initialValue: $route.query.words && String(Number($route.query.words.hasIndex)) || '0',
                                                 rules: [{ required: true, message: '请选择是否需要索引!' }] }
                                                ]"
                                      placeholder="请选择是否需要索引" @change="selectChange">
                                <a-select-option value="1">
                                    是
                                </a-select-option>
                                <a-select-option value="0">
                                    否
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="12">
                        <a-form-item label="是否需要展示"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select v-decorator="[
                                             'showColumn',
                                             {   initialValue: $route.query.words && String(Number($route.query.words.showColumn)) || '0',
                                                  }
                                                ]"
                                      placeholder="请选择是否需要展示">
                                <a-select-option value="1">
                                    是
                                </a-select-option>
                                <a-select-option value="0">
                                    否
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="12" v-if="showIndex && !$route.query.words">
                        <a-form-item label="索引名"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'indexName',
                                         {
                                             initialValue: $route.query.words && $route.query.words.indexName || undefined,
                                         }
                                            ]"
                                     placeholder="请输入索引名">
                            </a-input>
                        </a-form-item>
                    </a-col>
                    <a-col :span="12" v-if="!$route.query.words">
                        <a-form-item label="默认值"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-input v-decorator="[
                                         'defaultValue',
                                         { initialValue: $route.query.words && $route.query.words.defaultValue || undefined }
                                            ]"
                                     placeholder="请输入默认值">
                            </a-input>
                        </a-form-item>
                    </a-col>
            </a-form>
        </div>
        <div class="modal-button">
            <a-button shape="round" type="primary" id="cancelButton" @click="cancel">取消</a-button>
            <a-button shape="round" type="primary" id="okButton" @click="confirm" :loading="confirmLoading">确定</a-button>
        </div>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import { reqDataType, reqAddColumn, reqUpdateColumn } from "../../../api/schema";
    export default {
        name: "AddWords",
        data () {
            return {
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 12 }
                },
                showIndex: false,
                dataType: [],
                dataTypeLoading: false,
                confirmLoading: false
            }
        },
        methods: {
            cancel () {
                this.$router.go(-1);
            },
            confirm () {
                this.confirmLoading = true;
                this.form.validateFields( (err , values) => {
                    if (err) {
                        this.confirmLoading = false;
                        return false;
                    }
                    values.hasIndex = !!Number(values.hasIndex);
                    values.showColumn = !!Number(values.showColumn);
                    values.tableId = this.$route.query.tableId;
                    values.dataType = values.dataType - 1;
                    if (!this.$route.query.words){
                        reqAddColumn(values).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.$router.push('/auth/words');
                            code !== 20000 && this.$message.error(message);
                            this.confirmLoading = false;
                        })
                    } else {
                        values.id = this.$route.query.words.id;
                        reqUpdateColumn(values).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.$router.push('/auth/words');
                            code !== 20000 && this.$message.error(message);
                            this.confirmLoading = false;
                        })
                    }
                })
            },
            getDataType () {
                this.dataTypeLoading = true;
                reqDataType().then( res => {
                    const { code, message, result } = res.data;
                    if (code === 20000){
                        this.dataType = [];
                        let id = 0;
                        result.forEach( item => {
                            id++;
                            this.dataType.push({
                                id,
                                name: item
                            })
                        });
                    } else {
                        this.$message.error(message);
                    }
                    this.dataTypeLoading = false;
                });
            },
            selectChange (value) {
                this.showIndex = !!Number(value);
            }
        },
        components: {
            Title
        },
        mounted() {
            this.getDataType();
            if (this.$route.query.words && this.$route.query.words.indexName){
                this.showIndex = true;
            }
        }
    }
</script>

<style scoped>

</style>