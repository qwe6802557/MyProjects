<template>
    
</template>

<script>
    export default {
        name: "SearchWords"
    }
</script>

<style scoped>

</style>