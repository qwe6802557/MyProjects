<template>
    <div id="words">
        <Title :title="'表字段管理'"/>
        <div class="button-area">
            <a-select :value="tableValue" style="width: 120px;margin-right: 10px;" @change="changeValue" :loading="tableLoading">
                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">{{item.tableChineseName}}</a-select-option>
            </a-select>
            <a-button type="primary" icon="search" @click="showTable">查看</a-button>
            <a-button type="danger" icon="delete" @click="deleteMany" v-if="userInfo.admin">批量删除</a-button>
            <a-button icon="plus" @click="addSchema" :disabled="addDisabled" v-if="userInfo.admin">新建字段</a-button>
        </div>
        <a-spin :tip="tip" :spinning="spinning">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="pagination"
                     :rowKey="'id'"
                     :rowSelection="rowSelection"
                     @change="handleTableChange"
                     :scroll="{ y: 640}">
                <span slot="operation" slot-scope="text">
                    <a href="javascript:;" @click="editOperation(text)" v-if="userInfo.admin">编辑</a>
                    <a href="javascript:;" @click="deleteOperation(text.id)" v-if="userInfo.admin">删除</a>
                </span>
                <span slot="dataType" slot-scope="dataType">
                    {{dataType === 0 && '普通文本' ||
                    dataType === 1 && '长文本' ||
                    dataType === 2 && '数字' ||
                    dataType === 3 && '大数字'}}
                </span>
                <span slot="showColumn" slot-scope="showColumn">
                   <a-tag :color="showColumn === true? 'geekblue' : 'volcano'">
                        {{showColumn === true? '已展示' : '未展示'}}
                  </a-tag>
                </span>
            </a-table>
        </a-spin>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import { reqFindAllTable, reqFindAllColumn, reqDeleteColumn } from "../../../api/schema";
    import { Modal } from "ant-design-vue";
    import { mapState } from 'vuex';
    /*import SearchForm from "@/views/origin/schema/SearchForm";*/
    export default {
        name: "Words",
        data () {
            return {
                columns: [],
                dataSource: [],
                selectValue: [],
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize) {
                        this.pagination.pageSize = pageSize;
                    },
                    showQuickJumper: true,
                    showSizeChanger: false,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                rowSelection: {},
                drawerWidth: '300',
                searchLoading: false,
                drawerVisible: false,
                spinning: false,
                tableValue: '',
                tip: '获取数据中...',
                tableLoading: false,
                addDisabled: false,
                selectedId: [],
            }
        },
        methods: {
            tableInit () {
                this.columns = [
                    {
                        title: '列序号',
                        key: 'columnNumber',
                        dataIndex: 'columnNumber',
                    },
                    {
                        title: '主键ID',
                        key: 'id',
                        dataIndex: 'id',
                    },
                    {
                        title: '字段名',
                        key: 'tableColumnChineseName',
                        dataIndex: 'tableColumnChineseName',
                    },
                    {
                        title: '数据库字段名',
                        key: 'tableColumnEnglishName',
                        dataIndex: 'tableColumnEnglishName',
                    },
                    {
                        title: '数据类型',
                        key: 'dataType',
                        dataIndex: 'dataType',
                        scopedSlots: { customRender: 'dataType' }
                    },
                    {
                        title: '默认值',
                        key: 'defaultValue',
                        dataIndex: 'defaultValue',
                    },
                    {
                        title: '索引名',
                        key: 'indexName',
                        dataIndex: 'indexName',
                    },
                    {
                        title: '展示状态',
                        key: 'showColumn',
                        dataIndex: 'showColumn',
                        scopedSlots: { customRender: 'showColumn' }
                    },
                    {
                        title: '操作',
                        scopedSlots: { customRender: 'operation' }
                    },
                ];
                this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }
            },
            addSchema () {
                this.$router.push({ path: '/auth/addOrEditWords', query: { tableId: this.tableValue}});
            },
            drawerClose () {
                this.drawerVisible = false;
            },
            showTable () {
                this.getAllColumn();
            },
            getAllColumn () {
                this.spinning = true;
                reqFindAllColumn({
                    tableId: this.tableValue,
                    showColumn: false,
                    pageNumber: this.pagination.current,
                    pageSize: this.pagination.pageSize
                }).then( res => {
                    const { code, message, result } = res.data;
                    if (code === 20000){
                        this.dataSource = result.data;
                        this.pagination.total = result.total;
                    } else {
                        this.$message.error(message);
                    }
                    this.spinning = false;
                });
            },
            getAllTable () {
                this.tableLoading = true;
                this.addDisabled = true;
                reqFindAllTable({
                    hasCreate: true,
                    pageNumber: 1,
                    pageSize: 1000
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.selectValue = result;
                        this.tableValue = result[0].id;
                        this.getAllColumn();
                    } else {
                        this.$message.error(message);
                    }
                    this.tableLoading = false;
                    this.addDisabled = false;
                });
            },
            deleteOperation (id) {
                Modal.confirm({
                    title: '删除字段',
                    content: '确定要删除该字段吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteColumn({
                            ids: [id]
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllTable();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除字段',
                    content: '确定要批量删除这些字段吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteColumn({
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllTable();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            changeValue (value) {
                this.tableValue = value;
            },
            editOperation (row) {
                this.$router.push({ path: '/auth/addOrEditWords', query: { tableId: this.tableValue, words: row }})
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.showTable();
            },
        },
        computed: {
          ...mapState(['userInfo'])
        },
        components: {
            Title,
           /* SearchForm*/
        },
        mounted() {
            this.tableInit();
            this.getAllTable();
        }
    }
</script>

<style lang="less">
    #words{
        .button-area{
            text-align: left;
            padding-bottom: 3px;
        }
        .ant-btn{
            margin-right: 10px;
        }
    }
</style>