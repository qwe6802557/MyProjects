<template>
    <div id="upload-form">
        <Title :title="'新增文件'"/>
        <div class="container">
            <div class="conform-words">
                <div class="add-title">
                    <i class="title-icon"/>
                    确认字段
                </div>
                <div class="confirm-table">
                    <div class="finish-card">
                        <el-table
                                :data="tableData"
                                border
                                style="width: 100%;max-height: 700px;">
                            <el-table-column
                                    prop="sourceColumn"
                                    label="来源字段"
                                    width="180">
                            </el-table-column>
                            <el-table-column
                                    prop="tableColumn"
                                    label="表字段"
                                    width="180">
                                <template slot-scope="scope">
                                    <el-select v-model="scope.row.tableColumn" placeholder="请选择">
                                        <el-option value="" :label="'不导入'">
                                        </el-option>
                                        <el-option
                                                v-for="item in tableColumnList"
                                                :key="item.id"
                                                :label="item.tableColumnChineseName"
                                                :value="item.tableColumnChineseName">
                                        </el-option>
                                    </el-select>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    prop="sourceData"
                                    label="示例数据"
                                    width="180">
                            </el-table-column>
                        </el-table>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-button">
            <a-button shape="round" type="primary" id="cancelButton" @click="cancel">取消</a-button>
            <a-button shape="round" type="primary" id="okButton" @click="confirm" :loading="confirmLoading">确定导入</a-button>
        </div>
    </div>
</template>

<script type="text/jsx">
    import Title from '@/components/contentTitle';
    import {reqImportFile, reqPreImport} from "../../api/file";
    export default {
        name: "AddFile",
        data () {
            return {
                form: this.$form.createForm(this),
                dataTypeLoading: false,
                confirmLoading: false,
                columns: [],
                tableData: [],
                rowSelection: {},
                formItemLayout: {
                    labelCol: { span: 6 },
                    wrapperCol: { span: 18 }
                },
                xlsxTitleDtos: [],
                tableColumnList: [],
                selectValue: '',
            }
        },
        methods: {
            cancel () {
                this.$router.go(-1);
            },
            async confirm () {
                const map = new Map();
                const filterArr = this.tableData.filter(item => (!map.has(item.tableColumn) && map.set(item.tableColumn, 1)) || !item.tableColumn);
                if (filterArr.length !== this.tableData.length) {
                    return this.$message.warning('存在导入重复的表字段，请检查!');
                }
                const filterArr1 = filterArr.filter(item => !!item.tableColumn);
                const importObj = {
                    map: {}
                };
                importObj.importId = this.$route.query.file.id;
                filterArr1.map( item => {
                    importObj.map[this.tableColumnList.filter( cItem => cItem.tableColumnChineseName === item.tableColumn)[0].tableColumnEnglishName] = item.id;
                    return item;
                });

                this.confirmLoading = true;
                const result_confirm = await reqImportFile(importObj);
                const { code, message, result } = result_confirm.data;
                if (code === 20000){
                    this.$message.success(`总条数${result.total}条,已成功导入${result.ok},失败${result.no}`);
                    this.$router.go(-1);
                } else {
                    this.$message.error(message);
                }
                this.confirmLoading = false;
            },
            async getFileWords () {
                const result_words = await reqPreImport({
                    importId: this.$route.query.file.id
                });
                const { code, result, message } = result_words.data;
                if (code === 20000){
                    this.tableData = [];
                    this.tableColumnList = result.tableColumnList;
                    this.xlsxTitleDtos = result.xlsxTitleDtos;
                    for (const item of this.xlsxTitleDtos){
                        this.tableData.push({
                            id: item.id,
                            sourceColumn: item.titleName,
                            sourceData: item.value,
                            tableColumn: item.titleName,
                        });
                    }
                } else {
                    this.$message.error(message);
                }
            },
            selectChange (value) {
                this.tableId = value;
            },
            tableInit () {
                this.columns = [{
                    title: '已匹配到的文件字段',
                    dataIndex: 'frontColumn',
                    width: 370
                }, {
                    title: '查询文件字段',
                    dataIndex: 'searchColumn',
                }];
                this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }
            },
        },
        watch: {
            tableData (value) {

                value.map( item => {
                    let isExist = false;
                    this.tableColumnList.map( cItem => {
                        if (item.tableColumn === cItem.tableColumnChineseName){
                            isExist = true;
                        }
                    });

                    if (!isExist){
                        item.tableColumn = '';
                    }
                })
            }
        },
        components: {
            Title
        },
        mounted() {
            this.tableInit();
            this.getFileWords();
        }
    }
</script>

<style lang="less">
#upload-form{
    .el-upload__input{
        display: none;
    }
        .ant-table{
            width: 100%;
            th{
                text-align: center;
            }
        }
    .container{
        display: flex;
        flex-direction: row;
        padding: 24px 90px;
        .el-upload-dragger{
            width: 500px;
            height: 300px;
            i{
                margin-top: 90px;
            }
        }
        .ant-table-header{
            overflow-y: hidden;
        }
        .ant-card-body{
            max-width: 720px;
            overflow-x: auto;
        }
        .confirm-table{
            width: 100%;
        }
        .ant-row{
            text-align: center;
        }
    }
    .modal-button{
        padding-left: 150px !important;
    }
}
</style>