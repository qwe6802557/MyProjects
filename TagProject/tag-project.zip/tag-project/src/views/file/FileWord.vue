<template>
    <div id="file">
        <Title :title="title"/>
        <div class="button-area">
            <span style="margin-right: 5px;">表名称:</span>
            <a-select :value="tableValue" style="width: 150px;margin-right: 10px;" @change="changeValue" :loading="tableLoading" placeholder="请选择表名称">
                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">{{item.tableChineseName}}</a-select-option>
            </a-select>
            <span style="margin-right: 5px;">表字段:</span>
            <a-select :value="columnValue" style="width: 150px;margin-right: 10px;" @change="columnChange" :loading="tableLoading" placeholder="请选择表名称">
                <a-select-option  v-for="item in columnData" :value="item.id" :key="item.id">{{item.tableColumnChineseName}}</a-select-option>
            </a-select>
            <a-button type="primary" icon="search" @click="showTable">查看</a-button>
            <a-button type="danger" icon="delete" @click="deleteMany">批量删除</a-button>
            <a-button icon="plus" @click="addTagGroup">新增数据</a-button>
            <a-button type="primary" icon="pushpin" @click="changeHeader">筛选显示</a-button>
            <a-button icon="left"  style="float: right; margin-right: 0;" @click="$router.go(-1)">返回文件管理</a-button>
        </div>
        <a-spin :spinning="initLoading" tip="获取文件数据中...">
            <a-table class="tag-table"
                     :columns="columns"
                     :dataSource="dataSource"
                     :pagination="pagination"
                     :rowSelection="rowSelection"
                     :rowKey="'id'"
                     @change="handleTableChange">
                <span slot="tableId" slot-scope="tableId">
                    {{!!selectValue.filter( item => item.id === tableId )[0] && selectValue.filter( item => item.id === tableId )[0].tableChineseName || '-'}}
                </span>
                <template slot="operation" slot-scope="text">
                    <a href="javascript:;" @click="deleteOperation(text)">删除</a>
                </template>
            </a-table>
        </a-spin>
        <a-modal :title="modalTitle"
                 v-model="visible"
                 @ok="handleOk"
                 :class="showHeader? ['common-modal', 'personal-modal'] : ['common-modal', 'tagGroup-modal']"
                 :destroyOnClose="true"
                 :keyboard="true"
                 :maskClosable="false"
                 :closable="!showHeader"
                 :okText="'确认'"
                 :cancelText="'取消'"
                 :confirmLoading="confirmLoading">
            <div class="check-box-area" v-if="showHeader">
                <a-checkbox-group name="checkboxgroup"
                                  v-model="checkedHeader"
                                  :options="options">
                </a-checkbox-group>
            </div>
            <div class="add-tag-group" v-if="!showHeader">
                <a-form :form="form">
                    <a-col :span="24">
                        <a-form-item label="表名称"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'tableId',
                                                              {    initialValue: modalTableValue || undefined,
                                                                   rules: [
                                                                             {   required: true, message: '请选择表名称!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择表名称"
                                    @change="modalTableChange"
                            >
                                <a-select-option  v-for="item in selectValue" :value="item.id" :key="item.id">
                                    {{item.tableChineseName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                    <a-col :span="24">
                        <a-form-item label="表字段"
                                     :label-col="formItemLayout.labelCol"
                                     :wrapper-col="formItemLayout.wrapperCol">
                            <a-select
                                    v-decorator="[
                                                              'tableColumnId',
                                                              {    initialValue: modalColumnValue || undefined,
                                                                   rules: [ {   required: true, message: '请选择表字段!' }]
                                                              }
                                                            ]"
                                    placeholder="请选择表字段"
                            >
                                <a-select-option  v-for="item in modalColumnData" :value="item.id" :key="item.id">
                                    {{item.tableColumnChineseName}}
                                </a-select-option>
                            </a-select>
                        </a-form-item>
                    </a-col>
                </a-form>
            </div>
        </a-modal>
    </div>
</template>

<script>
    import Title from '@/components/contentTitle';
    import {reqFindAllColumn, reqFindAllTable} from "../../api/schema";
    import { Modal } from 'ant-design-vue';
    import {reqAllConfirmFile, reqConfirmFile, reqDeleteConfirm} from "../../api/file";
    export default {
        name: "FileWord",
        data () {
            return {
                columns: [],
                showHeader: false,
                uploadLoading: false,
                columnValue: '',
                editInfo:{
                    tagGroupName: '',
                    tableId: '',
                    id: ''
                },
                defaultColumns: [{
                    id: 1,
                    name: 'id',
                    title: '主键ID'
                }, {
                    id: 2,
                    name: 'tableId',
                    title: '表ID',
                },{
                    id: 3,
                    name: 'tableColumnId',
                    title: '表字段ID'
                }, {
                    id: 4,
                    name: 'tableColumnName',
                    title: '表字段名'
                }],
                options: [ { label: '主键ID', value: 'id' },
                    { label: '表ID', value: 'tableId' },
                    { label: '表字段ID', value: 'tableColumnId' },
                    { label: '表字段名', value: 'tableColumnName' }],
                showColumns: [],
                dataSource: [],
                columnData: [],
                initLoading: false,
                tableValue: '',
                selectValue: [],
                tableHeader: [],
                title: '重复字段管理',
                tableId: '',
                visible: false,
                confirmLoading: false,
                tableLoading: false,
                modalTitle: '新增数据',
                pagination: {
                    total: 0,
                    defaultCurrent: 1,
                    pageSize: 10,
                    current: 1,
                    showSizeChange (pageSize) {
                        this.pagination.pageSize = pageSize;
                    },
                    showQuickJumper: true,
                    showSizeChanger: false,
                    pageSizeOptions: ['10', '100', '1000', '5000']
                },
                rowSelection: {},
                checkedHeader: [],
                form: this.$form.createForm(this),
                formItemLayout: {
                    labelCol: { span: 7 },
                    wrapperCol: { span: 14 }
                },
                selectedId: '',
                modalTableValue: '',
                modalColumnData: '',
                modalColumnValue: ''
            }
        },
        methods: {
            getTableData () {
                this.tableLoading = true;
                reqFindAllTable({
                    hasCreate: true,
                    pageNumber: 1,
                    pageSize: 1000
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.selectValue = result;
                        this.tableValue = result[0].id;
                        this.getAllColumn();
                        this.getAllWords();
                    } else {
                        this.$message.error(message);
                    }
                    this.tableLoading = false;
                });
            },
            async getAllColumn () {
                this.tableLoading  = true;
                const result_column = await reqFindAllColumn({
                    tableId: this.tableValue,
                    showColumn: true
                });
                const { code, result, message } = result_column.data;
                if (code === 20000){
                    this.columnData = result;
                    result.length > 0 ? this.columnValue = result[0].id : this.columnValue = undefined
                } else {
                    this.$message.error(message);
                }
                this.tableLoading  = false;
            },
            async getAllWords () {
                this.initLoading = true;
                const result_word = await reqAllConfirmFile({
                    tableId: this.tableValue
                });
                const { code, result, message } = result_word.data;
                if (code === 20000){
                    this.dataSource = result;
                } else {
                    this.$message.error(message);
                }
                this.initLoading = false;
            },
            columnChange (value) {
                this.columnValue = value;
            },
            changeValue (value) {
                this.tableValue = value;
                this.getAllColumn();
            },
            showTable () {
                this.getAllWords();
            },
            tableInit () {
                this.showColumns = this.defaultColumns;
                this.showColumns.map(( item ) => {
                    if (item.scopedSlots){
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name,
                            scopedSlots: { customRender: item.name }
                        });
                    } else {
                        this.columns.push({
                            title: item.title,
                            key: item.name,
                            dataIndex: item.name
                        });
                    }
                    return item;
                });
                this.columns.push({
                    title: '操作',
                    scopedSlots: { customRender: 'operation' }
                });

                this.rowSelection = {
                    onChange: (selectedRowKeys) => {
                        this.selectedId = selectedRowKeys;
                    },
                    onSelect: (record, selected, selectedRows) => {
                        console.log(record, selected, selectedRows);
                    },
                    onSelectAll: (selected, selectedRows, changeRows) => {
                        console.log(selected, selectedRows, changeRows);
                    }
                }
            },
            changeHeader () {
                this.modalTitle = '筛选表头';
                this.showHeader = true;
                this.visible = true;
            },
            importData () {

            },
            editOperation (tagGroup) {
                this.$router.push({ path: '/auth/addFile', query: { file: tagGroup }})
            },
            showTag (tagGroup) {
                this.$router.push("/auth/tag/" + tagGroup.id);
            },
            deleteOperation (tagGroup) {
                Modal.confirm({
                    title: '删除数据',
                    content: '确定要删除 ' + tagGroup.tableColumnName + ' 吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteConfirm({
                            ids: [tagGroup.id]
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllWords();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            deleteMany () {
                if (this.selectedId.length === 0){
                    return this.$message.warning('请先选择批量删除项');
                }
                Modal.confirm({
                    title: '批量删除数据',
                    content: '确定要批量删除这些数据吗?',
                    okText: '确认',
                    cancelText: '取消',
                    onOk: () => {
                        reqDeleteConfirm({
                            ids: this.selectedId
                        }).then( res => {
                            const { code, message } = res.data;
                            code === 20000 && this.$message.success(message) && this.getAllWords();
                            code !== 20000 && this.$message.error(message);
                        })
                    }
                })
            },
            addTagGroup () {
                this.modalTableValue = this.tableValue;
                this.modalColumnData = this.columnData;
                this.modalColumnValue = this.columnValue;
                this.header = !this.header;
                this.visible = !this.visible;
            },
            handleChange(info) {
                if (info.file.status !== 'uploading') {
                    this.uploadLoading = true;
                }
                if (info.file.status === 'done') {
                    if (info.file.response.code === 20000){
                        this.$message.success(`上传成功!`);
                    } else {
                        this.$message.error(info.file.response.message);
                    }
                    this.uploadLoading = false;
                } else if (info.file.status === 'error') {
                    this.uploadLoading = false;
                    this.$message.error(`上传失败!`);
                }
            },
            handleOk () {
                if (this.showHeader){
                    const okColumns = [];
                    this.showColumns.map( item => {
                        this.checkedHeader.map( cItem => {
                            if (cItem === item.name){
                                if (item.scopedSlots){
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name,
                                        scopedSlots: { customRender: item.name }
                                    });
                                } else {
                                    okColumns.push({
                                        title: item.title,
                                        key: item.name,
                                        dataIndex: item.name
                                    });
                                }
                            }
                        });
                    });
                    okColumns.push({
                        title: '操作',
                        scopedSlots: { customRender: 'operation' }
                    });
                    this.columns = okColumns;
                    this.visible = false;
                } else {
                    this.form.validateFields( (err, values) => {
                        if (err){
                            return false;
                        }
                        this.confirmLoading = true;
                        reqConfirmFile(values).then( res => {
                            const { code, message } = res.data;
                            if (code === 20000){
                                this.$message.success(message);
                                this.getAllWords();
                            } else {
                                this.$message.error(message);
                            }
                            this.confirmLoading = false;
                            this.visible = false;
                        });
                    })
                }
            },
            modalTableChange (value) {
                this.modalTableValue = value;
                reqFindAllColumn({
                    tableId: this.modalTableValue,
                    showColumn: true
                }).then( res => {
                    const { code, result, message } = res.data;
                    if (code === 20000){
                        this.modalColumnData = result;
                        this.modalColumnValue = '';
                    } else {
                        this.$message.error(message);
                    }
                })
            },
            handleTableChange (pagination) {
                this.pagination.current = pagination.current;
                this.showTable();
            },
        },
        components:{
            Title
        },
        mounted() {
            this.getTableData();
            this.tableInit();
            this.checkedHeader = this.options.map( item => item.value);
        }
    }
</script>

<style lang="less">
    .tagGroup-modal{
        .ant-btn{
            margin-top: 20px;
        }
        .ant-input{
            background: #F7F9FA !important;
        }
        .ant-input:focus{
            background: #ffffff !important;
        }
        .ant-select-selection--single{
            background: #F7F9FA !important;
        }
    }
    .personal-modal{
        .ant-btn{
            &:nth-child(1){
                display: none;
            }
        }
        .ant-select-selection--single{
            background: #F7F9FA !important;
        }
    }
    .ant-checkbox-group-item{
        white-space: nowrap;
        text-overflow:ellipsis;
        overflow: hidden;
        width: 117px;
    }
</style>