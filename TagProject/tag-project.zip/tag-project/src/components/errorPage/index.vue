<template>
    <div class="page-404">
      <h1>页面不存在哦，请尝试访问其他网址☺</h1>
    </div>
</template>

<script>
    export default {
        name: "ErrorPage"
    }
</script>

<style scoped>

</style>
