/**
 * 首页统计
 */
import ajax from '@/api';
import Store from '@/vuex/store';

//获取省份分布图
export const reqProvinceMap = table => ajax('/statistics/distributionMap1', table, 'GET', Store.state.token);
//获取运营商分布图
export const reqMerchantMap = table => ajax('/statistics/distributionMap2', table, 'GET', Store.state.token);
//获取城市分布图
export const reqCityMap = table => ajax('/statistics/distributionMap3', table, 'GET', Store.state.token);
//获取次数分布图
export const reqCountMap = table => ajax('/statistics/distributionMap4', table, 'GET', Store.state.token);
//获取型号分布图
export const reqTypeMap = table => ajax('/statistics/distributionMap5', table, 'GET', Store.state.token);