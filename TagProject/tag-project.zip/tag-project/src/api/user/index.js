/**
 * 权限及用户管理
 * @returns {*}
 */
import ajax from '@/api';
import Store from '@/vuex/store';
//查询所有用户
export const reqFindAllUsers = () => ajax('/user/findAllUser', {}, 'GET', Store.state.token);
//增加用户
export const reqAddUser = userInfo => ajax('/user/addUser', userInfo, 'POST', Store.state.token);
//更新用户
export const reqUpdateUser = userInfo => ajax('/user/updateUser', userInfo, 'POST', Store.state.token);
//删除用户
export const reqDeleteUser = id => ajax('/user/deleteUser', id, 'GET', Store.state.token);