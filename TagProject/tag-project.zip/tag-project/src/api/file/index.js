/**
 * 文件管理
 */
import ajax from '@/api';
import Store from '@/vuex/store';

// 添加数据重复确认字段
export const reqConfirmFile = map => ajax('/file/addRepeatStandard', map, 'GET', Store.state.token);
//预导入表格数据
export const reqPreImport = file => ajax('/file/beforeImport', file, 'GET', Store.state.token);
//导入数据表格
export const reqImportFile = file => ajax('/file/confirmImport', file, 'POST', Store.state.token);
//删除表格文件接口
export const reqDeleteFile = file => ajax('/file/deleteFiles', file, 'POST', Store.state.token);
//删除表格文件重复确认
export const reqDeleteConfirm = file => ajax('/file/deleteRepeatStandard', file, 'POST', Store.state.token);
//查询所有数据重复确认字段
export const reqAllConfirmFile = file => ajax('/file/findAllRepeatStandard', file, 'GET', Store.state.token);
//表格文件查询接口
export const reqAllFile = file => ajax('/file/findFiles', file, 'GET', Store.state.token);
//导出表格文件接口
export const reqExportFile = file => ajax('/tableData/tableDataToFile', file, 'POST', Store.state.token, 'blob');