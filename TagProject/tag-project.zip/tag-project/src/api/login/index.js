/**
 * 登录请求管理
 * @returns {*}
 */
import ajax from '@/api';
//获取验证码ID
export const reqGetValidateId = () => ajax('/user/getCode');
//获取验证码图片
export const reqGetValidateImg = codeId => ajax('/user/getCodeImages', { codeId }, 'GET', '', 'arraybuffer');
//登录
export const reqLogin = userInfo => ajax('/user/login', userInfo, 'POST');
//判断用户是否登录
export const reqIsLogin = token => ajax('/user/isLogin', token, 'GET');
