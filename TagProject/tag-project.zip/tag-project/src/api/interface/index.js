/**
 * 接口管理
 * @returns {*}
 */
import ajax from '@/api';
import Store from '@/vuex/store';

//查询密钥
export const reqAllKey = key => ajax('/aliyunKey/findAllAliyunKey', key, 'GET', Store.state.token);
//添加密钥
export const reqAddKey = key => ajax('/aliyunKey/addAliyunKey', key, 'POST', Store.state.token);
//修改密钥
export const reqUpdateKey = key => ajax('/aliyunKey/updateAliyunKey', key, 'POST', Store.state.token);
//删除密钥
export const reqDeleteKey = key => ajax('/aliyunKey/deleteAliyunKey', key, 'GET', Store.state.token);
//查询数据模板
export const reqAllTemplate = template => ajax('/dataField/findDataField', template, 'GET', Store.state.token);
//增加数据模板
export const reqAddTemplate = template => ajax('/dataField/addDataField', template, 'POST', Store.state.token);
//删除数据模板
export const reqDeleteTemplate = template => ajax('/dataField/deleteDataField', template, 'GET', Store.state.token);
//第三方接口调用
export const reqInterfaceData = template => ajax('/interfaceCall/interfaceCall', template, 'POST', Store.state.token);