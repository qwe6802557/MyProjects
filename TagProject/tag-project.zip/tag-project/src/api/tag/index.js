/**
 * 标签管理请求
 * @returns {*}
 */
import ajax from '@/api';
import Store from '@/vuex/store';
//请求所有标签组
export const reqTagGroup = tag => ajax('/tag/findAllTagGroup', tag, 'GET', Store.state.token);
//请求所有标签组列表
export const reqTagGroupList = () => ajax('/tag/findAllTagGroupList', {}, 'GET', Store.state.token);
//添加标签组
export const reqAddTagGroup = tag => ajax('/tag/addTagGroup', tag, 'POST', Store.state.token);
//修改标签组
export const reqUpdateTagGroup = tag => ajax('/tag/updateTagGroup', tag, 'GET', Store.state.token);
//删除标签组
export const reqDeleteTagGroup = id => ajax('/tag/deleteTagGroup', id, 'POST', Store.state.token);
//查询标签组下的字段
export const reqGroupColumn = column => ajax('/tag/tagGroupIdToColumnTagList', column, 'GET', Store.state.token);
//请求所有标签
export const reqAllTag = tag => ajax('/tag/findAllTag', tag, 'GET', Store.state.token);
//添加标签
export const reqAddTag= tag => ajax('/tag/addTag', tag, 'POST', Store.state.token);
//修改标签
export const reqUpdateTag = tag => ajax('/tag/updateTag', tag, 'GET', Store.state.token);
//删除标签
export const reqDeleteTag = id => ajax('/tag/deleteTag', id, 'POST', Store.state.token);
//根据表ID获取标签列表
export const reqTagsByTableId = id => ajax('/tag/findAllTagByTableId', id, 'GET', Store.state.token);

