/**
 * 表请求管理
 * @returns {*}
 */
import ajax from '@/api';
import Store from '@/vuex/store';
//查询全部表
export const reqFindAllTable = pageInfo => ajax('/tableManagement/findAllTable', pageInfo, 'GET', Store.state.token);
//增加表
export const reqAddTable = table => ajax('/tableManagement/addTable', table, 'POST', Store.state.token);
//更新表
export const reqUpdateTable = table => ajax('tableManagement/updateTable', table, 'POST', Store.state.token);
//删除表
export const reqDeleteTable = id => ajax('/tableManagement/deleteTable', id, 'POST', Store.state.token);
//创建表
export const reqCreateTable = tableId => ajax('/tableManagement/createTable', tableId, 'GET', Store.state.token);
//查询全部表字段
export const reqFindAllColumn = column => ajax('/tableManagement/findAllTableColumn', column, 'GET', Store.state.token);
//增加表字段
export const reqAddColumn = column => ajax('/tableManagement/addTableColumn', column, 'POST', Store.state.token);
//更新表字段
export const reqUpdateColumn = column => ajax('tableManagement/updateTableColumn', column, 'POST', Store.state.token);
//删除表字段
export const reqDeleteColumn = id => ajax('/tableManagement/deleteTableColumn', id, 'POST', Store.state.token);
//获取表字段数据类型
export const reqDataType = () => ajax('/tableManagement/dataType', {}, 'GET', Store.state.token);
//根据字段ID查询字段类型
export const reqQueryDataType = data => ajax('/tableManagement/tableColumnToDataType', data, 'GET', Store.state.token);
//获取筛选表格数据
export const reqTableData = table => ajax('/tableData/queryTableData', table, 'POST', Store.state.token);
//添加筛选表格数据
export const reqAddTableData = table => ajax('/tableData/addTableData', table, 'POST', Store.state.token);
//更新筛选表格数据
export const reqUpdateTableData = table => ajax('/tableData/updateTableData', table, 'POST', Store.state.token);
//删除筛选表格数据
export const reqDeleteTableData = table => ajax('/tableData/deleteTableData', table, 'POST', Store.state.token);
//根据表ID查找表字段
export const reqFindTableColumn = tableId => ajax('/tableManagement/findColumnbyTableId', tableId, 'GET', Store.state.token);
//设置标签
export const reqSetTags = table => ajax('/tableData/addTableDataTags', table, 'POST', Store.state.token);