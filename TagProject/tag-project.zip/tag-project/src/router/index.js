import VueRouter from 'vue-router';
import Vue from 'vue';

Vue.use(VueRouter);

const routes = [{
    path: '/',
    name: 'App',
    redirect: '/login',
    component: () => import('@/App'),
    children: [{
        path: 'login',
        name: 'Login',
        component: () => import('@/views/login/Login')
    }, {
        path: 'auth',
        name: 'Layout',
        redirect: '/auth/home',
        component: () => import('@/views/layout/Layout'),
        children: [{
            path: 'home',
            name: 'Home',
            component: () => import('@/views/home/Home')
        }, {
            path: 'phone',
            name: 'Phone',
            component: () => import('@/views/phone/Phone')
        }, {
            path: 'tagGroup',
            name: 'TagGroup',
            component: () => import('@/views/tag/TagGroup')
        }, {
            path: 'tag/:tableId/:tagGroupId',
            name: 'Tag',
            component: () => import('@/views/tag/Tag')
        }, {
            path: 'schema',
            name: 'Schema',
            component: () => import('@/views/origin/schema/Schema')
        }, {
            path: 'addOrEditSchema',
            name: 'AddSchema',
            component: () => import('@/views/origin/schema/AddSchema')
        }, {
            path: 'words',
            name: 'Words',
            component: () => import('@/views/origin/words/Words')
        }, {
            path: 'addOrEditWords',
            name: 'AddWords',
            component: () => import('@/views/origin/words/AddWords')
        }, {
            path: 'authority',
            name: 'Authority',
            component: () => import('@/views/authority/Authority')
        }, {
            path: 'addOrEditUser',
            name: 'AddUser',
            component: () => import('@/views/authority/AddUser')
        }, {
            path: 'interfaceKey',
            name: 'InterfaceKey',
            component: () => import('@/views/interface/InterfaceKey')
        }, {
            path: 'interface',
            name: 'Interface',
            component: () => import('@/views/interface/Interface')
        }, {
            path: 'interfaceData',
            name: 'InterfaceData',
            component: () => import('@/views/interface/InterfaceData')
        }, {
            path: 'file',
            name: 'File',
            component: () => import('@/views/file/File')
        }, {
            path: 'fileWord',
            name: 'FileWord',
            component: () => import('@/views/file/FileWord')
        }, {
            path: 'addFile',
            name: 'AddFile',
            component: () => import('@/views/file/AddFile')
        }, {
            path: 'tableData',
            name: 'Table',
            component: () => import('@/views/origin/table/Table')
        }, {
            path: 'searchTable',
            name: 'SearchTable',
            component: () => import('@/views/origin/table/SearchTable')
        }, {
            path: 'addTable',
            name: 'AddTable',
            component: () => import('@/views/origin/table/AddTable')
        }]
    }]
}];

export default new VueRouter({
    routes
});