import ajax from "./index";

// 登录请求
export const reqLogin = data => ajax('/auth', data, 'POST', true);
// 获取收据请求
export const reqPayment = data => ajax('/user/payment', {}, 'GET');
// 获取个人资料
export const reqProfile = data => ajax('/user/profile', {}, 'GET');
// 获取保险资料1
export const reqHomePolicy = data => ajax('/user/homepolicy', {}, 'GET');
// 获取保险资料2
export const reqAutoPolicy = data => ajax('/user/autopolicy', {}, 'GET');
// 车保险单付款
export const reqPayAuto = data => ajax('/user/payauto', data, 'POST');
// 房屋保险单付款
export const reqPayHome = data => ajax('/user/payhome', data, 'POST');
// 动态查询
export const reqAdmin = () => ajax('/admin', {}, 'GET');
// 更新个人信息
export const reqUpdateSelf = data => ajax('/update/customer', data, 'POST');
// 更新车辆保险
export const reqUpdateAuto = data => ajax('/update/autopolicy', data, 'POST');
// 更新房屋保险
export const reqUpdateHome = data => ajax('/update/homepolicy', data, 'POST');
// 删除个人信息
export const reqDeleteSelf = data => ajax('/delete/customer', data, 'POST');
// 删除车辆保险
export const reqDeleteAuto = data => ajax('/delete/autopolicy', data, 'POST');
// 删除房屋保险
export const reqDeleteHome = data => ajax('/delete/homepolicy', data, 'POST');