import React, { Component } from "react";
import './App.css';
import {BrowserRouter, Redirect, Route, Switch} from 'react-router-dom'
import Router from '@/router'

export default class App extends Component{

    render() {
        return (
            <div className="App">
                <BrowserRouter>
                    <Switch>
                        <Route path="/login" component={Router.Login} />
                        <Route path="/" component={Router.Layout} />
                        <Redirect to="/login"/>
                    </Switch>
                </BrowserRouter>
            </div>
        );
    }
}
