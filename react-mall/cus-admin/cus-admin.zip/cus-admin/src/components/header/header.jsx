import React, { Component } from "react";
import { withRouter, Link } from 'react-router-dom';
import {Menu, Dropdown, Avatar, /*message,*/ Form, Input, Modal as AntdModal} from 'antd';
import Modal from "@/components/modal/modal";
/*import { Modal as AntdModal } from 'antd';*/
import './header.less';
import storeUntil from "@/utils/storeUntil";
import {
    MailOutlined,
    AppstoreOutlined,
    SettingOutlined,
    ExclamationCircleOutlined,
    DownOutlined,
    /*ExclamationCircleOutlined*/
} from '@ant-design/icons';
const { Item } = Form;

class Header extends Component{
    state = {
        current: this.props.location.pathname,
        editInfo: {},
        modalVisible: false,
        userInfo: storeUntil.getInfo(),
    };

    handleClick = e => {
        this.setState({
            current: e.key,
        });
    };

    updateUser () {
        this.setState({
            modalVisible: true,
        });
    }

    getUserInfo = () => {
       /* reqUserInfo(this).then( res => {
           const { code, messageBody } = res.data;

           if (code === 0){
               this.setState({
                   editInfo: messageBody
               });
           } else {
               message.error(res.data.message);
           }

        })*/
    };

    loginOut = () => {
        const that = this;
        AntdModal.confirm({
            title: `确定退出系统?`,
            icon: <ExclamationCircleOutlined />,
            content: '退出后将重新登录',
            okText: '退出',
            cancelText: '取消',
            onOk() {
                storeUntil.delInfo();
                that.props.history.push({ pathname: '/login'});
            },
            onCancel() {}})
    };

    menuBorn = () => {
        return (
            <Menu>
                <Menu.Item>
                    <span onClick={this.updateUser.bind(this)}>修改个人资料</span>
                </Menu.Item>
                <Menu.Item>
                    <span onClick={this.loginOut}>注销账户</span>
                </Menu.Item>
            </Menu>
        )
    };

    componentDidMount() {
        this.getUserInfo();
    }

    render() {
        const { editInfo, modalVisible } = this.state;
        const addModal = {
            title: '编辑资料',
            okText: '确定',
            cancelText: '取消',
            visible: modalVisible,
            destroyOnClose: false,
            onOk: () => {
                this.props.form.validateFields((err, values) => {
                    if (err){
                        return false;
                    }
                        values._id = editInfo._id;
                        /*reqUpdateUser(values).then( res => {
                            const { code, messageBody } = res.data;

                            if (code === 0){
                                message.success(res.data.message);
                                this.setState({
                                    editInfo: messageBody,
                                })
                            } else {
                                message.error(res.data.message);
                            }
                        });*/
                    this.setState({
                        modalVisible: false,
                    }, () => {
                        this.props.form.resetFields();
                    });
                });
            },
            onCancel: () => {
                this.setState({
                    modalVisible: false,
                }, () => {
                    this.props.form.resetFields();
                });
            }
        };

        const { getFieldDecorator } = this.props.form;

        const formItemLayout = {
            labelCol:{ span:6 },
            wrapperCol:{ span:15 },
        };

        return (
           <div id="header">
               <Menu onClick={this.handleClick} selectedKeys={[this.state.current]} mode="horizontal" style={{textAlign: 'center'}}>
                   <Menu.Item key="/home">
                       <Link to="/home">
                           <SettingOutlined/>
                           个人中心
                       </Link>
                   </Menu.Item>
                   <Menu.Item key="/receipt">
                       <Link to="/receipt">
                       <MailOutlined />
                       收据管理
                       </Link>
                   </Menu.Item>
                   {
                       this.state.userInfo.group === 1 ? (<Menu.Item key="/search">
                           <Link to="/search">
                               <AppstoreOutlined />
                               动态查询
                           </Link>
                       </Menu.Item>) : null
                   }
                   <div style={{float: 'right', marginRight: '50px'}}>
                       <Dropdown overlay={this.menuBorn()}>
                           <a href="https://ant.design" className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                               <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" style={{ marginRight: '5px'}}/>
                               <span style={{marginRight: '15px'}}>{ this.state.userInfo.username ? this.state.userInfo.username : ''}</span>
                               <DownOutlined />
                           </a>
                       </Dropdown>
                   </div>
               </Menu>
               <Modal {...addModal}>
                   <Form layout="horizontal">
                       <Item label="用户名" {...formItemLayout}>
                           {getFieldDecorator('userName', {
                               initialValue: editInfo.userName ? editInfo.userName : undefined,
                               rules:[
                                   {
                                       required:true,
                                       message:'请输入用户名'
                                   }
                               ]
                           })(<Input  placeholder="请输入"/>)}
                       </Item>
                       <Item label="密码" {...formItemLayout}>
                           {getFieldDecorator('passWord', {
                               initialValue: undefined,
                               rules:[
                                   {
                                       required:true,
                                       message:'请输入密码'
                                   }
                               ]
                           })(<Input  placeholder="请输入" type="password"/>)}
                       </Item>
                       <Item label="邮箱" {...formItemLayout}>
                           {getFieldDecorator('eMail', {
                               initialValue: editInfo.eMail ? editInfo.eMail : undefined,
                               rules:[
                                   {
                                       required:true,
                                       message:'请输入邮箱'
                                   }
                               ]
                           })(<Input  placeholder="请输入"/>)}
                       </Item>
                       <Item label="电话号码" {...formItemLayout}>
                           {getFieldDecorator('mobile', {
                               initialValue: editInfo.mobile ? editInfo.mobile : undefined,
                               rules:[
                                   {
                                       required:true,
                                       message:'请输入电话号码'
                                   }
                               ]
                           })(<Input  placeholder="请输入"/>)}
                       </Item>
                       <Item label="年龄" {...formItemLayout}>
                           {getFieldDecorator('age', {
                               initialValue: editInfo.age ? editInfo.age : undefined,
                               rules:[
                                   {
                                       required:true,
                                       message:'请输入年龄'
                                   }
                               ]
                           })(<Input  placeholder="请输入"/>)}
                       </Item>
                       <Item label="性别" {...formItemLayout}>
                           {getFieldDecorator('sex', {
                               initialValue: editInfo.sex ? editInfo.sex : undefined,
                               rules:[
                                   {
                                       required:true,
                                       message:'请输入性别'
                                   }
                               ]
                           })(<Input  placeholder="请输入"/>)}
                       </Item>
                       <Item label="居住地址" {...formItemLayout}>
                           {getFieldDecorator('address', {
                               initialValue: editInfo.address ? editInfo.address : undefined,
                               rules:[
                                   {
                                       required:true,
                                       message:'请输入居住地址'
                                   }
                               ]
                           })(<Input  placeholder="请输入"/>)}
                       </Item>
                   </Form>
               </Modal>
           </div>
        );
    }
}
const wrapForm = Form.create()(Header);
export default withRouter(wrapForm);