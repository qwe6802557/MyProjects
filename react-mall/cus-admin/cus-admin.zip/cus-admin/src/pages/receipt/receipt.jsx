import React, { Component } from "react";
import Title from '@/components/contentTitle/contentTitle';
import Table from '@/components/table/table';
import Modal from "@/components/modal/modal";
import {message, Modal as AntModal} from 'antd';
import { DownOutlined } from '@ant-design/icons';
import {/*message,*/ Input, Form, Tabs, Dropdown, Menu, Button} from 'antd';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import {reqPayAuto, reqPayHome, reqPayment} from "../../api/main";
const {  TabPane } = Tabs;
/*const { Search } = Input;*/
const { Item } = Form;

class Receipt extends Component{
    state = {
        dataSource: [],
        dataSource1: [],
        pagination: {
            total: 0,
            current: 1,
            pageSize: 10,
            onChange: this.pageChange
        },
        modalVisible: false,
        editInfo: {},
    };

    pageChange = (current) => {
        this.setState({
            pagination: Object.assign({}, this.state.pagination, {current})
        })
    };

    menu (data) {
         return (
             <Menu>
                 <Menu.Item>
                     <span target="_blank" rel="noopener noreferrer" href="javacript:;" onClick={this.operation.bind(this, data,'PAYPAL')}>
                         PAYPAL
                     </span>
                 </Menu.Item>
                 <Menu.Item>
                     <span target="_blank" rel="noopener noreferrer" href="javacript:;" onClick={this.operation.bind(this, data,'CHECK')}>
                         CHECK
                     </span>
                 </Menu.Item>
                 <Menu.Item>
                     <span target="_blank" rel="noopener noreferrer" href="javacript:;" onClick={this.operation.bind(this, data,'DEBIT', true)}>
                         DEBIT
                     </span>
                 </Menu.Item>
                 <Menu.Item>
                     <span target="_blank" rel="noopener noreferrer"  onClick={this.operation.bind(this, data,'CREDIT', true)}>
                         CREDIT
                     </span>
                 </Menu.Item>
             </Menu>
         )
    }

    menu1 (data) {
        return (<Menu>
            <Menu.Item>
                <span  rel="noopener noreferrer" onClick={this.operation.bind(this, data, 'PAYPAL', false)}>
                    PAYPAL
                </span>
            </Menu.Item>
            <Menu.Item>
                <span  rel="noopener noreferrer" onClick={this.operation.bind(this, data, 'CHECK', false)}>
                    CHECK
                </span>
            </Menu.Item>
            <Menu.Item>
                <span  rel="noopener noreferrer" onClick={this.operation.bind(this, data,'DEBIT', false)}>
                    DEBIT
                </span>
            </Menu.Item>
            <Menu.Item>
                <span  rel="noopener noreferrer"  onClick={this.operation.bind(this, data,'CREDIT', false)}>
                    CREDIT
                </span>
            </Menu.Item>
        </Menu>)
    }

    editWords (data) {
        this.setState({
            editInfo: data,
            modalVisible: true
        });
    }

    async operation (data, method, type) {

        console.log(data);

        if (!type){
            await reqPayHome({
                inv_id: data.h_inv_id,
                method,
            });
        } else {
            await reqPayAuto({
                inv_id: data.a_inv_id,
                method,
            });
        }

        message.success('付款成功!');
        this.getPayment();
    }

    getPayment = () => {
        reqPayment().then( res => {
            const { invoice } = res.data;

            this.setState({
                dataSource: invoice.auto_payment,
                dataSource1: invoice.home_payment
            });
        });
    };

    deleteWords (data) {
        /*const that = this;*/
        AntModal.confirm({
            title: `确定删除${data.userName}?`,
            icon: <ExclamationCircleOutlined />,
            content: '删除后将无法复原',
            onOk() {
               /* reqDeleteUser({
                    _id: data._id,
                }).then( res => {
                    const { code } = res.data;

                    if (code === 0){
                        message.success(res.data.message);
                        that.getClassMateData();
                    } else {
                        message.error(res.data.message);
                    }
                });*/
            },
            onCancel() {}})
    }

    searchData (value) {
        console.log(value);
        this.getClassMateData(value);
    }

    tableInit = () => {
        this.columns = [
            {
                title: '收款证编号',
                dataIndex: 'a_inv_id',
                key: 'a_inv_id',
                render:(data) => (<span>{data?data:'-'}</span>)
            },
            {
                title: '应付金额',
                dataIndex: 'a_amt_due',
                key: 'a_amt_due',
                render:(data) => (<span>{data?data + '.00':'-'}</span>)
            },
            {
                title: '截止日期',
                dataIndex: 'h_due_date',
                key: 'h_due_date',
                render:(data) => (<span>{data?data:'-'}</span>)
            },
            {
                title: '付款日期',
                dataIndex: 'a_paid_date',
                key: 'a_paid_date',
                render:(data) => (<span>{data?data:'-'}</span>),
            },
            {
                title: '付款方式',
                dataIndex: 'a_pay_method',
                key: 'a_pay_method',
                render:(data) => (<span>{data?data:'-'}</span>),
            },
            {
                title: '操作',
                render:(data) => {
                    return (
                        <div>
                            {
                                !data.a_pay_method ? (
                                    <Dropdown overlay={this.menu.bind(this, data)}>
                                        <Button  type="link" className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                            选择付款方式 <DownOutlined />
                                        </Button>
                                    </Dropdown>
                                ) : null
                            }
                        </div>
                    )
                }
            },
        ];

        this.columns1 = [
            {
                title: '收款证编号',
                dataIndex: 'h_inv_id',
                key: 'h_inv_id',
                render:(data) => (<span>{data?data : '-'}</span>)
            },
            {
                title: '应付金额',
                dataIndex: 'h_amt_due',
                key: 'h_amt_due',
                render:(data) => (<span>{data?data + '.00':'-'}</span>)
            },
            {
                title: '截止日期',
                dataIndex: 'h_due_date',
                key: 'h_due_date',
                render:(data) => (<span>{data?data:'-'}</span>)
            },
            {
                title: '付款日期',
                dataIndex: 'h_paid_date',
                key: 'h_paid_date',
                render:(data) => (<span>{data?data:'-'}</span>),
            },
            {
                title: '付款方式',
                dataIndex: 'h_pay_method',
                key: 'h_pay_method',
                render:(data) => (<span>{data?data:'-'}</span>),
            },
            {
                title: '操作',
                render:(data) => {
                    return (
                        <div>
                            {
                                !data.h_pay_method ? (
                                    <Dropdown overlay={this.menu1.bind(this, data)}>
                                        <Button type="link" className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                            选择付款方式 <DownOutlined />
                                        </Button>
                                    </Dropdown>
                                ) : <span>-</span>
                            }
                        </div>
                    )
                }
            },
        ];
    };

    getClassMateData = (value) => {
     /*   const { /!*current, pageSize*!/ } = this.state.pagination;*/
        /*reqUserList({
            curPage: current,
            pageSize: pageSize,
            username: value ? value : ''
        }).then( res => {
            const { code, messageBody } = res.data;

            if (code === 0){
                this.setState({
                    dataSource: messageBody.data,
                    pagination: Object.assign({}, this.state.pagination, { total: messageBody.total})
                });
            } else {
                message.error(res.data.message);
            }
        });*/
    };

    addWords () {
        this.setState({
            modalVisible: true,
        })
    }

    callback () {

    }

    componentDidMount() {
        this.getClassMateData();
        this.tableInit();
        this.getPayment();
    }

    render() {
        const {  dataSource, modalVisible, editInfo, dataSource1 } = this.state;
        const { getFieldDecorator } = this.props.form;

        const formItemLayout = {
            labelCol:{ span:6 },
            wrapperCol:{ span:15 },
        };

        const addModal = {
            title: editInfo._id ? '编辑信息' : '添加信息',
            okText: '确定',
            cancelText: '取消',
            visible: modalVisible,
            destroyOnClose: false,
            onOk: () => {
                this.props.form.validateFields((err, values) => {
                    if (err){
                        return false;
                    }

                    if (editInfo._id){
                        values._id = editInfo._id;
                        /*reqUpdatePhone(values).then( res => {
                            const { code } = res.data;

                            if (code === 0){
                                message.success(res.data.message);
                                this.getClassMateData();
                            } else {
                                message.error(res.data.message);
                            }
                        });*/
                    } else {
                        /*reqAddPhone(values).then( res => {
                            const { code } = res.data;

                            if (code === 0){
                                message.success(res.data.message);
                                this.getClassMateData();
                            } else {
                                message.error(res.data.message);
                            }
                        });*/
                    }
                    this.setState({
                        modalVisible: false,
                        editInfo: {}
                    }, () => {
                        this.props.form.resetFields();
                    });
                });
            },
            onCancel: () => {
                this.setState({
                    modalVisible: false,
                    editInfo: {}
                }, () => {
                    this.props.form.resetFields();
                });
            }
        };

        return (<div className="classmate-words">
            <Title title={'收据管理'}/>
            <Tabs defaultActiveKey="1" onChange={this.callback.bind(this)} style={{textAlign: 'left',marginTop: '10px'}}>
                {
                    dataSource.length > 0 ? (
                        <TabPane tab="车辆保险收据" key="1">
                            <Table pagination={false} dataSource={dataSource} columns={this.columns}/>
                        </TabPane>
                    ) : ''
                }
                <TabPane tab="房屋保险收据" key="2">
                    <Table pagination={false} dataSource={dataSource1} columns={this.columns1}/>
                </TabPane>
            </Tabs>,

            <Modal {...addModal}>
                <Form layout="horizontal">
                    <Item label="QQ号码" {...formItemLayout}>
                        {getFieldDecorator('qq', {
                            initialValue: editInfo.qq ? editInfo.qq : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入QQ号码'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                    <Item label="微信号" {...formItemLayout}>
                        {getFieldDecorator('wechat', {
                            initialValue: editInfo.wechat ? editInfo.wechat : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入微信号'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                    <Item label="电话号码" {...formItemLayout}>
                        {getFieldDecorator('mobile', {
                            initialValue: editInfo.mobile ? editInfo.mobile : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入电话号码'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                </Form>
            </Modal>
        </div>);
    }
}
const wrapForm = Form.create()(Receipt);

export default wrapForm;