import React,{ Component } from "react";
import { Form, Icon, Checkbox, Input, Button, message } from 'antd';
import { reqLogin } from "@/api/main";
import './login.less';
import storeUntil from "@/utils/storeUntil";
const { Item } = Form;
class Login extends Component {

    state = {
        loading: false,
    };

    cssInit () {
        const loginDom = document.querySelector('#login');

        loginDom.style.height = document.documentElement.clientHeight + 'px';
    };

    getValidateCode () {

    }

    async login(){
        this.props.form.validateFields( async (err, value) => {
           if (err){
               return false;
           }

            const result = await reqLogin(value);
            message.success('登录成功!');
            storeUntil.setInfo(result.data.user);
            this.props.history.push('/home');
        });
    }

    toRegister(){
        this.props.history.push('/register');
    };

    componentDidMount() {
        this.cssInit();
    }

    render() {
        const { getFieldDecorator } = this.props.form;
        const { loading } = this.state;
        const formItemLayout = {
            labelCol:{ span: 8 },
            wrapperCol:{ span: 15 },
        };

        return (<div id="login">
            <div className="login-box">
                <div className="right-box">
                    <h1>用户登录</h1>
                    <Form layout="horizontal">
                        <Item  {...formItemLayout}>
                            {getFieldDecorator('username', {
                                rules:[
                                    {
                                        required:true,
                                        message:'请输入用户名'
                                    }
                                ]
                            })(<Input
                                placeholder="请输入用户名/手机号/邮箱"
                                prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                                type="text"
                            />)}
                        </Item>
                        <Item  {...formItemLayout}>
                            {getFieldDecorator('password', {
                                rules:[
                                    {
                                        required:true,
                                        message:'请输入密码'
                                    }
                                ]
                            })(<Input
                                prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                                placeholder="请输入密码"
                                type="password"/>)}
                        </Item>
                       {/*<Item  {...formItemLayout}>
                            {getFieldDecorator('verifyCode', {
                                rules:[
                                    {
                                        required:true,
                                        message:'请输入验证码'
                                    }
                                ]
                            })(<Input
                                prefix={<Icon type="safety-certificate" style={{ color: 'rgba(0,0,0,.25)' }} />}
                                placeholder="请输入验证码"
                                type="text"/>)}
                            <div id="verify" onClick={this.getValidateCode}/>
                        </Item>*/}
                        <Item>
                            {getFieldDecorator('remember', {
                                valuePropName: 'checked',
                                initialValue: true,
                            })(<Checkbox>记住此次登录信息</Checkbox>)}
                            <Button type="primary" htmlType="submit" className="login-form-button" loading={loading} onClick={this.login.bind(this)}>
                                登录
                            </Button>
                           {/* <div className="register">
                                还没有账号?<span onClick={this.toRegister.bind(this)}>立即注册</span>
                            </div>*/}
                        </Item>
                    </Form>
                </div>
            </div>
        </div>);
    }
}

const wrapForm = Form.create()(Login);

export default wrapForm;