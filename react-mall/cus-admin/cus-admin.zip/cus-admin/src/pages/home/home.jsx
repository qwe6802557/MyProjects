import React,{ Component } from "react";
import Title from '@/components/contentTitle/contentTitle';
import {Descriptions, Button, Modal as AntdModal, Input, Form, Radio, message} from 'antd';
import  { ExclamationCircleOutlined } from '@ant-design/icons';
import  Modal from '@/components/modal/modal';
import './home.less';
import {
    reqDeleteAuto,
    reqDeleteHome,
    reqDeleteSelf,
    reqProfile,
    reqUpdateAuto,
    reqUpdateHome,
    reqUpdateSelf
} from "../../api/main";
const { Item } = Form;
class Home extends Component{
    state = {
        userInfo: '',
        policy: '',
        editInfo: {},
        modalVisible: false,
        modalVisible1: false,
    };

    getProfile = async () => {
      const result = await reqProfile();

       const { customer, policy } = result.data;

       this.setState({
           userInfo: customer,
           policy
       });
    };

    deleteOperation (data, flag) {
        AntdModal.confirm({
            title: '删除',
            icon: <ExclamationCircleOutlined />,
            content: '确定要删除吗',
            okText: '删除',
            cancelText: '取消',
            onOk:async () => {
                if (flag === 1){
                    await reqDeleteSelf({
                        c_id: data.c_id
                    });
                } else if (flag === 2){
                    await reqDeleteAuto({
                        a_id: data.ap_id
                    });
                } else {
                    await reqDeleteHome({
                        h_id: data.hp_id
                    });
                }

                message.success('删除成功!');
                this.getProfile();
            },
            onCancel() {
                console.log('Cancel');
            },
        });
    }

    updatePerson () {
        this.setState({
            editInfo: this.state.userInfo,
            modalVisible: true,
        });
    }

    updateAuto () {
        this.setState({
            editInfo: this.state.policy.auto_policy,
            modalVisible1: true,
        });
    }

    updateHome () {
        this.setState({
            editInfo: this.state.policy.home_policy,
            modalVisible1: true,
        });
    }

    componentDidMount() {
        this.getProfile();
    }

    render() {
        const { userInfo, policy, editInfo, modalVisible, modalVisible1 } = this.state;
        const { getFieldDecorator } = this.props.form;

        const formItemLayout = {
            labelCol:{ span:6 },
            wrapperCol:{ span:15 },
        };

        const addModal = {
            title: '更新信息',
            okText: '确定',
            cancelText: '取消',
            visible: modalVisible,
            destroyOnClose: false,
            onOk: () => {
                this.props.form.validateFields(['c_fname', 'c_lname', 'c_gender', 'c_marital_stat', 'c_instal'], async (err, values) => {
                    if (err){
                        return false;
                    }

                    values.firstname = values.c_fname;
                    values.lastname = values.c_lname;
                    values.gender = values.c_gender;
                    values.marital = values.c_marital_stat;
                    values.installment = values.c_instal;

                    await reqUpdateSelf(values);

                    message.success('更新成功!');
                    this.getProfile();
                    this.setState({
                        modalVisible: false,
                    }, () => {
                        this.props.form.resetFields();
                    });
                });
            },
            onCancel: () => {
                this.setState({
                    modalVisible: false,
                    editInfo: {}
                }, () => {
                    this.props.form.resetFields();
                });
            }
        };

        const otherModal = {
            title: '更新信息',
            okText: '确定',
            cancelText: '取消',
            visible: modalVisible1,
            destroyOnClose: false,
            onOk: () => {
                this.props.form.validateFields( ['end_date', 'stat', 'premium'], async (err, values) => {
                    if (err){
                        return false;
                    }

                    if (this.state.editInfo.ap_stat){
                        await reqUpdateAuto(values);
                    } else {
                        await reqUpdateHome(values);
                    }
                    message.success('更新成功!');
                    this.getProfile();
                    this.setState({
                        modalVisible1: false,
                    }, () => {
                        this.props.form.resetFields();
                    });
                });
            },
            onCancel: () => {
                this.setState({
                    modalVisible1: false,
                    editInfo: {}
                }, () => {
                    this.props.form.resetFields();
                });
            }
        };

        return (<div id="home">
            <Title title={'个人中心'}/>
                {
                    userInfo && userInfo.c_fname ? (
                        <div className="container">
                        <div className="button-area">
                            <Button type="link" onClick={this.updatePerson.bind(this)}>更新</Button>
                            <Button type="link" onClick={this.deleteOperation.bind(this, userInfo, 1)}>删除</Button>
                        </div>
                        <Descriptions title="用户个人信息" bordered>
                            <Descriptions.Item label="姓">{userInfo.c_fname ? userInfo.c_fname : null}</Descriptions.Item>
                            <Descriptions.Item label="名">{userInfo.c_lname ? userInfo.c_lname : null}</Descriptions.Item>
                            <Descriptions.Item label="性别" span={3}>{userInfo.c_gender && userInfo.c_gender === 'M' ? '男' : '女'}</Descriptions.Item>
                            <Descriptions.Item label="是否分期">{userInfo.c_instal && userInfo.c_instal === '0' ? '是' : '否'}</Descriptions.Item>
                            <Descriptions.Item label="婚姻">{userInfo.c_marital_stat && userInfo.c_marital_stat === 'S' ? '未婚' : '已婚'}</Descriptions.Item>
                            <Descriptions.Item label="投保类型">{userInfo.c_type && userInfo.c_type === 'AH' ? '车辆房屋' : '房屋'}</Descriptions.Item>
                        </Descriptions>
                        </div>
                    ) : null
                }
                {
                    policy && policy.auto_policy ? (
                        <div className="container">
                            <div className="button-area">
                                <Button type="link" onClick={this.updateAuto.bind(this)}>更新</Button>
                                <Button type="link" onClick={this.deleteOperation.bind(this, policy ? policy.auto_policy : '', 2)}>删除</Button>
                            </div>
                            <Descriptions title="车辆保险" bordered>
                                <Descriptions.Item label="状态">{ policy.auto_policy && policy.auto_policy === 'C' ? '正常' : '过期'}</Descriptions.Item>
                                <Descriptions.Item label="是否分期">{policy.auto_policy && policy.auto_policy.c_instal === '0' ? '是' : '否'}</Descriptions.Item>
                                <Descriptions.Item label="应付金额">{policy.auto_policy ? policy.auto_policy.ap_premium : null}</Descriptions.Item>
                                <Descriptions.Item label="投保日期">{policy.auto_policy ? policy.auto_policy.ap_start_date : null}</Descriptions.Item>
                                <Descriptions.Item label="有效日期">{policy.auto_policy ? policy.auto_policy.ap_end_date : null}</Descriptions.Item>
                            </Descriptions>
                        </div>
                    ) : null
                }
                {
                    policy && policy.home_policy ? (
                        <div className="container">
                            <div className="button-area">
                                <Button type="link" onClick={this.updateHome.bind(this)}>更新</Button>
                                <Button type="link" onClick={this.deleteOperation.bind(this, policy ? policy.home_policy : '', 3)}>删除</Button>
                            </div>
                        <Descriptions title="房屋保险" bordered>
                            <Descriptions.Item label="状态">{ policy.home_policy && policy.home_policy === 'C' ? '正常' : '过期'}</Descriptions.Item>
                            <Descriptions.Item label="是否分期">{policy.home_policy && policy.home_policy.c_instal === '0' ? '是' : '否'}</Descriptions.Item>
                            <Descriptions.Item label="应付金额">{policy.home_policy ? policy.home_policy.hp_premium : null}</Descriptions.Item>
                            <Descriptions.Item label="投保日期">{policy.home_policy ? policy.home_policy.hp_start_date : null}</Descriptions.Item>
                            <Descriptions.Item label="有效日期">{policy.home_policy ? policy.home_policy.hp_end_date : null}</Descriptions.Item>
                        </Descriptions>
                        </div>
                    ) : null
                }
            {
                userInfo && userInfo.c_fname ? (
                    <div className="container">
                        <div className="button-area">
                            <Button type="link" onClick={this.updatePerson.bind(this)}>更新</Button>
                            <Button type="link" onClick={this.deleteOperation.bind(this, userInfo, 1)}>删除</Button>
                        </div>
                        <Descriptions title="车" bordered>
                            <Descriptions.Item label="姓">{userInfo.c_fname ? userInfo.c_fname : null}</Descriptions.Item>
                            <Descriptions.Item label="名">{userInfo.c_lname ? userInfo.c_lname : null}</Descriptions.Item>
                            <Descriptions.Item label="性别" span={3}>{userInfo.c_gender && userInfo.c_gender === 'M' ? '男' : '女'}</Descriptions.Item>
                            <Descriptions.Item label="是否分期">{userInfo.c_instal && userInfo.c_instal === '0' ? '是' : '否'}</Descriptions.Item>
                            <Descriptions.Item label="婚姻">{userInfo.c_marital_stat && userInfo.c_marital_stat === 'S' ? '未婚' : '已婚'}</Descriptions.Item>
                            <Descriptions.Item label="投保类型">{userInfo.c_type && userInfo.c_type === 'AH' ? '车辆房屋' : '房屋'}</Descriptions.Item>
                        </Descriptions>
                    </div>
                ) : null
            }
            {
                userInfo && userInfo.c_fname ? (
                    <div className="container">
                        <div className="button-area">
                            <Button type="link" onClick={this.updatePerson.bind(this)}>更新</Button>
                            <Button type="link" onClick={this.deleteOperation.bind(this, userInfo, 1)}>删除</Button>
                        </div>
                        <Descriptions title="驾驶员" bordered>
                            <Descriptions.Item label="姓">{userInfo.c_fname ? userInfo.c_fname : null}</Descriptions.Item>
                            <Descriptions.Item label="名">{userInfo.c_lname ? userInfo.c_lname : null}</Descriptions.Item>
                            <Descriptions.Item label="性别" span={3}>{userInfo.c_gender && userInfo.c_gender === 'M' ? '男' : '女'}</Descriptions.Item>
                            <Descriptions.Item label="是否分期">{userInfo.c_instal && userInfo.c_instal === '0' ? '是' : '否'}</Descriptions.Item>
                            <Descriptions.Item label="婚姻">{userInfo.c_marital_stat && userInfo.c_marital_stat === 'S' ? '未婚' : '已婚'}</Descriptions.Item>
                            <Descriptions.Item label="投保类型">{userInfo.c_type && userInfo.c_type === 'AH' ? '车辆房屋' : '房屋'}</Descriptions.Item>
                        </Descriptions>
                    </div>
                ) : null
            }
            <Modal {...addModal}>
                <Form layout="horizontal">
                    <Item label="姓" {...formItemLayout}>
                        {getFieldDecorator('c_fname', {
                            initialValue: editInfo.c_fname ? editInfo.c_fname : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入姓'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                    <Item label="名" {...formItemLayout}>
                        {getFieldDecorator('c_lname', {
                            initialValue: editInfo.c_lname ? editInfo.c_lname : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入名'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                    <Item label="性别" {...formItemLayout}>
                        {getFieldDecorator('c_gender', {
                            initialValue: editInfo.c_gender ? editInfo.c_gender : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请选择性别'
                                }
                            ]
                        })( <Radio.Group>
                            <Radio value={'M'}>男</Radio>
                            <Radio value={'F'}>女</Radio>
                        </Radio.Group>)}
                    </Item>
                    <Item label="婚姻" {...formItemLayout}>
                        {getFieldDecorator('c_marital_stat', {
                            initialValue: editInfo.c_marital_stat ? editInfo.c_marital_stat : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请选择婚姻情况'
                                }
                            ]
                        })( <Radio.Group>
                            <Radio value={'M'}>已婚</Radio>
                            <Radio value={'S'}>未婚</Radio>
                            <Radio value={'W'}>守寡</Radio>
                        </Radio.Group>)}
                    </Item>
                    <Item label="是否分期" {...formItemLayout}>
                        {getFieldDecorator('c_instal', {
                            initialValue: editInfo.c_instal ? editInfo.c_instal : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请选择是否分期'
                                }
                            ]
                        })( <Radio.Group>
                            <Radio value={'1'}>是</Radio>
                            <Radio value={'0'}>否</Radio>
                        </Radio.Group>)}
                    </Item>
                    <Item label="投保类型" {...formItemLayout}>
                        {getFieldDecorator('c_type', {
                            initialValue: editInfo.c_type ? editInfo.c_type : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请选择投保类型'
                                }
                            ]
                        })( <Radio.Group>
                            <Radio value={'A'}>车辆</Radio>
                            <Radio value={'H'}>房屋</Radio>
                            <Radio value={'AH'}>车辆房屋</Radio>
                        </Radio.Group>)}
                    </Item>
                </Form>
            </Modal>
            <Modal {...otherModal}>
                <Form layout="horizontal">
                    <Item label="状态" {...formItemLayout}>
                        {getFieldDecorator('stat', {
                            initialValue: editInfo.ap_stat ? editInfo.ap_stat : editInfo.hp_stat,
                            rules:[
                                {
                                    required:true,
                                    message:'请选择状态'
                                }
                            ]
                        })( <Radio.Group>
                            <Radio value={'C'}>正常</Radio>
                            <Radio value={'P'}>过期</Radio>
                        </Radio.Group>)}
                    </Item>
                    <Item label="有效日期" {...formItemLayout}>
                        {getFieldDecorator('end_date', {
                            initialValue: editInfo.ap_end_date ? editInfo.ap_end_date : editInfo.hp_end_date,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入有效日期'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                    <Item label="应付金额" {...formItemLayout}>
                        {getFieldDecorator('premium', {
                            initialValue: editInfo.ap_premium ? editInfo.ap_premium : editInfo.hp_premium,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入应付金额'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                </Form>
            </Modal>
        </div>)
    }
}

const wrapForm = Form.create()(Home);

export default wrapForm;