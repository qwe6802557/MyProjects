import React, { Component } from 'react';
import {Redirect, Route, Switch} from "react-router-dom";
import Router from '@/router';
import Header from "@/components/header/header";
import './layout.less';
export default class Layout extends Component{

    render() {
        return (<div className="layout">
            <Header/>
            <Switch>
                <Route path="/home" component={Router.Home}/>
                <Route path="/receipt" component={Router.Receipt}/>
                <Route path="/search" component={Router.SearchComponent} />
                <Redirect to="/receipt"/>
            </Switch>
        </div>)
    }
}