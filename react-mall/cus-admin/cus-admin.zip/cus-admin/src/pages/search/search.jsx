import React, { Component } from "react";
import Title from '@/components/contentTitle/contentTitle';
import Table from '@/components/table/table';
import Modal from "@/components/modal/modal";
import {Modal as AntModal, Tabs} from 'antd';
import {Input, Button, Form, Radio} from 'antd';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import {reqAdmin} from "../../api/main";
const { Item } = Form;
const { TabPane } = Tabs;
const columns1 = [
        {
            title: '保险类型',
            dataIndex: 'c_type',
            key: 'c_type',
            render:(data) => (<span>{data?data:'-'}</span>)
        },
        {
            title: '姓',
            dataIndex: 'c_fname',
            key: 'c_fname',
            render:(data) => (<span>{data?data:'-'}</span>)
        },
        {
            title: '名',
            dataIndex: 'c_lname',
            key: 'c_lname',
            render:(data) => (<span>{data?data:'-'}</span>)
        },
        {
            title: '性别',
            dataIndex: 'c_gender',
            key: 'c_gender',
            render:(data) => (<span>{data?data:'-'}</span>)
        },
        {
            title: '是否分期',
            dataIndex: 'c_instal',
            key: 'c_instal',
            render:(data) => (<span>{data === '1'?  '是': '否'}</span>),
        },
        {
            title: '投保日期',
            dataIndex: 'ap_start_date',
            key: 'ap_start_date',
            sorter: (a, b) => new Date(a.ap_start_date).getTime() - new Date(b.ap_start_date).getTime(),
            render:(data) => (<span>{data?data:'-'}</span>),
        },
        {
            title: '有效日期',
            dataIndex: 'ap_end_date',
            key: 'ap_end_date',
            sorter: (a, b) => new Date(a.ap_end_date).getTime() - new Date(b.ap_end_date).getTime(),
            render:(data) => (<span>{data?data:'-'}</span>),
        },
        {
            title: '状态',
            dataIndex: 'ap_stat',
            key: 'ap_stat',
            render:(data) => (<span>{data === 'P' ? '过期' : '正常'}</span>),
        },
        {
            title: '应付金额',
            dataIndex: 'ap_premium',
            key: 'ap_premium',
            sorter: (a, b) => a.ap_premium - b.ap_premium,
            render:(data) => (<span>{data?data:'-'}</span>)
        },
      /*  {
        title: '操作',
        render:(data) => {
            return (
                <div>
                    <Button type="link" >删除</Button>
                </div>
            )
        }
    },*/
    ];
const columns2 = [
    {
        title: '保险类型',
        dataIndex: 'c_type',
        key: 'c_type',
        render:(data) => (<span>{data?data:'-'}</span>)
    },
    {
        title: '姓',
        dataIndex: 'c_fname',
        key: 'c_fname',
        render:(data) => (<span>{data?data:'-'}</span>)
    },
    {
        title: '名',
        dataIndex: 'c_lname',
        key: 'c_lname',
        render:(data) => (<span>{data?data:'-'}</span>)
    },
    {
        title: '性别',
        dataIndex: 'c_gender',
        key: 'c_gender',
        render:(data) => (<span>{data?data:'-'}</span>)
    },
    {
        title: '是否分期',
        dataIndex: 'c_instal',
        key: 'c_instal',
        render:(data) => (<span>{data === '1'?  '是': '否'}</span>),
    },
    {
        title: '投保日期',
        dataIndex: 'hp_start_date',
        key: 'hp_start_date',
        sorter: (a, b) => new Date(a.hp_start_date).getTime() - new Date(b.hp_start_date).getTime(),
        render:(data) => (<span>{data?data:'-'}</span>),
    },
    {
        title: '有效日期',
        dataIndex: 'hp_end_date',
        key: 'hp_end_date',
        sorter: (a, b) => new Date(a.hp_end_date).getTime() - new Date(b.hp_end_date).getTime(),
        render:(data) => (<span>{data?data:'-'}</span>),
    },
    {
        title: '状态',
        dataIndex: 'hp_stat',
        key: 'hp_stat',
        render:(data) => (<span>{data === 'P' ? '过期' : '正常'}</span>),
    },
    {
        title: '应付金额',
        dataIndex: 'hp_premium',
        key: 'hp_premium',
        sorter: (a, b) => a.hp_premium - b.hp_premium,
        render:(data) => (<span>{data?data:'-'}</span>)
    },
    /*{
        title: '操作',
        render:(data) => {
            return (
                <div>
                    <Button type="link" >删除</Button>
                </div>
            )
        }
    },*/
];

class SearchComponent extends Component{
    state = {
        dataSource: [],
        newDataSource: [],
        columns: columns1,
        columns1: columns2,
        isSex: false,
        pagination: {
            total: 0,
            current: 1,
            pageSize: 10,
            onChange: this.pageChange
        },
        dataSource1: [],
        newDataSource1: [],
        modalVisible: false,
        modalVisible1: false,
        editInfo: {},
        nowIndex: 1,
        id: '',
        name: '',
        header: ''
    };

    pageChange = (current) => {
        this.setState({
            pagination: Object.assign({}, this.state.pagination, {current})
        })
    };

    changeSex (value) {
        this.setState({
            isSex: value
        });
    }

    editWords (data) {
        this.setState({
            editInfo: data,
            modalVisible: true
        });
    }

    getData = async () => {
        const result = await reqAdmin();

        const { all } = result.data;

        console.log(all);

        this.setState({
            dataSource: all.auto_policy,
            newDataSource: all.auto_policy,
            dataSource1: all.home_policy,
            newDataSource1: all.home_policy
        });
    };

    deleteWords (data) {
        /*const that = this;*/
        AntModal.confirm({
            title: `确定删除${data.userName}?`,
            icon: <ExclamationCircleOutlined />,
            content: '删除后将无法复原',
            onOk() {
                /* reqDeleteUser({
                     _id: data._id,
                 }).then( res => {
                     const { code } = res.data;

                     if (code === 0){
                         message.success(res.data.message);
                         that.getClassMateData();
                     } else {
                         message.error(res.data.message);
                     }
                 });*/
            },
            onCancel() {}})
    }
   // 筛选查询
    searchData () {
       const { id, name, newDataSource, newDataSource1 } = this.state;
       let dataSource = newDataSource;
       let dataSource1 = newDataSource1;

       if (id){
           dataSource = newDataSource.filter(item => item.c_id === Number(id));
           dataSource1 = newDataSource1.filter(item => item.c_id === Number(id));
       }

       if (name){
           dataSource = newDataSource.filter(item => item.c_fname.includes(name) || item.c_lname.includes(name));
           dataSource1 = newDataSource1.filter(item => item.c_fname.includes(name) || item.c_lname.includes(name));
       }

       this.setState({
           dataSource,
           dataSource1
       });
    }

    getClassMateData = (value) => {
        /*   const { /!*current, pageSize*!/ } = this.state.pagination;*/
        /*reqUserList({
            curPage: current,
            pageSize: pageSize,
            username: value ? value : ''
        }).then( res => {
            const { code, messageBody } = res.data;

            if (code === 0){
                this.setState({
                    dataSource: messageBody.data,
                    pagination: Object.assign({}, this.state.pagination, { total: messageBody.total})
                });
            } else {
                message.error(res.data.message);
            }
        });*/
    };

    addWords () {
        this.setState({
            modalVisible: true,
        })
    }

    changeId (e) {
        this.setState({
            id: e.target.value
        });
    }

    changeName (e) {
        this.setState({
            name: e.target.value
        });
    }

    changeHeader (e) {
        this.setState({
            header: e.target.value
        });
    }

    searchHeader(){
        this.setState({
            modalVisible1: true,
        });
    }

    callback(value){
       this.setState({
           nowIndex: value
       });
    }

    componentDidMount() {
        this.getClassMateData();
        this.getData();
    }

    render() {
        const {  dataSource, modalVisible, editInfo, modalVisible1, dataSource1 } = this.state;
        const { getFieldDecorator } = this.props.form;

        const formItemLayout = {
            labelCol:{ span:6 },
            wrapperCol:{ span:15 },
        };

        const addModal = {
            title: editInfo._id ? '编辑信息' : '添加信息',
            okText: '确定',
            cancelText: '取消',
            visible: modalVisible,
            destroyOnClose: false,
            onOk: () => {
                this.props.form.validateFields((err, values) => {
                    if (err){
                        return false;
                    }

                    if (editInfo._id){
                        values._id = editInfo._id;
                        /*reqUpdatePhone(values).then( res => {
                            const { code } = res.data;

                            if (code === 0){
                                message.success(res.data.message);
                                this.getClassMateData();
                            } else {
                                message.error(res.data.message);
                            }
                        });*/
                    } else {
                        /*reqAddPhone(values).then( res => {
                            const { code } = res.data;

                            if (code === 0){
                                message.success(res.data.message);
                                this.getClassMateData();
                            } else {
                                message.error(res.data.message);
                            }
                        });*/
                    }
                    this.setState({
                        modalVisible: false,
                        editInfo: {}
                    }, () => {
                        this.props.form.resetFields();
                    });
                });
            },
            onCancel: () => {
                this.setState({
                    modalVisible: false,
                    editInfo: {}
                }, () => {
                    this.props.form.resetFields();
                });
            }
        };

        const searchModal = {
            title: '筛选显示',
            okText: '确定',
            cancelText: '取消',
            visible: modalVisible1,
            destroyOnClose: false,
            onOk: () => {
                const { header, newDataSource, newDataSource1 } = this.state;
                let dataSource = newDataSource;
                let dataSource1 = newDataSource1;

                if (header){
                    dataSource = newDataSource.filter( item => item.c_gender === header);
                    dataSource1 = newDataSource1.filter( item => item.c_gender === header);
                }

                this.setState({
                    dataSource,
                    dataSource1,
                    modalVisible1: false,
                });
            },
            onCancel: () => {
                this.setState({
                    modalVisible1: false
                });
            }
        };

        return (<div className="classmate-words">
            <Title title={'动态查询'}/>
            <div className="search-area" style={{marginTop: '10px'}}>
                <Input onChange={this.changeId.bind(this)} placeholder="请输入保险编号" style={{width: '192px', marginRight: '15px'}}/>
                <Input onChange={this.changeName.bind(this)} placeholder="请输入姓名" style={{width: '192px', marginRight: '15px'}}/>
                <Button type="primary" icon="search"style={{marginRight: '15px'}} onClick={this.searchData.bind(this)}>搜索</Button>
                <Button type="primary" icon="branches" onClick={this.searchHeader.bind(this)}>筛选显示</Button>
            </div>
            <Tabs defaultActiveKey="1" onChange={this.callback.bind(this)} style={{textAlign: 'left',marginTop: '10px'}}>
                <TabPane tab="车辆保险" key="1">
                    <Table pagination={false} dataSource={dataSource} columns={this.state.columns}/>
                </TabPane>
                <TabPane tab="房屋保险" key="2">
                    <Table pagination={false} dataSource={dataSource1} columns={this.state.columns1}/>
                </TabPane>
            </Tabs>
            <Modal {...addModal}>
                <Form layout="horizontal">
                    <Item label="QQ号码" {...formItemLayout}>
                        {getFieldDecorator('qq', {
                            initialValue: editInfo.qq ? editInfo.qq : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入QQ号码'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                    <Item label="微信号" {...formItemLayout}>
                        {getFieldDecorator('wechat', {
                            initialValue: editInfo.wechat ? editInfo.wechat : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入微信号'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                    <Item label="电话号码" {...formItemLayout}>
                        {getFieldDecorator('mobile', {
                            initialValue: editInfo.mobile ? editInfo.mobile : undefined,
                            rules:[
                                {
                                    required:true,
                                    message:'请输入电话号码'
                                }
                            ]
                        })(<Input  placeholder="请输入"/>)}
                    </Item>
                </Form>
            </Modal>
            <Modal {...searchModal}>
                <div style={{textAlign: 'center'}}>
                   <Radio.Group onChange={this.changeHeader.bind(this)} value={this.state.header}>
                       <Radio value={''}>全部</Radio>
                        <Radio value={'M'}>男</Radio>
                        <Radio value={'F'}>女</Radio>
                    </Radio.Group>
                </div>
            </Modal>
        </div>);
    }
}
const wrapForm = Form.create()(SearchComponent);

export default wrapForm;