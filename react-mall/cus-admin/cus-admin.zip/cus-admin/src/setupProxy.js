const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
    app.use(createProxyMiddleware(['/user', '/auth', '/admin', '/update', '/delete'], {
        target: 'http://db6083.viphk.ngrok.org',
        changeOrigin: true,
        secure: false,
    }));
    // app.use(proxy('/test', { target: 'http://localhost:3000' }));
    // 省略...
};