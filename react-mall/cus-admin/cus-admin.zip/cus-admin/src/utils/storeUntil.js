import Store from 'store'

export default {
  getToken () {
    return Store.get('token') || ''
  },
  setToken (token) {
    return Store.set('token', token)
  },
  delToken () {
    return Store.remove('token')
  },
  getInfo () {
    if (Store.get('userInfo')){
      return JSON.parse(Store.get('userInfo'));
    } else {
      return  '';
    }
  },
  setInfo (info) {
    return Store.set('userInfo', JSON.stringify(info));
  },
  delInfo () {
    return Store.remove('userInfo');
  },
}
