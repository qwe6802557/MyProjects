import React from "react";
import Loadable from 'react-loadable';

const Layout = Loadable({
    loader: () => import('@/pages/layout/layout.jsx'),
    loading(){
        return (<h1>加载中...</h1>)
    }
});

const Home = Loadable({
    loader: () => import('@/pages/home/home.jsx'),
    loading() {
        return (<h1>加载中...</h1>)
    }
});

const Receipt = Loadable({
    loader: () => import('@/pages/receipt/receipt.jsx'),
    loading() {
        return (<h1>加载中...</h1>)
    }
});

const SearchComponent = Loadable({
    loader: () => import('@/pages/search/search.jsx'),
    loading() {
        return (<h1>加载中...</h1>)
    }
});

const Login = Loadable({
    loader: () => import('@/pages/login/login.jsx'),
    loading() {
        return (<h1>加载中...</h1>)
    }
});


export default {
    Home,
    Login,
    Layout,
    SearchComponent,
    Receipt,
}